
BattlefieldMapOptions = {
	["locked"] = true,
	["opacity"] = 0.7,
	["showPlayers"] = true,
	["position"] = {
		["y"] = 444.0000305175781,
		["x"] = 112.4998474121094,
	},
}
