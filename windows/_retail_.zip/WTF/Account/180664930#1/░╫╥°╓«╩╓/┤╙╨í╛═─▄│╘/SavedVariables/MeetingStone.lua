
MEETINGSTONE_CHARACTER_DB = {
	["profileKeys"] = {
		["从小就能吃 - 白银之手"] = "从小就能吃 - 白银之手",
	},
	["profiles"] = {
		["从小就能吃 - 白银之手"] = {
			["appShine"] = "80200.03",
			["createHistoryList"] = {
				"9-0-19-0", -- [1]
			},
			["recent"] = {
				["3-254-671-0"] = {
					{
						["role"] = "HEALER",
						["name"] = "美小萨-熊猫酒仙",
						["iLvl"] = 420,
						["time"] = 1567845578,
						["class"] = 7,
						["leader"] = true,
						["bTag"] = "慵懒之龟#5168406",
					}, -- [1]
					{
						["role"] = "DAMAGER",
						["name"] = "悲伤的威尔-伊萨里奥斯",
						["iLvl"] = 351,
						["time"] = 1567845590,
						["class"] = 4,
						["bTag"] = "神威之翼#5320",
					}, -- [2]
					{
						["role"] = "DAMAGER",
						["name"] = "但丁之子-罗宁",
						["iLvl"] = 444,
						["time"] = 1567845588,
						["class"] = 12,
						["bTag"] = "光之军刀#51486",
					}, -- [3]
					{
						["role"] = "DAMAGER",
						["name"] = "暗夜魔灵-利刃之拳",
						["iLvl"] = 439,
						["time"] = 1567845594,
						["class"] = 12,
						["bTag"] = "唔讲得#5713",
					}, -- [4]
					{
						["role"] = "DAMAGER",
						["name"] = "欧洛拉-罗宁",
						["time"] = 1567845574,
						["class"] = 8,
					}, -- [5]
					{
						["role"] = "HEALER",
						["name"] = "十方俱灭灬-拉格纳罗斯",
						["iLvl"] = 385,
						["time"] = 1567845592,
						["class"] = 5,
						["bTag"] = "战斗之裤#5225789",
					}, -- [6]
					{
						["role"] = "HEALER",
						["name"] = "PlayerPDFDGS-阿尔萨斯",
						["iLvl"] = 382,
						["time"] = 1567845715,
						["class"] = 5,
						["bTag"] = "快乐之裤#5192732",
					}, -- [7]
					{
						["role"] = "DAMAGER",
						["name"] = "Aurore-玛法里奥",
						["time"] = 1567845592,
						["class"] = 2,
						["leader"] = true,
					}, -- [8]
					{
						["role"] = "TANK",
						["name"] = "钱作怪-奥特兰克",
						["time"] = 1567845656,
						["class"] = 2,
						["leader"] = true,
					}, -- [9]
					{
						["role"] = "DAMAGER",
						["name"] = "蓝嵐嵐-白银之手",
						["time"] = 1567845656,
						["class"] = 10,
					}, -- [10]
					{
						["role"] = "HEALER",
						["name"] = "神乐殇-蜘蛛王国",
						["time"] = 1567845656,
						["class"] = 7,
					}, -- [11]
					{
						["role"] = "TANK",
						["name"] = "错位的搭配-蜘蛛王国",
						["time"] = 1567845656,
						["class"] = 2,
					}, -- [12]
					{
						["role"] = "DAMAGER",
						["name"] = "Independent-罗宁",
						["time"] = 1567845656,
						["class"] = 4,
					}, -- [13]
					{
						["role"] = "DAMAGER",
						["name"] = "玩地就是心跳-铜龙军团",
						["iLvl"] = 410,
						["time"] = 1567845656,
						["class"] = 2,
						["bTag"] = "傲雪凌霜#5669",
					}, -- [14]
					{
						["role"] = "DAMAGER",
						["name"] = "喵女仆-拉文凯斯",
						["iLvl"] = 406,
						["time"] = 1567845656,
						["class"] = 11,
						["bTag"] = "公爵#5143",
					}, -- [15]
					{
						["role"] = "DAMAGER",
						["name"] = "怒风之锋-末日行者",
						["iLvl"] = 417,
						["time"] = 1567845656,
						["class"] = 12,
						["bTag"] = "狼哥#51263",
					}, -- [16]
					{
						["role"] = "DAMAGER",
						["name"] = "土豆土豆呀-神圣之歌",
						["time"] = 1567845656,
						["class"] = 8,
					}, -- [17]
					{
						["role"] = "DAMAGER",
						["name"] = "尼基塔柳-图拉扬",
						["time"] = 1567845715,
						["class"] = 10,
						["leader"] = true,
					}, -- [18]
					{
						["role"] = "DAMAGER",
						["name"] = "狼性不该-熊猫酒仙",
						["time"] = 1567845715,
						["class"] = 3,
					}, -- [19]
					{
						["role"] = "DAMAGER",
						["name"] = "紫云苍月-暮色森林",
						["iLvl"] = 394,
						["time"] = 1567845715,
						["class"] = 4,
						["bTag"] = "紫云沧月#5953",
					}, -- [20]
					{
						["role"] = "DAMAGER",
						["name"] = "Autiste-白银之手",
						["iLvl"] = 440,
						["time"] = 1567845715,
						["class"] = 8,
						["bTag"] = "炼狱丶#51386",
					}, -- [21]
					{
						["role"] = "HEALER",
						["name"] = "黑珍珠灬-拉格纳罗斯",
						["iLvl"] = 396,
						["time"] = 1567845715,
						["class"] = 5,
						["bTag"] = "暴躁之鼬#5247725",
					}, -- [22]
				},
				["9-0-19-0"] = {
					{
						["role"] = "DAMAGER",
						["name"] = "呄尐隐丶-埃德萨拉",
						["time"] = 1567864299,
						["class"] = 3,
						["leader"] = true,
					}, -- [1]
					{
						["role"] = "DAMAGER",
						["name"] = "疯狂的口子窖-罗宁",
						["time"] = 1567864299,
						["class"] = 2,
					}, -- [2]
					{
						["role"] = "DAMAGER",
						["name"] = "亂轟轟丶-国王之谷",
						["time"] = 1567864299,
						["class"] = 8,
					}, -- [3]
					{
						["role"] = "DAMAGER",
						["name"] = "馹丶天-国王之谷",
						["iLvl"] = 372,
						["time"] = 1567864299,
						["class"] = 9,
						["bTag"] = "良情择木而栖#51102",
					}, -- [4]
					{
						["role"] = "DAMAGER",
						["name"] = "playerFSNLZT-主宰之剑",
						["iLvl"] = 439,
						["time"] = 1567864278,
						["class"] = 10,
						["bTag"] = "富强民主文明和谐#51873",
					}, -- [5]
					{
						["role"] = "DAMAGER",
						["name"] = "郭大寳-暗影之月",
						["time"] = 1567864299,
						["class"] = 4,
					}, -- [6]
					{
						["role"] = "HEALER",
						["name"] = "米仔囡囡-白银之手",
						["time"] = 1567864299,
						["class"] = 5,
					}, -- [7]
					{
						["role"] = "DAMAGER",
						["name"] = "Wanghui-蜘蛛王国",
						["time"] = 1567864299,
						["class"] = 6,
					}, -- [8]
					{
						["role"] = "DAMAGER",
						["name"] = "戰魁-罗宁",
						["iLvl"] = 439,
						["time"] = 1567864299,
						["class"] = 1,
						["bTag"] = "jojo#5994",
					}, -- [9]
					{
						["role"] = "DAMAGER",
						["name"] = "真真的个人-泰兰德",
						["time"] = 1567864376,
						["class"] = 3,
						["leader"] = true,
					}, -- [10]
					{
						["role"] = "DAMAGER",
						["name"] = "丨汕丨-霜之哀伤",
						["time"] = 1567864376,
						["class"] = 6,
					}, -- [11]
					{
						["role"] = "TANK",
						["name"] = "赤澜-库尔提拉斯",
						["iLvl"] = 396,
						["time"] = 1567864376,
						["class"] = 1,
						["bTag"] = "火力支援#5871",
					}, -- [12]
					{
						["role"] = "DAMAGER",
						["name"] = "烟波刺青-远古海滩",
						["time"] = 1567864376,
						["class"] = 5,
					}, -- [13]
					{
						["role"] = "DAMAGER",
						["name"] = "昨夜西风-轻风之语",
						["time"] = 1567864376,
						["class"] = 11,
					}, -- [14]
					{
						["role"] = "DAMAGER",
						["name"] = "白给嗷-破碎岭",
						["time"] = 1567864376,
						["class"] = 6,
					}, -- [15]
					{
						["role"] = "DAMAGER",
						["name"] = "天韵之红-法拉希姆",
						["time"] = 1567864376,
						["class"] = 4,
					}, -- [16]
					{
						["role"] = "DAMAGER",
						["name"] = "离开回来-无尽之海",
						["time"] = 1567864458,
						["class"] = 3,
						["leader"] = true,
					}, -- [17]
					{
						["role"] = "DAMAGER",
						["name"] = "星之子丶-安苏",
						["time"] = 1567864458,
						["class"] = 3,
					}, -- [18]
					{
						["role"] = "DAMAGER",
						["name"] = "维密天使秀-凯尔萨斯",
						["time"] = 1567864458,
						["class"] = 5,
					}, -- [19]
					{
						["role"] = "DAMAGER",
						["name"] = "燕小七-银月",
						["time"] = 1567864458,
						["class"] = 3,
					}, -- [20]
					{
						["role"] = "DAMAGER",
						["name"] = "老犀牛角-迦拉克隆",
						["time"] = 1567864588,
						["class"] = 6,
						["leader"] = true,
					}, -- [21]
					{
						["role"] = "DAMAGER",
						["name"] = "playerENUQXD-黑暗之矛",
						["time"] = 1567864588,
						["class"] = 5,
					}, -- [22]
					{
						["role"] = "DAMAGER",
						["name"] = "道森先生-主宰之剑",
						["time"] = 1567864588,
						["class"] = 1,
					}, -- [23]
					{
						["role"] = "DAMAGER",
						["name"] = "秋夜落枫-末日行者",
						["time"] = 1567864588,
						["class"] = 2,
					}, -- [24]
					{
						["role"] = "DAMAGER",
						["name"] = "微分-萨洛拉丝",
						["time"] = 1567864588,
						["class"] = 8,
					}, -- [25]
					{
						["role"] = "DAMAGER",
						["name"] = "祥子-激流之傲",
						["iLvl"] = 406,
						["time"] = 1567864588,
						["class"] = 2,
						["bTag"] = "祥子#5288",
					}, -- [26]
					{
						["role"] = "DAMAGER",
						["name"] = "羅蘭灬之歌-国王之谷",
						["time"] = 1567864588,
						["class"] = 2,
					}, -- [27]
					{
						["role"] = "DAMAGER",
						["name"] = "Cdk-山丘之王",
						["time"] = 1567864588,
						["class"] = 6,
					}, -- [28]
					{
						["role"] = "DAMAGER",
						["name"] = "花落丶莫相惜-布兰卡德",
						["time"] = 1567864588,
						["class"] = 6,
					}, -- [29]
					{
						["role"] = "DAMAGER",
						["name"] = "不知天上宫阙-盖斯",
						["time"] = 1567864636,
						["class"] = 12,
						["leader"] = true,
					}, -- [30]
					{
						["role"] = "DAMAGER",
						["name"] = "帕林-生态船",
						["time"] = 1567864724,
						["class"] = 8,
						["leader"] = true,
					}, -- [31]
					{
						["role"] = "DAMAGER",
						["name"] = "Sisi-朵丹尼尔",
						["iLvl"] = 344,
						["time"] = 1567864724,
						["class"] = 2,
						["bTag"] = "脑壳中刀#5688",
					}, -- [32]
					{
						["role"] = "DAMAGER",
						["name"] = "均艳-白银之手",
						["iLvl"] = 393,
						["time"] = 1567864724,
						["class"] = 3,
						["bTag"] = "沐丶辰#5427",
					}, -- [33]
					{
						["role"] = "DAMAGER",
						["name"] = "忧愁指尖绕-血牙魔王",
						["iLvl"] = 427,
						["time"] = 1567864724,
						["class"] = 1,
						["bTag"] = "黑的不一定是坏的#5762",
					}, -- [34]
					{
						["role"] = "DAMAGER",
						["name"] = "楠墨-深渊之巢",
						["time"] = 1567864719,
						["class"] = 8,
					}, -- [35]
					{
						["role"] = "DAMAGER",
						["name"] = "狮王骑士-凤凰之神",
						["iLvl"] = 307,
						["time"] = 1567864724,
						["class"] = 6,
						["bTag"] = "王小猛#5308",
					}, -- [36]
					{
						["role"] = "DAMAGER",
						["name"] = "克尔小科奥-克尔苏加德",
						["time"] = 1567864926,
						["class"] = 10,
						["leader"] = true,
					}, -- [37]
					{
						["role"] = "DAMAGER",
						["name"] = "大胡子老爷子-主宰之剑",
						["time"] = 1567864926,
						["class"] = 1,
					}, -- [38]
					{
						["role"] = "DAMAGER",
						["name"] = "杰克船长丶-末日行者",
						["iLvl"] = 445,
						["time"] = 1567864926,
						["class"] = 4,
						["bTag"] = "红烧牛肉面#52827",
					}, -- [39]
					{
						["role"] = "HEALER",
						["name"] = "烟织青萝梦-瓦里玛萨斯",
						["iLvl"] = 439,
						["time"] = 1567864926,
						["class"] = 10,
						["bTag"] = "且听风吟#5908",
					}, -- [40]
					{
						["role"] = "DAMAGER",
						["name"] = "伍尺差半寸-罗宁",
						["iLvl"] = 407,
						["time"] = 1567864926,
						["class"] = 8,
						["bTag"] = "挽歌清唱#5799",
					}, -- [41]
					{
						["role"] = "DAMAGER",
						["name"] = "Trevorshaw-迦拉克隆",
						["iLvl"] = 408,
						["time"] = 1567864926,
						["class"] = 1,
						["bTag"] = "Warbringer#51116",
					}, -- [42]
					{
						["role"] = "DAMAGER",
						["name"] = "丨旧灬袜子丨-末日行者",
						["iLvl"] = 328,
						["time"] = 1567864926,
						["class"] = 2,
						["bTag"] = "BattleOoze#54588",
					}, -- [43]
					{
						["role"] = "DAMAGER",
						["name"] = "丿内涵段子灬-安苏",
						["time"] = 1567864926,
						["class"] = 2,
					}, -- [44]
					{
						["role"] = "DAMAGER",
						["name"] = "爱喝雪碧-凯尔萨斯",
						["iLvl"] = 343,
						["time"] = 1567864926,
						["class"] = 3,
						["bTag"] = "上帝之锤#5255",
					}, -- [45]
					{
						["role"] = "DAMAGER",
						["name"] = "不忘初战-熊猫酒仙",
						["time"] = 1567865472,
						["class"] = 9,
						["leader"] = true,
					}, -- [46]
					{
						["role"] = "DAMAGER",
						["name"] = "狩猎蛋-埃克索图斯",
						["time"] = 1567865472,
						["class"] = 3,
					}, -- [47]
					{
						["role"] = "DAMAGER",
						["name"] = "Vforever-灰谷",
						["time"] = 1567865472,
						["class"] = 8,
					}, -- [48]
					{
						["role"] = "DAMAGER",
						["name"] = "南山凉白开-末日行者",
						["time"] = 1567865472,
						["class"] = 1,
					}, -- [49]
					{
						["role"] = "DAMAGER",
						["name"] = "跟风德-白银之手",
						["iLvl"] = 441,
						["time"] = 1567865472,
						["class"] = 11,
						["bTag"] = "老衲#51140",
					}, -- [50]
					{
						["role"] = "DAMAGER",
						["name"] = "你老公真润-熊猫酒仙",
						["iLvl"] = 326,
						["time"] = 1567865472,
						["class"] = 3,
						["bTag"] = "小北#52460",
					}, -- [51]
					{
						["role"] = "TANK",
						["name"] = "月霜-达纳斯",
						["iLvl"] = 418,
						["time"] = 1567865472,
						["class"] = 1,
						["bTag"] = "明镜湖之忆#5672",
					}, -- [52]
					{
						["role"] = "TANK",
						["name"] = "九月桂-主宰之剑",
						["time"] = 1567865538,
						["class"] = 11,
						["leader"] = true,
					}, -- [53]
					{
						["role"] = "DAMAGER",
						["name"] = "初茶-白银之手",
						["time"] = 1567865538,
						["class"] = 4,
					}, -- [54]
					{
						["role"] = "DAMAGER",
						["name"] = "第一硬汉-国王之谷",
						["iLvl"] = 440,
						["time"] = 1567865538,
						["class"] = 3,
						["bTag"] = "第一硬汉#5346",
					}, -- [55]
					{
						["role"] = "DAMAGER",
						["name"] = "像雾又像风-布兰卡德",
						["iLvl"] = 419,
						["time"] = 1567865538,
						["class"] = 8,
						["bTag"] = "像雾又像风#5452",
					}, -- [56]
					{
						["role"] = "DAMAGER",
						["name"] = "你是我的心肝-格瑞姆巴托",
						["iLvl"] = 420,
						["time"] = 1567867111,
						["class"] = 6,
						["bTag"] = "寻找当年的初恋#5348",
					}, -- [57]
					{
						["role"] = "DAMAGER",
						["name"] = "Slugger-戈古纳斯",
						["time"] = 1567867111,
						["class"] = 3,
					}, -- [58]
					{
						["role"] = "DAMAGER",
						["name"] = "Tianwailaike-戈古纳斯",
						["time"] = 1567866416,
						["class"] = 8,
					}, -- [59]
					{
						["role"] = "DAMAGER",
						["name"] = "借书-国王之谷",
						["time"] = 1567866146,
						["class"] = 4,
					}, -- [60]
					{
						["role"] = "DAMAGER",
						["name"] = "吕布布丶-白银之手",
						["iLvl"] = 441,
						["time"] = 1567875453,
						["class"] = 3,
						["bTag"] = "風細細#51221",
					}, -- [61]
					{
						["role"] = "DAMAGER",
						["name"] = "落葬人-白银之手",
						["iLvl"] = 447,
						["time"] = 1567875453,
						["class"] = 4,
						["bTag"] = "嘿嘿嘿#52951",
					}, -- [62]
					{
						["role"] = "DAMAGER",
						["name"] = "Kocool-玛诺洛斯",
						["iLvl"] = 425,
						["time"] = 1567872797,
						["class"] = 3,
						["bTag"] = "热带雨林#5125",
					}, -- [63]
					{
						["role"] = "TANK",
						["name"] = "萌哥来也-雷斧堡垒",
						["iLvl"] = 420,
						["time"] = 1567877890,
						["class"] = 1,
						["leader"] = true,
						["bTag"] = "杨勇#5914",
					}, -- [64]
					{
						["role"] = "DAMAGER",
						["name"] = "星殉-提尔之手",
						["time"] = 1567872416,
						["class"] = 6,
					}, -- [65]
					{
						["role"] = "DAMAGER",
						["name"] = "Bijin-熊猫酒仙",
						["iLvl"] = 405,
						["time"] = 1567867111,
						["class"] = 3,
						["bTag"] = "ryou#5462",
					}, -- [66]
					{
						["role"] = "HEALER",
						["name"] = "自由行走的云-拉文凯斯",
						["time"] = 1567867111,
						["class"] = 5,
					}, -- [67]
					{
						["role"] = "DAMAGER",
						["name"] = "龍戰八荒-生态船",
						["time"] = 1567867719,
						["class"] = 1,
					}, -- [68]
					{
						["role"] = "DAMAGER",
						["name"] = "云勇-守护之剑",
						["iLvl"] = 404,
						["time"] = 1567869665,
						["class"] = 6,
						["bTag"] = "峨眉守山和尚#5453",
					}, -- [69]
					{
						["role"] = "DAMAGER",
						["name"] = "Tatsutoro-金色平原",
						["iLvl"] = 436,
						["time"] = 1567868004,
						["class"] = 12,
						["bTag"] = "红尘#5814",
					}, -- [70]
					{
						["role"] = "DAMAGER",
						["name"] = "Deloriss-白银之手",
						["iLvl"] = 406,
						["time"] = 1567872854,
						["class"] = 4,
						["bTag"] = "Nieko#5283",
					}, -- [71]
					{
						["role"] = "DAMAGER",
						["name"] = "布偶无心-罗宁",
						["iLvl"] = 433,
						["time"] = 1567875453,
						["class"] = 4,
						["bTag"] = "夜朽瞳#5739",
					}, -- [72]
					{
						["role"] = "DAMAGER",
						["name"] = "崛起的霸主-丹莫德",
						["time"] = 1567869665,
						["class"] = 3,
					}, -- [73]
					{
						["role"] = "HEALER",
						["name"] = "Happle-安苏",
						["time"] = 1567875062,
						["class"] = 2,
					}, -- [74]
					{
						["role"] = "DAMAGER",
						["name"] = "铁锤丹心-雷斧堡垒",
						["iLvl"] = 419,
						["time"] = 1567874490,
						["class"] = 2,
						["bTag"] = "大铁锤#5821",
					}, -- [75]
					{
						["role"] = "DAMAGER",
						["name"] = "邦邦-加里索斯",
						["iLvl"] = 442,
						["time"] = 1567875453,
						["class"] = 3,
						["bTag"] = "阿邦哥#5490",
					}, -- [76]
					{
						["role"] = "DAMAGER",
						["name"] = "轻灵之魂-奥蕾莉亚",
						["iLvl"] = 401,
						["time"] = 1567875453,
						["class"] = 8,
						["bTag"] = "小绵羊#5540",
					}, -- [77]
					{
						["role"] = "DAMAGER",
						["name"] = "烤焦你-灰谷",
						["iLvl"] = 436,
						["time"] = 1567873269,
						["class"] = 8,
						["bTag"] = "白银之鹰#512278",
					}, -- [78]
					{
						["role"] = "HEALER",
						["name"] = "果果和大景-暗影之月",
						["iLvl"] = 419,
						["time"] = 1567875453,
						["class"] = 10,
						["bTag"] = "果果大妞#5149",
					}, -- [79]
					{
						["role"] = "DAMAGER",
						["name"] = "Garonay-罗宁",
						["time"] = 1567874220,
						["class"] = 4,
					}, -- [80]
					{
						["role"] = "HEALER",
						["name"] = "过期的奶茶-阿拉索",
						["iLvl"] = 408,
						["time"] = 1567875453,
						["class"] = 2,
						["bTag"] = "过期的牛奶#51142",
					}, -- [81]
					{
						["role"] = "DAMAGER",
						["name"] = "Hurray-白银之手",
						["iLvl"] = 419,
						["time"] = 1567877890,
						["class"] = 9,
						["bTag"] = "符申毅#5341",
					}, -- [82]
					{
						["role"] = "DAMAGER",
						["name"] = "大大强-蜘蛛王国",
						["iLvl"] = 410,
						["time"] = 1567876848,
						["class"] = 1,
						["bTag"] = "嘉吉玛#5220",
					}, -- [83]
					{
						["role"] = "DAMAGER",
						["name"] = "美娜的保镖-古加尔",
						["iLvl"] = 438,
						["time"] = 1567876976,
						["class"] = 1,
						["bTag"] = "天火#5998",
					}, -- [84]
					{
						["role"] = "TANK",
						["name"] = "温柔的云-银月",
						["time"] = 1567876994,
						["class"] = 12,
					}, -- [85]
					{
						["role"] = "DAMAGER",
						["name"] = "周蒙蒙-杜隆坦",
						["time"] = 1567877890,
						["class"] = 8,
					}, -- [86]
					{
						["role"] = "DAMAGER",
						["name"] = "安丶和桥丿-白银之手",
						["iLvl"] = 369,
						["time"] = 1567877456,
						["class"] = 5,
						["bTag"] = "微笑丶向前行#5165",
					}, -- [87]
					{
						["role"] = "DAMAGER",
						["name"] = "午夜幽影-安苏",
						["time"] = 1567877163,
						["class"] = 11,
					}, -- [88]
					{
						["role"] = "DAMAGER",
						["name"] = "哎萨拉女王-雷斧堡垒",
						["iLvl"] = 436,
						["time"] = 1567877890,
						["class"] = 11,
						["bTag"] = "傅叔宝#5363",
					}, -- [89]
					{
						["role"] = "DAMAGER",
						["name"] = "塔西索尔-熊猫酒仙",
						["iLvl"] = 441,
						["time"] = 1567877890,
						["class"] = 3,
						["bTag"] = "Hidedestiny#51791",
					}, -- [90]
					{
						["role"] = "DAMAGER",
						["name"] = "艾蕾娜织影-金度",
						["iLvl"] = 350,
						["time"] = 1567877890,
						["class"] = 4,
						["bTag"] = "mitsui#5768",
					}, -- [91]
					{
						["role"] = "DAMAGER",
						["name"] = "风骚妖娆-蜘蛛王国",
						["iLvl"] = 440,
						["time"] = 1567877890,
						["class"] = 3,
						["bTag"] = "勋儿大大#5737",
					}, -- [92]
					{
						["role"] = "DAMAGER",
						["name"] = "安安乐乐-灰谷",
						["iLvl"] = 441,
						["time"] = 1567877890,
						["class"] = 3,
						["bTag"] = "白银之鹰#512278",
					}, -- [93]
					{
						["role"] = "HEALER",
						["name"] = "还我漂漂拳灬-熊猫酒仙",
						["iLvl"] = 421,
						["time"] = 1567877890,
						["class"] = 10,
						["bTag"] = "兽总#5811",
					}, -- [94]
				},
				["3-0-657-0"] = {
					{
						["role"] = "DAMAGER",
						["name"] = "飘逸之凤-桑德兰",
						["iLvl"] = 418,
						["time"] = 1567846097,
						["class"] = 5,
						["bTag"] = "飘逸之花#5139",
					}, -- [1]
					{
						["role"] = "DAMAGER",
						["name"] = "阿修罗丿湮灭-白银之手",
						["iLvl"] = 422,
						["time"] = 1567846097,
						["class"] = 4,
						["bTag"] = "哈库玛#5398",
					}, -- [2]
					{
						["role"] = "HEALER",
						["name"] = "创世宝宝-白银之手",
						["iLvl"] = 420,
						["time"] = 1567846097,
						["class"] = 5,
						["bTag"] = "我是豆豆#51956",
					}, -- [3]
					{
						["role"] = "DAMAGER",
						["name"] = "小不點丶喵-石爪峰",
						["iLvl"] = 418,
						["time"] = 1567846097,
						["class"] = 3,
						["bTag"] = "Sail#5414",
					}, -- [4]
					{
						["role"] = "DAMAGER",
						["name"] = "魂断蓝桥-银月",
						["iLvl"] = 438,
						["time"] = 1567846058,
						["class"] = 12,
						["bTag"] = "鬼泣阿修罗#5983",
					}, -- [5]
					{
						["role"] = "DAMAGER",
						["name"] = "梦中的精灵-伊萨里奥斯",
						["iLvl"] = 420,
						["time"] = 1567846091,
						["class"] = 8,
						["bTag"] = "流浪的猫#5901",
					}, -- [6]
					{
						["role"] = "DAMAGER",
						["name"] = "右岸未央-罗宁",
						["iLvl"] = 444,
						["time"] = 1567846058,
						["class"] = 9,
						["bTag"] = "右岸未央#5283",
					}, -- [7]
					{
						["role"] = "DAMAGER",
						["name"] = "白银猎手-生态船",
						["iLvl"] = 440,
						["time"] = 1567846091,
						["class"] = 12,
						["bTag"] = "白银骑士之首#5290",
					}, -- [8]
					{
						["role"] = "TANK",
						["name"] = "花拳-激流堡",
						["time"] = 1567846091,
						["class"] = 10,
					}, -- [9]
					{
						["role"] = "DAMAGER",
						["name"] = "太阳部落-阿古斯",
						["iLvl"] = 416,
						["time"] = 1567846091,
						["class"] = 12,
						["bTag"] = "张小虎#51978",
					}, -- [10]
				},
				["6-0-16-0"] = {
					{
						["role"] = "HEALER",
						["name"] = "PlayerPDFDGS-阿尔萨斯",
						["iLvl"] = 382,
						["time"] = 1567845700,
						["class"] = 5,
						["bTag"] = "快乐之裤#5192732",
					}, -- [1]
					{
						["role"] = "DAMAGER",
						["name"] = "弗拉基米尔-达文格尔",
						["time"] = 1567845537,
						["class"] = 12,
					}, -- [2]
					{
						["role"] = "DAMAGER",
						["name"] = "悲伤的威尔-伊萨里奥斯",
						["iLvl"] = 351,
						["time"] = 1567845543,
						["class"] = 4,
						["bTag"] = "神威之翼#5320",
					}, -- [3]
					{
						["role"] = "HEALER",
						["name"] = "十方俱灭灬-拉格纳罗斯",
						["iLvl"] = 385,
						["time"] = 1567845568,
						["class"] = 5,
						["bTag"] = "战斗之裤#5225789",
					}, -- [4]
					{
						["role"] = "HEALER",
						["name"] = "美小萨-熊猫酒仙",
						["iLvl"] = 420,
						["time"] = 1567845568,
						["class"] = 7,
						["bTag"] = "慵懒之龟#5168406",
					}, -- [5]
					{
						["role"] = "DAMAGER",
						["name"] = "大羿射曰-熊猫酒仙",
						["time"] = 1567845543,
						["class"] = 3,
					}, -- [6]
					{
						["role"] = "DAMAGER",
						["name"] = "但丁之子-罗宁",
						["iLvl"] = 444,
						["time"] = 1567845568,
						["class"] = 12,
						["bTag"] = "光之军刀#51486",
					}, -- [7]
					{
						["role"] = "HEALER",
						["name"] = "Çèéê-拉格纳罗斯",
						["iLvl"] = 395,
						["time"] = 1567845700,
						["class"] = 5,
						["leader"] = true,
						["bTag"] = "华丽之裤#589922",
					}, -- [8]
					{
						["role"] = "HEALER",
						["name"] = "御风神行-玛诺洛斯",
						["time"] = 1567845556,
						["class"] = 11,
					}, -- [9]
					{
						["role"] = "DAMAGER",
						["name"] = "暗夜魔灵-利刃之拳",
						["time"] = 1567845568,
						["class"] = 12,
					}, -- [10]
					{
						["role"] = "DAMAGER",
						["name"] = "欧洛拉-罗宁",
						["time"] = 1567845568,
						["class"] = 8,
					}, -- [11]
					{
						["role"] = "DAMAGER",
						["name"] = "尼基塔柳-图拉扬",
						["iLvl"] = 418,
						["time"] = 1567845700,
						["class"] = 10,
						["bTag"] = "尼子#5129",
					}, -- [12]
					{
						["role"] = "DAMAGER",
						["name"] = "德西利奥-凯尔萨斯",
						["iLvl"] = 439,
						["time"] = 1567845696,
						["class"] = 11,
						["bTag"] = "李三思#5807",
					}, -- [13]
					{
						["role"] = "HEALER",
						["name"] = "黑珍珠灬-拉格纳罗斯",
						["iLvl"] = 396,
						["time"] = 1567845700,
						["class"] = 5,
						["bTag"] = "暴躁之鼬#5247725",
					}, -- [14]
					{
						["role"] = "DAMAGER",
						["name"] = "大灰狼丶-芬里斯",
						["iLvl"] = 417,
						["time"] = 1567845694,
						["class"] = 9,
						["bTag"] = "SleepyHunte#5810",
					}, -- [15]
					{
						["role"] = "DAMAGER",
						["name"] = "Autiste-白银之手",
						["iLvl"] = 440,
						["time"] = 1567845700,
						["class"] = 8,
						["bTag"] = "炼狱丶#51386",
					}, -- [16]
					{
						["role"] = "DAMAGER",
						["name"] = "孤独的根号三-永夜港",
						["time"] = 1567845694,
						["class"] = 3,
					}, -- [17]
					{
						["role"] = "DAMAGER",
						["name"] = "紫云苍月-暮色森林",
						["iLvl"] = 394,
						["time"] = 1567845700,
						["class"] = 4,
						["bTag"] = "紫云沧月#5953",
					}, -- [18]
				},
			},
			["settings"] = {
				["panelLock"] = true,
				["storage"] = {
					["y"] = 0,
					["point"] = "BOTTOMLEFT",
					["scale"] = 1,
				},
			},
			["version"] = "80200.03",
			["lastSearchCode"] = "9-0-19-0",
			["searchHistoryList"] = {
				"9-0-19-0", -- [1]
				"6-0-0-0", -- [2]
			},
		},
	},
}
