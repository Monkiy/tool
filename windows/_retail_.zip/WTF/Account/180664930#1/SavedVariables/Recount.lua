
RecountDB = {
	["profileKeys"] = {
		["流星逐雨 - 贫瘠之地"] = "流星逐雨 - 贫瘠之地",
		["胖熊 - 远古海滩"] = "胖熊 - 远古海滩",
		["青衣人 - 远古海滩"] = "青衣人 - 远古海滩",
		["沉默的蜗牛 - 远古海滩"] = "沉默的蜗牛 - 远古海滩",
		["蜀川 - 贫瘠之地"] = "蜀川 - 贫瘠之地",
		["节省了空间是 - 盖斯"] = "节省了空间是 - 盖斯",
		["蜀川 - 远古海滩"] = "蜀川 - 远古海滩",
		["流星逐雨 - 远古海滩"] = "流星逐雨 - 远古海滩",
		["灰衣人 - 远古海滩"] = "灰衣人 - 远古海滩",
		["竹筷子 - 贫瘠之地"] = "竹筷子 - 贫瘠之地",
		["熊猫胖胖 - 远古海滩"] = "熊猫胖胖 - 远古海滩",
		["流溯 - 远古海滩"] = "流溯 - 远古海滩",
		["从小就能吃 - 白银之手"] = "从小就能吃 - 白银之手",
	},
	["profiles"] = {
		["流星逐雨 - 贫瘠之地"] = {
			["MainWindow"] = {
				["Position"] = {
					["y"] = -400.9997863769531,
					["h"] = 194.0000457763672,
					["w"] = 280,
					["x"] = 636.0001220703125,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["Locked"] = true,
			["CurDataSet"] = "OverallData",
			["LastInstanceName"] = "暴风城监狱大逃亡",
		},
		["胖熊 - 远古海滩"] = {
			["MainWindow"] = {
				["Position"] = {
					["y"] = -402.0003967285156,
					["x"] = 627.999755859375,
					["w"] = 280,
					["h"] = 194.0000457763672,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["Locked"] = true,
			["LastInstanceName"] = "魔古山宝库",
			["CurDataSet"] = "OverallData",
		},
		["青衣人 - 远古海滩"] = {
			["LastInstanceName"] = "盘牙湖泊：奴隶围栏",
			["MainWindow"] = {
				["Position"] = {
					["y"] = -401.999954223633,
					["h"] = 194.000045776367,
					["w"] = 280,
					["x"] = 628.000122070313,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["CurDataSet"] = "OverallData",
		},
		["沉默的蜗牛 - 远古海滩"] = {
			["MainWindow"] = {
				["Position"] = {
					["y"] = -437.000114440918,
					["x"] = 745.0013427734375,
					["w"] = 280,
					["h"] = 194.0000457763672,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["Locked"] = true,
			["LastInstanceName"] = "潮汐王座",
			["CurDataSet"] = "LastFightData",
			["MainWindowWidth"] = 280,
			["MainWindowHeight"] = 194.000015258789,
		},
		["蜀川 - 贫瘠之地"] = {
			["LastInstanceName"] = "洛丹伦",
			["MainWindow"] = {
				["Position"] = {
					["h"] = 199.9999847412109,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["CurDataSet"] = "OverallData",
		},
		["节省了空间是 - 盖斯"] = {
			["MainWindow"] = {
				["Position"] = {
					["y"] = 29.000244140625,
					["x"] = 570.000244140625,
					["h"] = 199.999984741211,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["CurDataSet"] = "OverallData",
		},
		["蜀川 - 远古海滩"] = {
			["LastInstanceName"] = "盘牙湖泊：奴隶围栏",
			["MainWindow"] = {
				["Position"] = {
					["h"] = 199.999984741211,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["CurDataSet"] = "OverallData",
		},
		["流星逐雨 - 远古海滩"] = {
			["LastInstanceName"] = "战争前线：黑海岸 - 联盟",
			["MainWindow"] = {
				["Position"] = {
					["h"] = 199.9999847412109,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["CurDataSet"] = "OverallData",
		},
		["灰衣人 - 远古海滩"] = {
			["MainWindow"] = {
				["Position"] = {
					["y"] = -399.9998474121094,
					["x"] = 635.001220703125,
					["w"] = 280,
					["h"] = 194.0000457763672,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["MainWindowHeight"] = 194.000015258789,
			["Locked"] = true,
			["CurDataSet"] = "OverallData",
			["MainWindowWidth"] = 280,
			["LastInstanceName"] = "Halls of Valor - Scenario",
		},
		["竹筷子 - 贫瘠之地"] = {
			["LastInstanceName"] = "魔古山宝库",
			["MainWindow"] = {
				["Position"] = {
					["h"] = 199.999984741211,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["CurDataSet"] = "OverallData",
		},
		["熊猫胖胖 - 远古海滩"] = {
			["MainWindow"] = {
				["Position"] = {
					["y"] = -400.9997863769531,
					["x"] = 640.0001220703125,
					["w"] = 280,
					["h"] = 194.0000457763672,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["LastInstanceName"] = "深风峡谷",
			["MainWindowHeight"] = 194.000015258789,
			["CurDataSet"] = "OverallData",
			["MainWindowWidth"] = 280,
			["Locked"] = true,
		},
		["流溯 - 远古海滩"] = {
			["MainWindow"] = {
				["Position"] = {
					["y"] = -436.9998550415039,
					["x"] = 745.000244140625,
					["w"] = 280,
					["h"] = 194.0000457763672,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["Locked"] = true,
			["CurDataSet"] = "OverallData",
			["LastInstanceName"] = "盘牙湖泊：奴隶围栏",
		},
		["从小就能吃 - 白银之手"] = {
			["MainWindow"] = {
				["Position"] = {
					["y"] = -397.0003204345703,
					["x"] = 623.500732421875,
					["w"] = 314.9999694824219,
					["h"] = 200.0000915527344,
				},
			},
			["MainWindowHeight"] = 200.0000915527344,
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["Locked"] = true,
			["LastInstanceName"] = "双子峰",
			["CurDataSet"] = "OverallData",
			["MainWindowWidth"] = 314.9999694824219,
		},
	},
}
