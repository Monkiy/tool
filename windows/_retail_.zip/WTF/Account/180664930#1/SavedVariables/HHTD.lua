
HHTD_SavedVariables = {
	["char"] = {
		["流星逐雨 - 贫瘠之地"] = {
			["settingsMigrated"] = false,
		},
		["胖熊 - 远古海滩"] = {
			["settingsMigrated"] = false,
		},
		["青衣人 - 远古海滩"] = {
			["settingsMigrated"] = false,
		},
		["沉默的蜗牛 - 远古海滩"] = {
			["settingsMigrated"] = false,
		},
		["蜀川 - 贫瘠之地"] = {
			["settingsMigrated"] = false,
		},
		["节省了空间是 - 盖斯"] = {
			["settingsMigrated"] = false,
		},
		["蜀川 - 远古海滩"] = {
			["settingsMigrated"] = false,
		},
		["流星逐雨 - 远古海滩"] = {
			["settingsMigrated"] = false,
		},
		["灰衣人 - 远古海滩"] = {
			["settingsMigrated"] = false,
		},
		["竹筷子 - 贫瘠之地"] = {
			["settingsMigrated"] = false,
		},
		["熊猫胖胖 - 远古海滩"] = {
			["settingsMigrated"] = false,
		},
		["流溯 - 远古海滩"] = {
			["settingsMigrated"] = false,
		},
		["从小就能吃 - 白银之手"] = {
			["settingsMigrated"] = false,
		},
	},
	["global"] = {
		["settingsMigrated"] = false,
		["oldNameEnableState"] = 0,
	},
	["profileKeys"] = {
		["流星逐雨 - 贫瘠之地"] = "流星逐雨 - 贫瘠之地",
		["胖熊 - 远古海滩"] = "胖熊 - 远古海滩",
		["青衣人 - 远古海滩"] = "青衣人 - 远古海滩",
		["沉默的蜗牛 - 远古海滩"] = "沉默的蜗牛 - 远古海滩",
		["蜀川 - 贫瘠之地"] = "蜀川 - 贫瘠之地",
		["节省了空间是 - 盖斯"] = "节省了空间是 - 盖斯",
		["蜀川 - 远古海滩"] = "蜀川 - 远古海滩",
		["流星逐雨 - 远古海滩"] = "流星逐雨 - 远古海滩",
		["灰衣人 - 远古海滩"] = "灰衣人 - 远古海滩",
		["竹筷子 - 贫瘠之地"] = "竹筷子 - 贫瘠之地",
		["熊猫胖胖 - 远古海滩"] = "熊猫胖胖 - 远古海滩",
		["流溯 - 远古海滩"] = "流溯 - 远古海滩",
		["从小就能吃 - 白银之手"] = "从小就能吃 - 白银之手",
	},
	["namespaces"] = {
		["Announcer"] = {
		},
		["CM"] = {
		},
		["NPH"] = {
		},
	},
}
