
DBT_AllPersistentOptions = {
	["Default"] = {
		["DBM"] = {
			["HugeTimerPoint"] = "CENTER",
			["TimerPoint"] = "TOPRIGHT",
			["TimerX"] = -223.000045776367,
			["HugeTimerX"] = 0,
			["TimerY"] = -260,
			["HugeTimerY"] = -120,
		},
	},
}
