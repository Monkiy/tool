
MapsterDB = {
	["namespaces"] = {
		["GroupIcons"] = {
		},
		["Coords"] = {
		},
		["FogClear"] = {
			["profiles"] = {
				["Default"] = {
					["version"] = 2,
				},
			},
		},
		["BattleMap"] = {
		},
	},
	["profileKeys"] = {
		["流星逐雨 - 贫瘠之地"] = "Default",
		["胖熊 - 远古海滩"] = "Default",
		["青衣人 - 远古海滩"] = "Default",
		["沉默的蜗牛 - 远古海滩"] = "Default",
		["蜀川 - 贫瘠之地"] = "Default",
		["节省了空间是 - 盖斯"] = "Default",
		["蜀川 - 远古海滩"] = "Default",
		["流星逐雨 - 远古海滩"] = "Default",
		["灰衣人 - 远古海滩"] = "Default",
		["竹筷子 - 贫瘠之地"] = "Default",
		["熊猫胖胖 - 远古海滩"] = "Default",
		["流溯 - 远古海滩"] = "Default",
		["从小就能吃 - 白银之手"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["hideMapButton"] = true,
			["y"] = -0.999588012695313,
			["x"] = 60.0000267028809,
		},
	},
}
