
MEETINGSTONE_UI_DB = {
	["profileKeys"] = {
		["流星逐雨 - 贫瘠之地"] = "Default",
		["胖熊 - 远古海滩"] = "Default",
		["青衣人 - 远古海滩"] = "Default",
		["沉默的蜗牛 - 远古海滩"] = "Default",
		["蜀川 - 贫瘠之地"] = "Default",
		["节省了空间是 - 盖斯"] = "Default",
		["蜀川 - 远古海滩"] = "Default",
		["流星逐雨 - 远古海滩"] = "Default",
		["竹筷子 - 贫瘠之地"] = "Default",
		["流溯 - 远古海滩"] = "Default",
		["熊猫胖胖 - 远古海滩"] = "Default",
		["灰衣人 - 远古海滩"] = "Default",
		["从小就能吃 - 白银之手"] = "Default",
	},
	["global"] = {
		["spamWord"] = {
			{
				["text"] = "%d+元",
			}, -- [1]
			{
				["pain"] = true,
				["text"] = "5173",
			}, -- [2]
			{
				["pain"] = true,
				["text"] = "lfg:",
			}, -- [3]
			{
				["text"] = "tao.*bao",
			}, -- [4]
			{
				["pain"] = true,
				["text"] = "平台",
			}, -- [5]
			{
				["text"] = "支.*付.*宝",
			}, -- [6]
			{
				["text"] = "淘.*宝",
			}, -- [7]
			{
				["pain"] = true,
				["text"] = "门票",
			}, -- [8]
			["default"] = true,
		},
		["serverDatas"] = {
			["AnnData"] = {
				["data"] = "^1^SAnnData^T^Stitle^S集合石插件积分兑换维护^Scontent^S集合石插件积分兑换功能正在维护中，目前暂时无法正常使用，大家还是可以正常登录战网进行兑换，给大家造成的不便还请谅解。^t^^",
				["new"] = false,
			},
			["ActivitiesData"] = {
				["data"] = "$1$Z$S241`魔兽主播活动`怀旧服：经典旧世地下城（部落）`9月7日（周六）20：00，*`斗鱼TV超人气主播：狂人与風（房间号：303917）*`带你重温怀旧服：经典旧世地下城。*J十五年的羁绊延续，经典怀旧服人气爆表，连续加开服务器也无法阻挡千万玩家的热情。那些深藏在心底感人肺腑的任务，复杂又繁琐的游戏机制，联盟与部落无休止的争斗，是否能勾起你曾经的一幕幕回忆？`http://w.163.com/special/convene-stone/`2`3$$",
			},
			["MallData"] = {
				["data"] = "^1^SMallData^T^S宠物#1^S2006;1500,,每周限量;23713;16943#2007;850,,每周限量;72134;38919^S消耗品#3^S1002;150;46779^S玩具#2^S7001;750,,每周限量;54212;31756#3006;1500,,每月限量;79769#3007;450,,每月限量;69227^t^^",
			},
			["FilterData"] = {
				["data"] = "^1^S![Vv][Xx]^S下单^S![Vv][Ii][Pp]^S付款^S某宝^S站桩^S代打^S陪练^S低价^S便宜^S超低^S老板^S门票^S包车^S![Ww][ⅩXx]^S另接^S全躺^S咨询^S陪打^S看戏^S差价^S可拼^S来壕^S实惠^S价格^S贵宾^S陪聊^S支付^SV信^S单点^S带小号^S无压斤^S有偿^S带你飞^S可淘^S自己捡装^S来各种躺^S卧铺^S根%h*糖^S拼%h*包^S代唰^S代做^S安全效率^S臣卜^S拼车^S可指定^S装备送^^",
				["new"] = true,
			},
		},
		["version"] = "80200.03",
		["ActivityProfiles"] = {
			["破碎海滩"] = {
				["ItemLevel"] = 0,
				["Summary"] = "丝瓦什",
				["MinLevel"] = 110,
				["MaxLevel"] = 110,
				["PvPRating"] = 0,
				["HonorLevel"] = 0,
			},
			["自定义PvE"] = {
				["ItemLevel"] = 0,
				["HonorLevel"] = 0,
			},
			["暴富矿区（史诗）"] = {
				["ItemLevel"] = 325,
				["HonorLevel"] = 0,
			},
			["评级战场"] = {
				["ItemLevel"] = 0,
				["HonorLevel"] = 0,
			},
		},
		["filters"] = {
			[6] = {
				["BossKilled"] = {
					["min"] = 0,
					["max"] = 0,
					["enable"] = false,
				},
				["ItemLevel"] = {
					["min"] = 0,
					["max"] = 0,
					["enable"] = false,
				},
				["Age"] = {
					["min"] = 0,
					["max"] = 0,
					["enable"] = false,
				},
				["Members"] = {
					["min"] = 0,
					["max"] = 0,
					["enable"] = false,
				},
			},
			[9] = {
				["BossKilled"] = {
					["min"] = 0,
					["max"] = 0,
					["enable"] = false,
				},
				["Age"] = {
					["min"] = 0,
					["max"] = 0,
					["enable"] = false,
				},
				["Members"] = {
					["min"] = 0,
					["max"] = 0,
					["enable"] = false,
				},
				["ItemLevel"] = {
					["min"] = 0,
					["max"] = 0,
					["enable"] = false,
				},
			},
		},
	},
}
