
BattlefieldMinimapOptions = {
	["locked"] = true,
	["opacity"] = 0.699999988079071,
	["position"] = {
		["y"] = 415.999847412109,
		["x"] = 89.4999313354492,
	},
	["showPlayers"] = true,
}
