
MEETINGSTONE_CHARACTER_DB = {
	["profileKeys"] = {
		["流星逐雨 - 贫瘠之地"] = "流星逐雨 - 贫瘠之地",
		["蜀川 - 远古海滩"] = "蜀川 - 远古海滩",
		["灰衣人 - 远古海滩"] = "灰衣人 - 远古海滩",
	},
	["profiles"] = {
		["流星逐雨 - 贫瘠之地"] = {
			["version"] = "70300.11",
			["searchHistoryList"] = {
				"6-0-0-0", -- [1]
			},
			["lastSearchValue"] = "6-0-0-0",
			["settings"] = {
				["panelLock"] = true,
				["storage"] = {
					["y"] = 0,
					["point"] = "BOTTOMLEFT",
					["scale"] = 1,
				},
			},
			["chatGroupListening"] = {
				["APP_WHISPER"] = {
					nil, -- [1]
					nil, -- [2]
					false, -- [3]
					false, -- [4]
					false, -- [5]
					false, -- [6]
					false, -- [7]
					false, -- [8]
					false, -- [9]
					false, -- [10]
				},
			},
		},
		["蜀川 - 远古海滩"] = {
			["version"] = "70300.11",
			["settings"] = {
				["panelLock"] = true,
				["storage"] = {
					["y"] = 0,
					["point"] = "BOTTOMLEFT",
					["scale"] = 1,
				},
			},
			["searchHistoryList"] = {
				"6-0-0-0", -- [1]
			},
			["lastSearchValue"] = "6-0-0-0",
			["chatGroupListening"] = {
				["APP_WHISPER"] = {
					nil, -- [1]
					nil, -- [2]
					false, -- [3]
					false, -- [4]
					false, -- [5]
					false, -- [6]
					false, -- [7]
					false, -- [8]
					false, -- [9]
					false, -- [10]
				},
			},
		},
		["灰衣人 - 远古海滩"] = {
			["version"] = "70300.11",
			["settings"] = {
				["panelLock"] = true,
				["storage"] = {
					["y"] = 0,
					["point"] = "BOTTOMLEFT",
					["scale"] = 1,
				},
			},
			["searchHistoryList"] = {
				"6-0-0-0", -- [1]
			},
			["lastSearchValue"] = "6-0-0-0",
			["worldQuestHelp"] = true,
			["chatGroupListening"] = {
				["APP_WHISPER"] = {
					nil, -- [1]
					nil, -- [2]
					false, -- [3]
					false, -- [4]
					false, -- [5]
					false, -- [6]
					false, -- [7]
					false, -- [8]
					false, -- [9]
					false, -- [10]
				},
			},
		},
	},
}
