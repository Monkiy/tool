
DBMWorldDMF_SavedStats = nil
