
BattlefieldMapOptions = {
	["locked"] = true,
	["opacity"] = 0.7,
	["position"] = {
		["y"] = 428.000183105469,
		["x"] = 94.5001068115234,
	},
	["showPlayers"] = true,
}
