
MEETINGSTONE_CHARACTER_DB = {
	["profileKeys"] = {
		["胖熊 - 远古海滩"] = "胖熊 - 远古海滩",
		["灰衣人 - 远古海滩"] = "灰衣人 - 远古海滩",
		["熊猫胖胖 - 远古海滩"] = "熊猫胖胖 - 远古海滩",
	},
	["profiles"] = {
		["胖熊 - 远古海滩"] = {
			["version"] = "80200.03",
			["settings"] = {
				["panelLock"] = true,
				["storage"] = {
					["y"] = 0,
					["point"] = "BOTTOMLEFT",
					["scale"] = 1,
				},
			},
			["lastSearchCode"] = "9-0-19-0",
			["searchInputHistory"] = {
				["9-0-19-0"] = {
					"胜", -- [1]
				},
			},
			["worldQuestHelp"] = true,
			["chatGroupListening"] = {
				["APP_WHISPER"] = {
					nil, -- [1]
					nil, -- [2]
					nil, -- [3]
					false, -- [4]
					false, -- [5]
					false, -- [6]
					false, -- [7]
					false, -- [8]
					false, -- [9]
					false, -- [10]
				},
			},
		},
		["灰衣人 - 远古海滩"] = {
			["version"] = "70300.11",
			["settings"] = {
				["panelLock"] = true,
				["storage"] = {
					["y"] = 0,
					["point"] = "BOTTOMLEFT",
					["scale"] = 1,
				},
			},
			["searchHistoryList"] = {
				"6-0-0-0", -- [1]
			},
			["lastSearchValue"] = "6-0-0-0",
			["worldQuestHelp"] = true,
			["chatGroupListening"] = {
				["APP_WHISPER"] = {
					nil, -- [1]
					nil, -- [2]
					false, -- [3]
					false, -- [4]
					false, -- [5]
					false, -- [6]
					false, -- [7]
					false, -- [8]
					false, -- [9]
					false, -- [10]
				},
			},
		},
		["熊猫胖胖 - 远古海滩"] = {
			["version"] = "80000.01",
			["settings"] = {
				["panelLock"] = true,
				["storage"] = {
					["y"] = 0,
					["point"] = "BOTTOMLEFT",
					["scale"] = 1,
				},
			},
			["lastSearchCode"] = "3-0-458-0",
			["recent"] = {
				["1-247-648-0"] = {
					{
						["role"] = "HEALER",
						["name"] = "勇敢的虫虫-艾萨拉",
						["iLvl"] = 332,
						["time"] = 1535189136,
						["class"] = 5,
						["leader"] = true,
						["bTag"] = "勇敢的虫虫#5937",
					}, -- [1]
					{
						["role"] = "TANK",
						["name"] = "終極歐巴桑-奥达曼",
						["iLvl"] = 306,
						["class"] = 1,
						["time"] = 1535189047,
						["bTag"] = "終極歐巴桑#5129",
					}, -- [2]
					{
						["role"] = "DAMAGER",
						["name"] = "情若动心则痛-贫瘠之地",
						["iLvl"] = 338,
						["class"] = 3,
						["time"] = 1535188994,
						["bTag"] = "无聊玩玩#5824",
					}, -- [3]
					{
						["time"] = 1535188994,
						["class"] = 6,
						["name"] = "撒切尔-火烟之谷",
						["role"] = "TANK",
					}, -- [4]
					{
						["time"] = 1535189136,
						["class"] = 8,
						["name"] = "饼饼猫-血色十字军",
						["role"] = "DAMAGER",
					}, -- [5]
					{
						["role"] = "DAMAGER",
						["name"] = "烟雨轻风-白银之手",
						["iLvl"] = 331,
						["class"] = 1,
						["time"] = 1535189128,
						["bTag"] = "David#51417",
					}, -- [6]
					{
						["role"] = "TANK",
						["name"] = "龍渊寒-海克泰尔",
						["iLvl"] = 325,
						["class"] = 11,
						["time"] = 1535188988,
						["bTag"] = "老司机#55925",
					}, -- [7]
					{
						["time"] = 1535188963,
						["class"] = 4,
						["name"] = "风伶-主宰之剑",
						["role"] = "DAMAGER",
					}, -- [8]
					{
						["role"] = "HEALER",
						["name"] = "骨科老中医-国王之谷",
						["iLvl"] = 322,
						["class"] = 2,
						["time"] = 1535188956,
						["bTag"] = "tomcong#5564",
					}, -- [9]
					{
						["role"] = "HEALER",
						["name"] = "番茄小土豆-回音山",
						["iLvl"] = 340,
						["class"] = 11,
						["time"] = 1535188963,
						["bTag"] = "懂比利就是弯#5722",
					}, -- [10]
					{
						["role"] = "TANK",
						["name"] = "幽冥之下-轻风之语",
						["iLvl"] = 343,
						["class"] = 6,
						["time"] = 1535188992,
						["bTag"] = "风暴烈酒#5916",
					}, -- [11]
					{
						["role"] = "DAMAGER",
						["name"] = "黑色的海-月神殿",
						["iLvl"] = 337,
						["class"] = 6,
						["time"] = 1535189065,
						["bTag"] = "黑色的海#5413",
					}, -- [12]
					{
						["role"] = "DAMAGER",
						["name"] = "圣光帕拉丁-利刃之拳",
						["iLvl"] = 333,
						["class"] = 2,
						["time"] = 1535189025,
						["bTag"] = "没谱的老金#5100",
					}, -- [13]
					{
						["time"] = 1535189136,
						["class"] = 9,
						["name"] = "湮灭无影-守护之剑",
						["role"] = "DAMAGER",
					}, -- [14]
					{
						["role"] = "DAMAGER",
						["name"] = "摇曳的大领主-罗宁",
						["iLvl"] = 330,
						["class"] = 2,
						["time"] = 1535188963,
						["bTag"] = "旅店老板的女儿#5730",
					}, -- [15]
					{
						["role"] = "DAMAGER",
						["name"] = "逐风追梦-贫瘠之地",
						["iLvl"] = 302,
						["class"] = 3,
						["time"] = 1535189000,
						["bTag"] = "逐风#5531",
					}, -- [16]
					{
						["time"] = 1535189065,
						["class"] = 2,
						["name"] = "Spadesq-自由之风",
						["role"] = "DAMAGER",
					}, -- [17]
					{
						["role"] = "HEALER",
						["name"] = "乱武-银月",
						["iLvl"] = 329,
						["class"] = 7,
						["time"] = 1535188990,
						["bTag"] = "竹林风暴#5356",
					}, -- [18]
					{
						["role"] = "DAMAGER",
						["name"] = "初卩心-安苏",
						["iLvl"] = 322,
						["class"] = 2,
						["time"] = 1535189000,
						["bTag"] = "骗钱骗点卡#5822",
					}, -- [19]
					{
						["role"] = "TANK",
						["name"] = "愤怒的瓦里安-克洛玛古斯",
						["iLvl"] = 339,
						["class"] = 1,
						["time"] = 1535188992,
						["bTag"] = "风沙梦魇#5365",
					}, -- [20]
					{
						["time"] = 1535189014,
						["class"] = 3,
						["name"] = "昕昕丶念念-伊瑟拉",
						["role"] = "DAMAGER",
					}, -- [21]
					{
						["time"] = 1535189065,
						["class"] = 8,
						["name"] = "纟屯女吴乐-主宰之剑",
						["role"] = "DAMAGER",
					}, -- [22]
					{
						["role"] = "DAMAGER",
						["name"] = "无名酱-塞拉摩",
						["iLvl"] = 340,
						["class"] = 3,
						["time"] = 1535188988,
						["bTag"] = "踟躇#5460",
					}, -- [23]
					{
						["role"] = "DAMAGER",
						["name"] = "我竟然有尾巴-永夜港",
						["iLvl"] = 338,
						["class"] = 7,
						["time"] = 1535188986,
						["bTag"] = "云扬#5591",
					}, -- [24]
					{
						["time"] = 1535188986,
						["class"] = 11,
						["name"] = "许是了然心-末日行者",
						["role"] = "DAMAGER",
					}, -- [25]
					{
						["time"] = 1535189136,
						["class"] = 6,
						["name"] = "白色的小河马-阿古斯",
						["role"] = "TANK",
					}, -- [26]
					{
						["role"] = "DAMAGER",
						["name"] = "秒杀哥他亲哥-回音山",
						["iLvl"] = 337,
						["class"] = 1,
						["time"] = 1535189035,
						["bTag"] = "方便面#51524",
					}, -- [27]
					{
						["time"] = 1535188994,
						["class"] = 10,
						["name"] = "阳宝山的武僧-迅捷微风",
						["role"] = "DAMAGER",
					}, -- [28]
					{
						["role"] = "TANK",
						["name"] = "陌刀-拉贾克斯",
						["iLvl"] = 337,
						["class"] = 1,
						["time"] = 1535188986,
						["bTag"] = "冰玫瑰#5190",
					}, -- [29]
					{
						["time"] = 1535188948,
						["class"] = 8,
						["name"] = "最萌的天使-破碎岭",
						["role"] = "DAMAGER",
					}, -- [30]
					{
						["role"] = "DAMAGER",
						["name"] = "阡山暮雪-月光林地",
						["iLvl"] = 336,
						["class"] = 3,
						["time"] = 1535188963,
						["bTag"] = "windhunter#5757",
					}, -- [31]
					{
						["time"] = 1535189136,
						["class"] = 2,
						["name"] = "魅昧之瞋-玛多兰",
						["role"] = "TANK",
					}, -- [32]
					{
						["time"] = 1535188948,
						["class"] = 1,
						["name"] = "七月二十九号-金色平原",
						["role"] = "DAMAGER",
					}, -- [33]
					{
						["role"] = "DAMAGER",
						["name"] = "扬情焕爱-影牙要塞",
						["iLvl"] = 340,
						["class"] = 2,
						["time"] = 1535188986,
						["bTag"] = "永远的爱情#5816",
					}, -- [34]
					{
						["role"] = "DAMAGER",
						["name"] = "空间之门-灰谷",
						["iLvl"] = 339,
						["class"] = 9,
						["time"] = 1535189055,
						["bTag"] = "卡雷莉斯任歌#5536",
					}, -- [35]
					{
						["role"] = "DAMAGER",
						["name"] = "淡香疏影-海达希亚",
						["iLvl"] = 299,
						["class"] = 8,
						["time"] = 1535189004,
						["bTag"] = "背氧气的鱼#5368",
					}, -- [36]
					{
						["role"] = "DAMAGER",
						["name"] = "叶心安的胖次-远古海滩",
						["iLvl"] = 342,
						["class"] = 9,
						["time"] = 1535189136,
						["bTag"] = "阎胖子#5975",
					}, -- [37]
					{
						["role"] = "DAMAGER",
						["name"] = "Watering-奥蕾莉亚",
						["iLvl"] = 343,
						["class"] = 8,
						["time"] = 1535189136,
						["bTag"] = "Watering#5332",
					}, -- [38]
					{
						["role"] = "DAMAGER",
						["name"] = "萨伦-万色星辰",
						["iLvl"] = 324,
						["class"] = 2,
						["time"] = 1535189000,
						["bTag"] = "萨伦#5103",
					}, -- [39]
					{
						["role"] = "DAMAGER",
						["name"] = "一粒乛尘埃-主宰之剑",
						["iLvl"] = 323,
						["class"] = 4,
						["time"] = 1535189004,
						["bTag"] = "雷霆战神#5652",
					}, -- [40]
					{
						["role"] = "DAMAGER",
						["name"] = "失却回忆-德拉诺",
						["iLvl"] = 317,
						["class"] = 9,
						["time"] = 1535189045,
						["bTag"] = "失却回忆#5122",
					}, -- [41]
					{
						["role"] = "TANK",
						["name"] = "轩辕琪琪-拉贾克斯",
						["iLvl"] = 297,
						["time"] = 1535212716,
						["class"] = 6,
						["leader"] = true,
						["bTag"] = "笨笨#5451",
					}, -- [42]
					{
						["role"] = "DAMAGER",
						["name"] = "巴尔萨泽-石爪峰",
						["iLvl"] = 328,
						["time"] = 1535212722,
						["class"] = 8,
						["leader"] = true,
						["bTag"] = "巴尔萨泽#5953",
					}, -- [43]
					{
						["role"] = "DAMAGER",
						["name"] = "尛丶玖兒-主宰之剑",
						["iLvl"] = 330,
						["class"] = 4,
						["time"] = 1535212710,
						["bTag"] = "小玖#5888",
					}, -- [44]
					{
						["time"] = 1535212700,
						["class"] = 9,
						["name"] = "夜雨逆位愚者-回音山",
						["role"] = "DAMAGER",
					}, -- [45]
					{
						["role"] = "TANK",
						["name"] = "挥刀蛋蛋疼-熊猫酒仙",
						["iLvl"] = 321,
						["class"] = 6,
						["time"] = 1535212706,
						["bTag"] = "lidaiwei#5482",
					}, -- [46]
					{
						["role"] = "DAMAGER",
						["name"] = "橘子汁-火烟之谷",
						["iLvl"] = 339,
						["class"] = 9,
						["time"] = 1535212710,
						["bTag"] = "小胖子耍大刀#5407",
					}, -- [47]
					{
						["role"] = "DAMAGER",
						["name"] = "圣光大肉包-拉文凯斯",
						["iLvl"] = 341,
						["class"] = 6,
						["time"] = 1535212708,
						["bTag"] = "徐伟伟#5150",
					}, -- [48]
					{
						["role"] = "DAMAGER",
						["name"] = "盐焗萨摩耶-普罗德摩",
						["iLvl"] = 325,
						["class"] = 6,
						["time"] = 1535212706,
						["bTag"] = "面包特好吃#5428",
					}, -- [49]
					{
						["role"] = "DAMAGER",
						["name"] = "痴情狗-自由之风",
						["iLvl"] = 339,
						["class"] = 1,
						["time"] = 1535212704,
						["bTag"] = "解超#5697",
					}, -- [50]
					{
						["role"] = "DAMAGER",
						["name"] = "村头毒姐-末日行者",
						["iLvl"] = 337,
						["class"] = 7,
						["time"] = 1535212700,
						["bTag"] = "幽灵飘雪#5615",
					}, -- [51]
					{
						["role"] = "DAMAGER",
						["name"] = "朵朵魔法少女-壁炉谷",
						["iLvl"] = 339,
						["class"] = 8,
						["time"] = 1535212716,
						["bTag"] = "兔子洞里的爱丽丝#5934",
					}, -- [52]
					{
						["role"] = "DAMAGER",
						["name"] = "青阳丶-雷斧堡垒",
						["iLvl"] = 337,
						["class"] = 12,
						["time"] = 1535212761,
						["bTag"] = "撕心裂肺#5172",
					}, -- [53]
					{
						["role"] = "DAMAGER",
						["name"] = "此去溪山远-玛诺洛斯",
						["iLvl"] = 323,
						["class"] = 2,
						["time"] = 1535212714,
						["bTag"] = "喵星人#5622",
					}, -- [54]
					{
						["role"] = "DAMAGER",
						["name"] = "白茶相依-末日行者",
						["iLvl"] = 307,
						["class"] = 3,
						["time"] = 1535212706,
						["bTag"] = "未闻花詺#5784",
					}, -- [55]
					{
						["role"] = "DAMAGER",
						["name"] = "不客气-盖斯",
						["iLvl"] = 325,
						["class"] = 1,
						["time"] = 1535212724,
						["bTag"] = "山口山#5800",
					}, -- [56]
					{
						["role"] = "HEALER",
						["name"] = "琉璃药师-破碎岭",
						["iLvl"] = 317,
						["class"] = 5,
						["time"] = 1535212730,
						["bTag"] = "Happyrogue#578617",
					}, -- [57]
					{
						["role"] = "DAMAGER",
						["name"] = "花莫离-通灵学院",
						["iLvl"] = 287,
						["class"] = 11,
						["time"] = 1535212714,
						["bTag"] = "葵葵#5941",
					}, -- [58]
					{
						["time"] = 1535212773,
						["class"] = 2,
						["name"] = "七七我心-伊瑟拉",
						["role"] = "HEALER",
					}, -- [59]
					{
						["role"] = "DAMAGER",
						["name"] = "司徒云麾-月光林地",
						["iLvl"] = 325,
						["class"] = 4,
						["time"] = 1535212702,
						["bTag"] = "司徒云麾#5461",
					}, -- [60]
					{
						["role"] = "DAMAGER",
						["name"] = "玉兰晶晶同学-伊萨里奥斯",
						["iLvl"] = 301,
						["class"] = 11,
						["time"] = 1535212773,
						["bTag"] = "汤汤水水#51138",
					}, -- [61]
					{
						["role"] = "DAMAGER",
						["name"] = "瓦雷西亚-贫瘠之地",
						["iLvl"] = 318,
						["class"] = 12,
						["time"] = 1535212716,
						["bTag"] = "rpal#5410",
					}, -- [62]
					{
						["time"] = 1535212724,
						["class"] = 6,
						["name"] = "天辰欣-泰兰德",
						["role"] = "DAMAGER",
					}, -- [63]
					{
						["role"] = "TANK",
						["name"] = "笨德埃枚-主宰之剑",
						["iLvl"] = 330,
						["class"] = 11,
						["time"] = 1535212706,
						["bTag"] = "笨德埃魔#5558",
					}, -- [64]
					{
						["role"] = "DAMAGER",
						["name"] = "百絲不得騎姐-安苏",
						["iLvl"] = 323,
						["class"] = 3,
						["time"] = 1535212773,
						["bTag"] = "和光同尘#5474",
					}, -- [65]
					{
						["role"] = "TANK",
						["name"] = "马克偲-凯尔萨斯",
						["iLvl"] = 334,
						["class"] = 2,
						["time"] = 1535212706,
						["bTag"] = "MaX#53556",
					}, -- [66]
					{
						["time"] = 1535212773,
						["class"] = 1,
						["name"] = "得瑟的小宝-雷霆号角",
						["role"] = "DAMAGER",
					}, -- [67]
					{
						["role"] = "DAMAGER",
						["name"] = "欣风-麦迪文",
						["iLvl"] = 325,
						["class"] = 11,
						["time"] = 1535212700,
						["bTag"] = "欣风#5649",
					}, -- [68]
					{
						["role"] = "DAMAGER",
						["name"] = "板凳太高-罗宁",
						["iLvl"] = 337,
						["class"] = 9,
						["time"] = 1535212761,
						["bTag"] = "逐梦者一一铭#5721",
					}, -- [69]
					{
						["role"] = "TANK",
						["name"] = "九鬼寻欢-加里索斯",
						["iLvl"] = 329,
						["class"] = 1,
						["time"] = 1535212722,
						["bTag"] = "Allen#5723",
					}, -- [70]
					{
						["time"] = 1535212708,
						["class"] = 12,
						["name"] = "巴芭菲特-伊萨里奥斯",
						["role"] = "DAMAGER",
					}, -- [71]
					{
						["time"] = 1535212726,
						["class"] = 7,
						["name"] = "安然如命-伊萨里奥斯",
						["role"] = "DAMAGER",
					}, -- [72]
					{
						["role"] = "HEALER",
						["name"] = "罗克索夫斯基-石锤",
						["iLvl"] = 318,
						["class"] = 5,
						["time"] = 1535212773,
						["bTag"] = "Yobo#5854",
					}, -- [73]
					{
						["role"] = "DAMAGER",
						["name"] = "Anfield-逐日者",
						["iLvl"] = 333,
						["class"] = 1,
						["time"] = 1535212706,
						["bTag"] = "人见人爱张益达#5503",
					}, -- [74]
					{
						["time"] = 1535212773,
						["class"] = 5,
						["name"] = "Eleanora-巴尔古恩",
						["role"] = "HEALER",
					}, -- [75]
					{
						["role"] = "DAMAGER",
						["name"] = "谜团的爱-贫瘠之地",
						["iLvl"] = 330,
						["class"] = 7,
						["time"] = 1535212773,
						["bTag"] = "nerazzurri#5296",
					}, -- [76]
					{
						["role"] = "DAMAGER",
						["name"] = "咪理总之犀利-奥杜尔",
						["iLvl"] = 324,
						["class"] = 12,
						["time"] = 1535212773,
						["bTag"] = "fanrkie#5462",
					}, -- [77]
					{
						["role"] = "DAMAGER",
						["name"] = "梦回雨季-生态船",
						["iLvl"] = 329,
						["class"] = 8,
						["time"] = 1535212773,
						["bTag"] = "徐徐#5330",
					}, -- [78]
					{
						["role"] = "TANK",
						["name"] = "圣光女骑-守护之剑",
						["iLvl"] = 316,
						["class"] = 2,
						["time"] = 1535212773,
						["bTag"] = "BattleOoze#5605",
					}, -- [79]
					{
						["role"] = "DAMAGER",
						["name"] = "雁过长空-爱斯特纳",
						["iLvl"] = 315,
						["class"] = 8,
						["time"] = 1535212773,
						["bTag"] = "天刚破晓#5843",
					}, -- [80]
					{
						["role"] = "TANK",
						["name"] = "逍遥月-格瑞姆巴托",
						["iLvl"] = 334,
						["class"] = 11,
						["time"] = 1535212773,
						["bTag"] = "月月随风#5615",
					}, -- [81]
					{
						["role"] = "TANK",
						["name"] = "丨噬血狮子丨-雷斧堡垒",
						["iLvl"] = 341,
						["class"] = 6,
						["time"] = 1535212773,
						["bTag"] = "恐怖狮子#51543",
					}, -- [82]
					{
						["role"] = "TANK",
						["name"] = "小坡孩-雷斧堡垒",
						["iLvl"] = 339,
						["class"] = 6,
						["time"] = 1535212773,
						["bTag"] = "巨硕之斧#59987",
					}, -- [83]
					{
						["role"] = "DAMAGER",
						["name"] = "钢铁之心-范达尔鹿盔",
						["class"] = 1,
						["leader"] = true,
						["time"] = 1535212746,
					}, -- [84]
					{
						["role"] = "DAMAGER",
						["name"] = "香蕉可乐-暗影之月",
						["class"] = 4,
						["leader"] = true,
						["time"] = 1535212773,
					}, -- [85]
					{
						["role"] = "DAMAGER",
						["name"] = "小小垚丶-白银之手",
						["iLvl"] = 303,
						["class"] = 4,
						["time"] = 1535212773,
						["bTag"] = "刘刘刘#5601",
					}, -- [86]
					{
						["time"] = 1535212773,
						["class"] = 4,
						["name"] = "底皮埃斯-末日行者",
						["role"] = "DAMAGER",
					}, -- [87]
					{
						["role"] = "HEALER",
						["name"] = "僞裝-扎拉赞恩",
						["iLvl"] = 330,
						["class"] = 11,
						["time"] = 1535212773,
						["bTag"] = "SneakyTurtle#54695",
					}, -- [88]
					{
						["role"] = "DAMAGER",
						["name"] = "嘀哒-扎拉赞恩",
						["iLvl"] = 325,
						["class"] = 12,
						["time"] = 1535212773,
						["bTag"] = "SneakyTurtle#54695",
					}, -- [89]
					{
						["role"] = "TANK",
						["name"] = "吉尔红血球-幽暗沼泽",
						["iLvl"] = 290,
						["class"] = 6,
						["time"] = 1535212773,
						["bTag"] = "简繁#5863",
					}, -- [90]
					{
						["role"] = "DAMAGER",
						["name"] = "小小爱殇-白银之手",
						["iLvl"] = 338,
						["class"] = 8,
						["time"] = 1535212773,
						["bTag"] = "小小爱殇#5394",
					}, -- [91]
					{
						["role"] = "DAMAGER",
						["name"] = "拭锋芒-霜之哀伤",
						["iLvl"] = 338,
						["class"] = 6,
						["time"] = 1535212773,
						["bTag"] = "拭锋芒#51249",
					}, -- [92]
					{
						["time"] = 1535212773,
						["class"] = 4,
						["name"] = "恐怖的大胡子-白银之手",
						["role"] = "DAMAGER",
					}, -- [93]
					{
						["role"] = "TANK",
						["name"] = "威廉姆邪爪-泰兰德",
						["iLvl"] = 339,
						["class"] = 6,
						["time"] = 1535212773,
						["bTag"] = "Real#5529",
					}, -- [94]
					{
						["role"] = "HEALER",
						["name"] = "Vce-火喉",
						["iLvl"] = 326,
						["class"] = 5,
						["time"] = 1535212773,
						["bTag"] = "苍崎青子#5897",
					}, -- [95]
					{
						["role"] = "DAMAGER",
						["name"] = "风雨陌路-回音山",
						["iLvl"] = 338,
						["class"] = 4,
						["time"] = 1535212773,
						["bTag"] = "鬼谷门生#5211",
					}, -- [96]
					{
						["time"] = 1535212773,
						["class"] = 11,
						["name"] = "Moonillusion-克尔苏加德",
						["role"] = "DAMAGER",
					}, -- [97]
					{
						["role"] = "DAMAGER",
						["name"] = "罗罗亚星辰-闪电之刃",
						["iLvl"] = 324,
						["class"] = 9,
						["time"] = 1535212773,
						["bTag"] = "繁星之眠#5104",
					}, -- [98]
					{
						["time"] = 1535212773,
						["class"] = 8,
						["name"] = "乄寿司乄-银松森林",
						["role"] = "DAMAGER",
					}, -- [99]
					{
						["time"] = 1535212773,
						["class"] = 1,
						["name"] = "乾枯大地-奥特兰克",
						["role"] = "TANK",
					}, -- [100]
					{
						["time"] = 1535212773,
						["class"] = 8,
						["name"] = "Geedin-末日行者",
						["role"] = "DAMAGER",
					}, -- [101]
					{
						["time"] = 1535212773,
						["class"] = 3,
						["name"] = "飞卫-安威玛尔",
						["role"] = "DAMAGER",
					}, -- [102]
					{
						["time"] = 1535212773,
						["class"] = 8,
						["name"] = "丷初丶訫丷-末日行者",
						["role"] = "DAMAGER",
					}, -- [103]
					{
						["time"] = 1535212773,
						["class"] = 4,
						["name"] = "碳氢化合物-守护之剑",
						["role"] = "DAMAGER",
					}, -- [104]
				},
			},
			["searchHistoryList"] = {
				"3-0-458-0", -- [1]
				"9-0-19-0", -- [2]
				"6-0-0-0", -- [3]
			},
			["chatGroupListening"] = {
				["APP_WHISPER"] = {
					nil, -- [1]
					nil, -- [2]
					false, -- [3]
					false, -- [4]
					false, -- [5]
					false, -- [6]
					false, -- [7]
					false, -- [8]
					false, -- [9]
					false, -- [10]
				},
			},
		},
	},
}
