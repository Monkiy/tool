
BattlefieldMapOptions = {
	["locked"] = true,
	["opacity"] = 0.7,
	["showPlayers"] = true,
	["position"] = {
		["y"] = 470.0001525878906,
		["x"] = 91.49996185302734,
	},
}
