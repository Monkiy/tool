
DBM_UsedProfile = "Default"
DBM_UseDualProfile = true
DBM_CharSavedRevision = 17517
