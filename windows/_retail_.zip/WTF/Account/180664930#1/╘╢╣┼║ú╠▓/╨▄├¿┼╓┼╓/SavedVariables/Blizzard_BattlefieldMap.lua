
BattlefieldMapOptions = {
	["locked"] = true,
	["opacity"] = 0.7,
	["showPlayers"] = true,
	["position"] = {
		["y"] = 450.9999694824219,
		["x"] = 151.4998474121094,
	},
}
