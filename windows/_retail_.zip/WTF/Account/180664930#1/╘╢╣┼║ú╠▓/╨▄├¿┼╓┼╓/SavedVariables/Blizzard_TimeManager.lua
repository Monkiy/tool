
BlizzardStopwatchOptions = {
	["position"] = {
		["y"] = 224.9995574951172,
		["x"] = 268.9994812011719,
	},
}
