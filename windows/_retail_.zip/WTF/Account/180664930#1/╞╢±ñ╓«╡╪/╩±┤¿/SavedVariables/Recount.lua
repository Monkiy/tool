
RecountPerCharDB = {
	["version"] = "1.3",
	["combatants"] = {
		["蜀川"] = {
			["GUID"] = "Player-1950-053E7FDA",
			["LastEventHealth"] = {
				28100, -- [1]
				28100, -- [2]
				28100, -- [3]
				28100, -- [4]
				28100, -- [5]
				28100, -- [6]
				28100, -- [7]
				28100, -- [8]
				28100, -- [9]
				28100, -- [10]
				28100, -- [11]
				28100, -- [12]
				28100, -- [13]
				28100, -- [14]
				28100, -- [15]
				28100, -- [16]
				28100, -- [17]
				28100, -- [18]
				28100, -- [19]
				28100, -- [20]
				28100, -- [21]
				28100, -- [22]
				28100, -- [23]
				28100, -- [24]
				28100, -- [25]
				28100, -- [26]
				28100, -- [27]
				28100, -- [28]
				28100, -- [29]
				28100, -- [30]
				28100, -- [31]
				28100, -- [32]
				28100, -- [33]
				28100, -- [34]
				28100, -- [35]
				28100, -- [36]
				28100, -- [37]
				28100, -- [38]
				28100, -- [39]
				28100, -- [40]
				28100, -- [41]
				28100, -- [42]
				28100, -- [43]
				28100, -- [44]
				28100, -- [45]
				28100, -- [46]
				28100, -- [47]
				28100, -- [48]
				28100, -- [49]
				28100, -- [50]
			},
			["LastAttackedBy"] = "Environment",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["RageGain"] = {
					1841.80000054836, -- [1]
				},
				["HOT_Time"] = {
					141, -- [1]
				},
				["ActiveTime"] = {
					320.14, -- [1]
				},
				["TimeDamage"] = {
					320.14, -- [1]
				},
				["Overhealing"] = {
					43702, -- [1]
				},
				["DamageTaken"] = {
					2687, -- [1]
				},
				["Damage"] = {
					12188073, -- [1]
				},
			},
			["enClass"] = "WARRIOR",
			["unit"] = "蜀川",
			["level"] = 110,
			["LastDamageAbility"] = "Falling",
			["LastFightIn"] = 20,
			["LastDamageTaken"] = 2687,
			["type"] = "Self",
			["FightsSaved"] = 5,
			["LastAbility"] = 8096.837,
			["UnitLockout"] = 286363.477,
			["Owner"] = false,
			["TimeLast"] = {
				["TimeDamage"] = 13396.456,
				["RageGain"] = 13396.456,
				["HOT_Time"] = 286628.478,
				["ActiveTime"] = 13396.456,
				["Overhealing"] = 286628.478,
				["OVERALL"] = 13396.456,
				["DamageTaken"] = 9159.460000000001,
				["Damage"] = 13396.456,
			},
			["NextEventNum"] = 38,
			["LastDamageTime"] = 13397.171,
			["LastEvents"] = {
				"残冠蛮徒 肉搏 蜀川 Miss (1)", -- [1]
				"蜀川 旋风斩 残冠蛮徒 Crit -49346 (Physical)", -- [2]
				"蜀川 肉搏 笨拙的地狱野猪 Hit -170259 (Physical)", -- [3]
				"笨拙的地狱野猪 肉搏 蜀川 Miss (1)", -- [4]
				"蜀川 旋风斩 笨拙的地狱野猪 Hit -27414 (Physical)", -- [5]
				"笨拙的地狱野猪 燃烧之刺 蜀川 Resist (Fire)", -- [6]
				"蜀川 冲锋 笨拙的地狱野猪 Crit -89811 (Physical)", -- [7]
				"笨拙的地狱野猪 燃烧之刺 蜀川 Resist (Fire)", -- [8]
				"蜀川 旋风斩 笨拙的地狱野猪 Crit -54830 (Physical)", -- [9]
				"笨拙的地狱野猪 燃烧之刺 蜀川 Resist (Fire)", -- [10]
				"蜀川 旋风斩 笨拙的地狱野猪 Hit -27523 (Physical)", -- [11]
				"笨拙的地狱野猪 燃烧之刺 蜀川 Resist (Fire)", -- [12]
				"蜀川 肉搏 笨拙的地狱野猪 Crit -425484 (Physical)", -- [13]
				"笨拙的地狱野猪 燃烧之刺 蜀川 Resist (Fire)", -- [14]
				"蜀川 肉搏 笨拙的地狱野猪 Crit -345824 (Physical)", -- [15]
				"笨拙的地狱野猪 肉搏 蜀川 Miss (1)", -- [16]
				"蜀川 旋风斩 笨拙的地狱野猪 Hit -27523 (Physical)", -- [17]
				"笨拙的地狱野猪 燃烧之刺 蜀川 Resist (Fire)", -- [18]
				"蜀川 肉搏 笨拙的地狱野猪 Hit -173249 (Physical)", -- [19]
				"笨拙的地狱野猪 肉搏 蜀川 Miss (1)", -- [20]
				"蜀川 旋风斩 笨拙的地狱野猪 Hit -27525 (Physical)", -- [21]
				"笨拙的地狱野猪 燃烧之刺 蜀川 Resist (Fire)", -- [22]
				"蜀川 肉搏 笨拙的地狱野猪 Crit -353380 (Physical)", -- [23]
				"笨拙的地狱野猪 肉搏 蜀川 Miss (1)", -- [24]
				"蜀川 旋风斩 笨拙的地狱野猪 Hit -27524 (Physical)", -- [25]
				"笨拙的地狱野猪 燃烧之刺 蜀川 Resist (Fire)", -- [26]
				"蜀川 肉搏 笨拙的地狱野猪 Hit -169834 (Physical)", -- [27]
				"笨拙的地狱野猪 燃烧之刺 蜀川 Resist (Fire)", -- [28]
				"蜀川 旋风斩 笨拙的地狱野猪 Hit -27416 (Physical)", -- [29]
				"笨拙的地狱野猪 燃烧之刺 蜀川 Resist (Fire)", -- [30]
				"笨拙的地狱野猪 肉搏 蜀川 Miss (1)", -- [31]
				"蜀川 旋风斩 笨拙的地狱野猪 Hit -27523 (Physical)", -- [32]
				"笨拙的地狱野猪 燃烧之刺 蜀川 Resist (Fire)", -- [33]
				"蜀川 旋风斩 笨拙的地狱野猪 Crit -55048 (Physical)", -- [34]
				"笨拙的地狱野猪 燃烧之刺 蜀川 Resist (Fire)", -- [35]
				"蜀川 旋风斩 笨拙的地狱野猪 Hit -27414 (Physical)", -- [36]
				"笨拙的地狱野猪 燃烧之刺 蜀川 Resist (Fire)", -- [37]
				"蜀川 旋风斩 逃跑的残冠战士 Crit -28086 (Physical)", -- [38]
				"伊利达雷监工 肉搏 蜀川 Miss (1)", -- [39]
				"蜀川 旋风斩 伊利达雷监工 Hit -24772 (Physical)", -- [40]
				"残冠蛮徒 肉搏 蜀川 Miss (1)", -- [41]
				"蜀川 旋风斩 残冠蛮徒 Hit -24772 (Physical)", -- [42]
				"蜀川 旋风斩 残冠蛮徒 Crit -49543 (Physical)", -- [43]
				"蜀川 肉搏 残冠蛮徒 Crit -358317 (Physical)", -- [44]
				"伊利达雷监工 肉搏 蜀川 Miss (1)", -- [45]
				"蜀川 旋风斩 伊利达雷监工 Hit -27524 (Physical)", -- [46]
				"残冠蛮徒 肉搏 蜀川 Miss (1)", -- [47]
				"蜀川 旋风斩 残冠蛮徒 Hit -27414 (Physical)", -- [48]
				"蜀川 旋风斩 残冠蛮徒 Crit -54829 (Physical)", -- [49]
				"蜀川 旋风斩 伊利达雷监工 Hit -24772 (Physical)", -- [50]
			},
			["LastEventIncoming"] = {
				true, -- [1]
				false, -- [2]
				false, -- [3]
				true, -- [4]
				false, -- [5]
				true, -- [6]
				false, -- [7]
				true, -- [8]
				false, -- [9]
				true, -- [10]
				false, -- [11]
				true, -- [12]
				false, -- [13]
				true, -- [14]
				false, -- [15]
				true, -- [16]
				false, -- [17]
				true, -- [18]
				false, -- [19]
				true, -- [20]
				false, -- [21]
				true, -- [22]
				false, -- [23]
				true, -- [24]
				false, -- [25]
				true, -- [26]
				false, -- [27]
				true, -- [28]
				false, -- [29]
				true, -- [30]
				true, -- [31]
				false, -- [32]
				true, -- [33]
				false, -- [34]
				true, -- [35]
				false, -- [36]
				true, -- [37]
				false, -- [38]
				true, -- [39]
				false, -- [40]
				true, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				true, -- [45]
				false, -- [46]
				true, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["Fights"] = {
				["Fight5"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
						["蜀川"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 228666,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 198390,
						["Physical"] = 30276,
					},
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["哈尔什风行者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["卡利鸟飞扑者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["卡利鸟女王"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["埃拉纳斯"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
								["副手旋风斩"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恐惧魔"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 30276,
								},
								["肉搏"] = {
									["count"] = 198390,
								},
							},
							["amount"] = 228666,
						},
						["啄骨秃鹫"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
						["旋风斩"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["哈尔什风行者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["卡利鸟飞扑者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恐惧魔"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["埃拉纳斯"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["啄骨秃鹫"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 1.5,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["旋风斩"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 30276,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 30276,
								},
							},
							["count"] = 1,
							["amount"] = 30276,
						},
						["副手旋风斩"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 198390,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 198390,
								},
							},
							["count"] = 1,
							["amount"] = 198390,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 4,
					["TimeDamage"] = 1.5,
					["TimeDamaging"] = {
						["哈尔什风行者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["卡利鸟飞扑者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恐惧魔"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["埃拉纳斯"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["啄骨秃鹫"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight2"] = {
					["ElementDoneBlock"] = {
						["Melee"] = 0,
						["Physical"] = 0,
					},
					["OverHeals"] = {
						["战斗专注"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["TimeSpent"] = {
						["恐惧魔"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["逃跑的残冠战士"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["团队副本训练假人"] = {
							["Details"] = {
								["巨龙怒吼"] = {
									["count"] = 0,
								},
								["嗜血"] = {
									["count"] = 0,
								},
								["冲锋"] = {
									["count"] = 0,
								},
								["怒击"] = {
									["count"] = 0,
								},
								["暴怒"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["德莱尼守备官"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
								["英勇飞跃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["哈尔什风行者"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["雄性小卡利鸟"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["卡利鸟飞扑者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无情的阿尔泽斯"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["残酷的阿拉修斯"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
								["冲锋"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["起泡的腐泥怪"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["伊利达雷监工"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 1.5,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 1.5,
						},
						["起泡的软泥怪"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RageGainedFrom"] = {
						["蜀川"] = {
							["Details"] = {
								["战斗专注"] = {
									["count"] = 0,
								},
								["嗜血"] = {
									["count"] = 0,
								},
								["冲锋"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 4,
								},
								["怒击"] = {
									["count"] = 0,
								},
								["巨龙怒吼"] = {
									["count"] = 0,
								},
							},
							["amount"] = 4,
						},
					},
					["PartialResist"] = {
						["挫志怒吼"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HOT_Time"] = 0,
					["ActiveTime"] = 1.5,
					["RageGained"] = {
						["战斗专注"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["嗜血"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["冲锋"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["旋风斩"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
						["怒击"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["巨龙怒吼"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Damage"] = 65816,
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["挫志怒吼"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["怒击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit (被格挡)"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit (被格挡)"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["巨龙怒吼"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["嗜血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit (被格挡)"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["冲锋"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["旋风斩"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 65816,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 65816,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 65816,
						},
						["英勇飞跃"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暴怒"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit (被格挡)"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Melee"] = 0,
						["Physical"] = 65816,
					},
					["RageGain"] = 4,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
								["Block"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
								["Block"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Parry"] = {
									["count"] = 0,
								},
							},
							["amount"] = 1,
						},
					},
					["TimeDamage"] = 1.5,
					["TimeDamaging"] = {
						["恐惧魔"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["逃跑的残冠战士"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["团队副本训练假人"] = {
							["Details"] = {
								["巨龙怒吼"] = {
									["count"] = 0,
								},
								["嗜血"] = {
									["count"] = 0,
								},
								["冲锋"] = {
									["count"] = 0,
								},
								["怒击"] = {
									["count"] = 0,
								},
								["暴怒"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["德莱尼守备官"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
								["英勇飞跃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["哈尔什风行者"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["雄性小卡利鸟"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["卡利鸟飞扑者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无情的阿尔泽斯"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["残酷的阿拉修斯"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
								["冲锋"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["起泡的腐泥怪"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["伊利达雷监工"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 1.5,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 1.5,
						},
						["起泡的软泥怪"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["起泡的软泥怪"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["团队副本训练假人"] = {
							["Details"] = {
								["巨龙怒吼"] = {
									["count"] = 0,
								},
								["嗜血"] = {
									["count"] = 0,
								},
								["冲锋"] = {
									["count"] = 0,
								},
								["怒击"] = {
									["count"] = 0,
								},
								["暴怒"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["德莱尼守备官"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
								["英勇飞跃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["哈尔什风行者"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["蝎子"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["残酷的阿拉修斯"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["起泡的腐泥怪"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["残冠地卜师"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
								["英勇飞跃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恐惧魔"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["逃跑的残冠战士"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无情的阿尔泽斯"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["伊利达雷监工"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 65816,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 65816,
						},
						["雄性小卡利鸟"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["卡利鸟飞扑者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["卡利鸟女王"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["残冠蛮徒"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["德莱尼学者"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["HOTs"] = {
						["战斗专注"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Overhealing"] = 0,
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
						["蜀川"] = {
							["Details"] = {
								["战斗专注"] = {
									["count"] = 0,
								},
								["冲锋"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Fire"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["DOT_Time"] = 0,
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["HOTs"] = {
					},
					["ElementTakenBlock"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["FDamagedWho"] = {
					},
					["FAttacks"] = {
					},
					["RageGain"] = 0,
					["ElementDone"] = {
						["Melee"] = 0,
						["Physical"] = 0,
					},
					["ManaGainedFrom"] = {
					},
					["DamagedWho"] = {
						["恐惧魔"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["笨拙的地狱野猪"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["哈尔什利爪卫兵"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["啄骨秃鹫"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
								["副手旋风斩"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["RageGained"] = {
						["战斗专注"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["冲锋"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["旋风斩"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["Dispelled"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
						["燃烧之刺"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["CCBreak"] = 0,
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ActiveTime"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["恐惧魔"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["笨拙的地狱野猪"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["哈尔什利爪卫兵"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["啄骨秃鹫"] = {
							["Details"] = {
								["副手旋风斩"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Heals"] = {
					},
					["PartialAbsorb"] = {
						["燃烧之刺"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["CCBroken"] = {
					},
					["RunicPowerGained"] = {
					},
					["Attacks"] = {
						["肉搏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["副手旋风斩"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["旋风斩"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["恐惧魔"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["笨拙的地狱野猪"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["哈尔什利爪卫兵"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["啄骨秃鹫"] = {
							["Details"] = {
								["副手旋风斩"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGain"] = 0,
					["Damage"] = 0,
					["DispelledWho"] = {
					},
				},
				["Fight3"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
						["蜀川"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 1,
								},
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 1,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 4,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
						["Physical"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 522236,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 371216,
						["Physical"] = 151020,
					},
					["PartialAbsorb"] = {
						["Falling"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["哈尔什风行者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["卡利鸟飞扑者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恐惧魔"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 30276,
								},
							},
							["amount"] = 30276,
						},
						["起泡的腐泥怪"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 30276,
								},
								["肉搏"] = {
									["count"] = 371216,
								},
							},
							["amount"] = 401492,
						},
						["哈尔什利爪卫兵"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["起泡的软泥怪"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 90468,
								},
							},
							["amount"] = 90468,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["Environment"] = {
							["Details"] = {
								["Falling"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["Falling"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
						["旋风斩"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["哈尔什风行者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["卡利鸟飞扑者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恐惧魔"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["起泡的腐泥怪"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["哈尔什利爪卫兵"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
								["英勇飞跃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["起泡的软泥怪"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0.42,
								},
							},
							["amount"] = 0.42,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 3.42,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["英勇飞跃"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 371216,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 371216,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 371216,
						},
						["旋风斩"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 60312,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 60312,
								},
								["Hit"] = {
									["max"] = 30276,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 90708,
								},
							},
							["count"] = 4,
							["amount"] = 151020,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 9,
					["TimeDamage"] = 3.42,
					["TimeDamaging"] = {
						["哈尔什风行者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["卡利鸟飞扑者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恐惧魔"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["起泡的腐泥怪"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["哈尔什利爪卫兵"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
								["英勇飞跃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["起泡的软泥怪"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0.42,
								},
							},
							["amount"] = 0.42,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight4"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
						["蜀川"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 8,
								},
							},
							["amount"] = 8,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 60432,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 0,
						["Physical"] = 60432,
					},
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["起泡的软泥怪"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["哈尔什利爪卫兵"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["末日女王"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 30156,
								},
							},
							["amount"] = 30156,
						},
						["雄性小卡利鸟"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["卡利鸟飞扑者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["卡利鸟女王"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["起泡的腐泥怪"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恐惧魔"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 0,
								},
								["冲锋"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 30276,
								},
							},
							["amount"] = 30276,
						},
						["啄骨秃鹫"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 0,
								},
								["英勇飞跃"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
						["冲锋"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["旋风斩"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 8,
								},
							},
							["amount"] = 8,
						},
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["雄性小卡利鸟"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["卡利鸟飞扑者"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["末日女王"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["恐惧魔"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 0,
								},
								["冲锋"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["起泡的软泥怪"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["哈尔什利爪卫兵"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["啄骨秃鹫"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 0,
								},
								["英勇飞跃"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 3,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["冲锋"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["英勇飞跃"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["旋风斩"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 30276,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 60432,
								},
							},
							["count"] = 2,
							["amount"] = 60432,
						},
						["肉搏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 8,
					["TimeDamage"] = 3,
					["TimeDamaging"] = {
						["雄性小卡利鸟"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["卡利鸟飞扑者"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["末日女王"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["恐惧魔"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 0,
								},
								["冲锋"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["起泡的软泥怪"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["哈尔什利爪卫兵"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["啄骨秃鹫"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 0,
								},
								["英勇飞跃"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
						["蜀川"] = {
							["Details"] = {
								["巨龙怒吼"] = {
									["count"] = 0,
								},
								["嗜血"] = {
									["count"] = 0,
								},
								["冲锋"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 4,
								},
								["怒击"] = {
									["count"] = 0,
								},
								["战斗专注"] = {
									["count"] = 0,
								},
							},
							["amount"] = 4,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Fire"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["DOT_Time"] = 0,
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["HOTs"] = {
						["战斗专注"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTakenBlock"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["FDamagedWho"] = {
					},
					["FAttacks"] = {
					},
					["RageGain"] = 4,
					["ElementDone"] = {
						["Melee"] = 0,
						["Physical"] = 82571,
					},
					["ManaGainedFrom"] = {
					},
					["DamagedWho"] = {
						["笨拙的地狱野猪"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 82571,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 82571,
						},
						["团队副本训练假人"] = {
							["Details"] = {
								["巨龙怒吼"] = {
									["count"] = 0,
								},
								["嗜血"] = {
									["count"] = 0,
								},
								["冲锋"] = {
									["count"] = 0,
								},
								["怒击"] = {
									["count"] = 0,
								},
								["暴怒"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["亚维鲁"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["哈尔什风行者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["雄性小卡利鸟"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["卡利鸟飞扑者"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["逃跑的残冠战士"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
								["英勇飞跃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["卡利鸟女王"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["残冠蛮徒"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["伊利达雷监工"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["哈尔什利爪卫兵"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
						["战斗专注"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["RageGained"] = {
						["巨龙怒吼"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["嗜血"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["冲锋"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["旋风斩"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
						["怒击"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["战斗专注"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
						["Melee"] = 0,
						["Physical"] = 0,
					},
					["TimeHealing"] = {
					},
					["Dispelled"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
						["燃烧之刺"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
					},
					["CCBreak"] = 0,
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ActiveTime"] = 1.8,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["笨拙的地狱野猪"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 1.8,
								},
								["冲锋"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 1.8,
						},
						["团队副本训练假人"] = {
							["Details"] = {
								["巨龙怒吼"] = {
									["count"] = 0,
								},
								["嗜血"] = {
									["count"] = 0,
								},
								["冲锋"] = {
									["count"] = 0,
								},
								["怒击"] = {
									["count"] = 0,
								},
								["暴怒"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["亚维鲁"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["伊利达雷监工"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
								["英勇飞跃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["雄性小卡利鸟"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["卡利鸟飞扑者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["逃跑的残冠战士"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["残冠蛮徒"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["哈尔什风行者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["哈尔什利爪卫兵"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Heals"] = {
					},
					["PartialAbsorb"] = {
						["燃烧之刺"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["CCBroken"] = {
					},
					["RunicPowerGained"] = {
					},
					["Attacks"] = {
						["怒击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit (被格挡)"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit (被格挡)"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["巨龙怒吼"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["嗜血"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["冲锋"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["旋风斩"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 55048,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 55048,
								},
								["Hit"] = {
									["max"] = 27523,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 27523,
								},
							},
							["count"] = 2,
							["amount"] = 82571,
						},
						["英勇飞跃"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暴怒"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit (被格挡)"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit (被格挡)"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit (被格挡)"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Block"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 1,
								},
								["Block"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Parry"] = {
									["count"] = 0,
								},
							},
							["amount"] = 2,
						},
					},
					["TimeDamage"] = 1.8,
					["TimeDamaging"] = {
						["笨拙的地狱野猪"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 1.8,
								},
								["冲锋"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 1.8,
						},
						["团队副本训练假人"] = {
							["Details"] = {
								["巨龙怒吼"] = {
									["count"] = 0,
								},
								["嗜血"] = {
									["count"] = 0,
								},
								["冲锋"] = {
									["count"] = 0,
								},
								["怒击"] = {
									["count"] = 0,
								},
								["暴怒"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["亚维鲁"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["伊利达雷监工"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
								["英勇飞跃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["雄性小卡利鸟"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["卡利鸟飞扑者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["逃跑的残冠战士"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["残冠蛮徒"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["哈尔什风行者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["哈尔什利爪卫兵"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGain"] = 0,
					["Damage"] = 82571,
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["ElementDoneBlock"] = {
						["Melee"] = 1179,
						["Physical"] = 2670,
					},
					["OverHeals"] = {
						["战斗专注"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 930,
									["min"] = 929,
									["count"] = 47,
									["amount"] = 43702,
								},
							},
							["count"] = 47,
							["amount"] = 43702,
						},
					},
					["TimeSpent"] = {
						["起泡的软泥怪"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 3.9,
								},
							},
							["amount"] = 3.9,
						},
						["哈尔什利爪卫兵"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 1.5,
								},
								["肉搏"] = {
									["count"] = 1.5,
								},
								["旋风斩"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 7.5,
						},
						["亚维鲁"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["哈尔什风行者"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 1.5,
								},
								["肉搏"] = {
									["count"] = 1.5,
								},
								["旋风斩"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 7.5,
						},
						["残酷的阿拉修斯"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 1.01,
								},
								["冲锋"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 2.51,
						},
						["起泡的腐泥怪"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
						["笨拙的地狱野猪"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 7.8,
								},
								["冲锋"] = {
									["count"] = 1.5,
								},
								["肉搏"] = {
									["count"] = 9,
								},
							},
							["amount"] = 18.3,
						},
						["恐惧魔"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 1.5,
								},
								["英勇飞跃"] = {
									["count"] = 1.5,
								},
								["肉搏"] = {
									["count"] = 3,
								},
								["旋风斩"] = {
									["count"] = 13.64,
								},
							},
							["amount"] = 19.64,
						},
						["埃拉纳斯"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0.57,
								},
								["旋风斩"] = {
									["count"] = 1.93,
								},
							},
							["amount"] = 2.5,
						},
						["逃跑的残冠战士"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0.44,
								},
							},
							["amount"] = 0.44,
						},
						["末日女王"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["伊利达雷监工"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 3,
								},
								["旋风斩"] = {
									["count"] = 12,
								},
								["肉搏"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 16.5,
						},
						["雄性小卡利鸟"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 1.5,
								},
								["肉搏"] = {
									["count"] = 3,
								},
							},
							["amount"] = 4.5,
						},
						["卡利鸟飞扑者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 8.739999999999998,
								},
								["肉搏"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 10.24,
						},
						["德莱尼守备官"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 1.25,
								},
								["英勇飞跃"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 2.75,
						},
						["无情的阿尔泽斯"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["残冠蛮徒"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["团队副本训练假人"] = {
							["Details"] = {
								["巨龙怒吼"] = {
									["count"] = 1.88,
								},
								["嗜血"] = {
									["count"] = 31.12,
								},
								["冲锋"] = {
									["count"] = 3.1,
								},
								["怒击"] = {
									["count"] = 43.58,
								},
								["暴怒"] = {
									["count"] = 23.62,
								},
								["肉搏"] = {
									["count"] = 83.1,
								},
							},
							["amount"] = 186.4,
						},
						["啄骨秃鹫"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 14.05,
								},
								["冲锋"] = {
									["count"] = 1.5,
								},
								["英勇飞跃"] = {
									["count"] = 1.5,
								},
								["副手旋风斩"] = {
									["count"] = 0.91,
								},
								["肉搏"] = {
									["count"] = 7.5,
								},
							},
							["amount"] = 25.46,
						},
					},
					["DamageTaken"] = 2687,
					["RageGainedFrom"] = {
						["蜀川"] = {
							["Details"] = {
								["战斗专注"] = {
									["count"] = 218,
								},
								["嗜血"] = {
									["count"] = 423.200000286102,
								},
								["冲锋"] = {
									["count"] = 240,
								},
								["旋风斩"] = {
									["count"] = 296,
								},
								["怒击"] = {
									["count"] = 644.60000026226,
								},
								["巨龙怒吼"] = {
									["count"] = 20,
								},
							},
							["amount"] = 1841.80000054836,
						},
					},
					["PartialResist"] = {
						["Falling"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["挫志怒吼"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["燃烧之刺"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 13,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 13,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 67,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 67,
						},
					},
					["HOT_Time"] = 141,
					["ActiveTime"] = 320.14,
					["ElementTaken"] = {
						["Physical"] = 2687,
					},
					["RageGained"] = {
						["战斗专注"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 218,
								},
							},
							["amount"] = 218,
						},
						["嗜血"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 423.200000286102,
								},
							},
							["amount"] = 423.200000286102,
						},
						["冲锋"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 240,
								},
							},
							["amount"] = 240,
						},
						["旋风斩"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 296,
								},
							},
							["amount"] = 296,
						},
						["怒击"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 644.60000026226,
								},
							},
							["amount"] = 644.60000026226,
						},
						["巨龙怒吼"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 20,
								},
							},
							["amount"] = 20,
						},
					},
					["Damage"] = 12188073,
					["WhoDamaged"] = {
						["Environment"] = {
							["Details"] = {
								["Falling"] = {
									["count"] = 2687,
								},
							},
							["amount"] = 2687,
						},
					},
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 3,
						},
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 4,
								},
								["Miss"] = {
									["count"] = 63,
								},
							},
							["amount"] = 67,
						},
						["Fire"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 13,
								},
							},
							["amount"] = 13,
						},
					},
					["PartialAbsorb"] = {
						["Falling"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["挫志怒吼"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["燃烧之刺"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 13,
									["amount"] = 0,
								},
							},
							["count"] = 13,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 67,
									["amount"] = 0,
								},
							},
							["count"] = 67,
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["巨龙怒吼"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5025,
									["min"] = 4568,
									["count"] = 3,
									["amount"] = 14618,
								},
								["Hit"] = {
									["max"] = 2512,
									["min"] = 2284,
									["count"] = 3,
									["amount"] = 7080,
								},
							},
							["count"] = 6,
							["amount"] = 21698,
						},
						["嗜血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1187,
									["min"] = 647,
									["count"] = 38,
									["amount"] = 34355,
								},
								["Crit"] = {
									["max"] = 2374,
									["min"] = 1295,
									["count"] = 14,
									["amount"] = 24992,
								},
								["Hit (被格挡)"] = {
									["max"] = 703,
									["min"] = 703,
									["count"] = 1,
									["amount"] = 703,
								},
							},
							["count"] = 53,
							["amount"] = 60050,
						},
						["怒击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1047,
									["min"] = 285,
									["count"] = 62,
									["amount"] = 41622,
								},
								["Crit (被格挡)"] = {
									["max"] = 620,
									["min"] = 564,
									["count"] = 2,
									["amount"] = 1184,
								},
								["Hit (被格挡)"] = {
									["max"] = 620,
									["min"] = 259,
									["count"] = 7,
									["amount"] = 3387,
								},
								["Crit"] = {
									["max"] = 1905,
									["min"] = 571,
									["count"] = 33,
									["amount"] = 36556,
								},
								["Parry"] = {
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 108,
							["amount"] = 82749,
						},
						["副手旋风斩"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 16231,
									["min"] = 16229,
									["count"] = 4,
									["amount"] = 64920,
								},
							},
							["count"] = 4,
							["amount"] = 64920,
						},
						["旋风斩"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 72697,
									["min"] = 28086,
									["count"] = 34,
									["amount"] = 1992275,
								},
								["Hit"] = {
									["max"] = 36204,
									["min"] = 23031,
									["count"] = 79,
									["amount"] = 2366865,
								},
							},
							["count"] = 113,
							["amount"] = 4359140,
						},
						["冲锋"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 98793,
									["min"] = 89811,
									["count"] = 2,
									["amount"] = 188604,
								},
								["Hit"] = {
									["max"] = 59301,
									["min"] = 109,
									["count"] = 4,
									["amount"] = 109310,
								},
							},
							["count"] = 9,
							["amount"] = 297914,
						},
						["英勇飞跃"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 88065,
									["min"] = 72054,
									["count"] = 2,
									["amount"] = 160119,
								},
								["Hit"] = {
									["max"] = 44210,
									["min"] = 20504,
									["count"] = 12,
									["amount"] = 462833,
								},
							},
							["count"] = 14,
							["amount"] = 622952,
						},
						["暴怒"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 943,
									["min"] = 377,
									["count"] = 51,
									["amount"] = 34989,
								},
								["Parry"] = {
									["count"] = 3,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 1596,
									["min"] = 1063,
									["count"] = 16,
									["amount"] = 21649,
								},
								["Hit (被格挡)"] = {
									["max"] = 586,
									["min"] = 372,
									["count"] = 2,
									["amount"] = 958,
								},
							},
							["count"] = 72,
							["amount"] = 57596,
						},
						["肉搏"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 4,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 223587,
									["min"] = 205,
									["count"] = 93,
									["amount"] = 3560516,
								},
								["Hit (被格挡)"] = {
									["max"] = 467,
									["min"] = 232,
									["count"] = 4,
									["amount"] = 1434,
								},
								["Miss"] = {
									["count"] = 28,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 425484,
									["min"] = 410,
									["count"] = 46,
									["amount"] = 3057785,
								},
								["Crit (被格挡)"] = {
									["max"] = 798,
									["min"] = 521,
									["count"] = 2,
									["amount"] = 1319,
								},
							},
							["count"] = 177,
							["amount"] = 6621054,
						},
					},
					["ElementDone"] = {
						["Melee"] = 6621054,
						["Physical"] = 5567019,
					},
					["RageGain"] = 1841.80000054836,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 97,
								},
								["Miss"] = {
									["count"] = 28,
								},
								["Block"] = {
									["count"] = 6,
								},
								["Crit"] = {
									["count"] = 48,
								},
								["Parry"] = {
									["count"] = 4,
								},
							},
							["amount"] = 183,
						},
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 263,
								},
								["Block"] = {
									["count"] = 12,
								},
								["Crit"] = {
									["count"] = 106,
								},
								["Parry"] = {
									["count"] = 7,
								},
							},
							["amount"] = 391,
						},
					},
					["TimeDamage"] = 320.14,
					["TimeDamaging"] = {
						["起泡的软泥怪"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 3.9,
								},
							},
							["amount"] = 3.9,
						},
						["哈尔什利爪卫兵"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 1.5,
								},
								["肉搏"] = {
									["count"] = 1.5,
								},
								["旋风斩"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 7.5,
						},
						["亚维鲁"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["哈尔什风行者"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 1.5,
								},
								["肉搏"] = {
									["count"] = 1.5,
								},
								["旋风斩"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 7.5,
						},
						["残酷的阿拉修斯"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 1.01,
								},
								["冲锋"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 2.51,
						},
						["起泡的腐泥怪"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
						["笨拙的地狱野猪"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 7.8,
								},
								["冲锋"] = {
									["count"] = 1.5,
								},
								["肉搏"] = {
									["count"] = 9,
								},
							},
							["amount"] = 18.3,
						},
						["恐惧魔"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 1.5,
								},
								["英勇飞跃"] = {
									["count"] = 1.5,
								},
								["肉搏"] = {
									["count"] = 3,
								},
								["旋风斩"] = {
									["count"] = 13.64,
								},
							},
							["amount"] = 19.64,
						},
						["埃拉纳斯"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0.57,
								},
								["旋风斩"] = {
									["count"] = 1.93,
								},
							},
							["amount"] = 2.5,
						},
						["逃跑的残冠战士"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0.44,
								},
							},
							["amount"] = 0.44,
						},
						["末日女王"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["伊利达雷监工"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 3,
								},
								["旋风斩"] = {
									["count"] = 12,
								},
								["肉搏"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 16.5,
						},
						["雄性小卡利鸟"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 1.5,
								},
								["肉搏"] = {
									["count"] = 3,
								},
							},
							["amount"] = 4.5,
						},
						["卡利鸟飞扑者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 8.739999999999998,
								},
								["肉搏"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 10.24,
						},
						["德莱尼守备官"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 1.25,
								},
								["英勇飞跃"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 2.75,
						},
						["无情的阿尔泽斯"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["残冠蛮徒"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["团队副本训练假人"] = {
							["Details"] = {
								["巨龙怒吼"] = {
									["count"] = 1.88,
								},
								["嗜血"] = {
									["count"] = 31.12,
								},
								["冲锋"] = {
									["count"] = 3.1,
								},
								["怒击"] = {
									["count"] = 43.58,
								},
								["暴怒"] = {
									["count"] = 23.62,
								},
								["肉搏"] = {
									["count"] = 83.1,
								},
							},
							["amount"] = 186.4,
						},
						["啄骨秃鹫"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 14.05,
								},
								["冲锋"] = {
									["count"] = 1.5,
								},
								["英勇飞跃"] = {
									["count"] = 1.5,
								},
								["副手旋风斩"] = {
									["count"] = 0.91,
								},
								["肉搏"] = {
									["count"] = 7.5,
								},
							},
							["amount"] = 25.46,
						},
					},
					["DamagedWho"] = {
						["起泡的软泥怪"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 543296,
								},
							},
							["amount"] = 543296,
						},
						["团队副本训练假人"] = {
							["Details"] = {
								["巨龙怒吼"] = {
									["count"] = 21698,
								},
								["嗜血"] = {
									["count"] = 60050,
								},
								["冲锋"] = {
									["count"] = 218,
								},
								["怒击"] = {
									["count"] = 82749,
								},
								["暴怒"] = {
									["count"] = 57596,
								},
								["肉搏"] = {
									["count"] = 69572,
								},
							},
							["amount"] = 291883,
						},
						["亚维鲁"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 44208,
								},
							},
							["amount"] = 44208,
						},
						["哈尔什风行者"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 59301,
								},
								["肉搏"] = {
									["count"] = 406295,
								},
								["旋风斩"] = {
									["count"] = 224151,
								},
							},
							["amount"] = 689747,
						},
						["蝎子"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 23031,
								},
							},
							["amount"] = 23031,
						},
						["残酷的阿拉修斯"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 197964,
								},
							},
							["amount"] = 197964,
						},
						["起泡的腐泥怪"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 1032574,
								},
								["旋风斩"] = {
									["count"] = 120865,
								},
							},
							["amount"] = 1153439,
						},
						["无情的阿尔泽斯"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 32907,
								},
							},
							["amount"] = 32907,
						},
						["德莱尼守备官"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 60313,
								},
								["英勇飞跃"] = {
									["count"] = 88065,
								},
							},
							["amount"] = 148378,
						},
						["笨拙的地狱野猪"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 89811,
								},
								["旋风斩"] = {
									["count"] = 329740,
								},
								["肉搏"] = {
									["count"] = 1638030,
								},
							},
							["amount"] = 2057581,
						},
						["残冠地卜师"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 86056,
								},
								["英勇飞跃"] = {
									["count"] = 83668,
								},
							},
							["amount"] = 169724,
						},
						["恐惧魔"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 98793,
								},
								["英勇飞跃"] = {
									["count"] = 44209,
								},
								["肉搏"] = {
									["count"] = 398027,
								},
								["旋风斩"] = {
									["count"] = 392751,
								},
							},
							["amount"] = 933780,
						},
						["埃拉纳斯"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 193379,
								},
								["副手旋风斩"] = {
									["count"] = 48689,
								},
								["旋风斩"] = {
									["count"] = 90828,
								},
							},
							["amount"] = 332896,
						},
						["逃跑的残冠战士"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 20504,
								},
								["旋风斩"] = {
									["count"] = 65398,
								},
							},
							["amount"] = 85902,
						},
						["末日女王"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 30156,
								},
							},
							["amount"] = 30156,
						},
						["伊利达雷监工"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 76361,
								},
								["旋风斩"] = {
									["count"] = 436910,
								},
								["肉搏"] = {
									["count"] = 183209,
								},
							},
							["amount"] = 696480,
						},
						["雄性小卡利鸟"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 121107,
								},
								["肉搏"] = {
									["count"] = 579715,
								},
							},
							["amount"] = 700822,
						},
						["卡利鸟飞扑者"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 44210,
								},
								["旋风斩"] = {
									["count"] = 404967,
								},
								["肉搏"] = {
									["count"] = 188291,
								},
							},
							["amount"] = 637468,
						},
						["哈尔什利爪卫兵"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 44032,
								},
								["肉搏"] = {
									["count"] = 185965,
								},
								["旋风斩"] = {
									["count"] = 120624,
								},
							},
							["amount"] = 350621,
						},
						["卡利鸟女王"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 127031,
								},
							},
							["amount"] = 127031,
						},
						["残冠蛮徒"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 108225,
								},
								["肉搏"] = {
									["count"] = 566920,
								},
								["旋风斩"] = {
									["count"] = 542619,
								},
							},
							["amount"] = 1217764,
						},
						["德莱尼学者"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 25261,
								},
							},
							["amount"] = 25261,
						},
						["啄骨秃鹫"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 606390,
								},
								["冲锋"] = {
									["count"] = 49791,
								},
								["英勇飞跃"] = {
									["count"] = 44209,
								},
								["副手旋风斩"] = {
									["count"] = 16231,
								},
								["肉搏"] = {
									["count"] = 981113,
								},
							},
							["amount"] = 1697734,
						},
					},
					["HOTs"] = {
						["战斗专注"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 141,
								},
							},
							["amount"] = 141,
						},
					},
					["Overhealing"] = 43702,
				},
				["Fight1"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
						["蜀川"] = {
							["Details"] = {
								["巨龙怒吼"] = {
									["count"] = 0,
								},
								["嗜血"] = {
									["count"] = 0,
								},
								["冲锋"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 4,
								},
								["怒击"] = {
									["count"] = 0,
								},
								["战斗专注"] = {
									["count"] = 0,
								},
							},
							["amount"] = 4,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Fire"] = {
							["Details"] = {
								["Resist"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["DOT_Time"] = 0,
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["HOTs"] = {
						["战斗专注"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTakenBlock"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["FDamagedWho"] = {
					},
					["FAttacks"] = {
					},
					["RageGain"] = 4,
					["ElementDone"] = {
						["Melee"] = 0,
						["Physical"] = 82571,
					},
					["ManaGainedFrom"] = {
					},
					["DamagedWho"] = {
						["笨拙的地狱野猪"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 82571,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 82571,
						},
						["团队副本训练假人"] = {
							["Details"] = {
								["巨龙怒吼"] = {
									["count"] = 0,
								},
								["嗜血"] = {
									["count"] = 0,
								},
								["冲锋"] = {
									["count"] = 0,
								},
								["怒击"] = {
									["count"] = 0,
								},
								["暴怒"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["亚维鲁"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["哈尔什风行者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["雄性小卡利鸟"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["卡利鸟飞扑者"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["逃跑的残冠战士"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
								["英勇飞跃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["卡利鸟女王"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["残冠蛮徒"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["伊利达雷监工"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 0,
								},
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["哈尔什利爪卫兵"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
						["战斗专注"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["RageGained"] = {
						["巨龙怒吼"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["嗜血"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["冲锋"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["旋风斩"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
						["怒击"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["战斗专注"] = {
							["Details"] = {
								["蜀川"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
						["Melee"] = 0,
						["Physical"] = 0,
					},
					["TimeHealing"] = {
					},
					["Dispelled"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
						["燃烧之刺"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
					},
					["CCBreak"] = 0,
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ActiveTime"] = 1.8,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["笨拙的地狱野猪"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 1.8,
								},
								["冲锋"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 1.8,
						},
						["团队副本训练假人"] = {
							["Details"] = {
								["巨龙怒吼"] = {
									["count"] = 0,
								},
								["嗜血"] = {
									["count"] = 0,
								},
								["冲锋"] = {
									["count"] = 0,
								},
								["怒击"] = {
									["count"] = 0,
								},
								["暴怒"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["亚维鲁"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["伊利达雷监工"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
								["英勇飞跃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["雄性小卡利鸟"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["卡利鸟飞扑者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["逃跑的残冠战士"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["残冠蛮徒"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["哈尔什风行者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["哈尔什利爪卫兵"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Heals"] = {
					},
					["PartialAbsorb"] = {
						["燃烧之刺"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["CCBroken"] = {
					},
					["RunicPowerGained"] = {
					},
					["Attacks"] = {
						["怒击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit (被格挡)"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit (被格挡)"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["巨龙怒吼"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["嗜血"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["冲锋"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["旋风斩"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 55048,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 55048,
								},
								["Hit"] = {
									["max"] = 27523,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 27523,
								},
							},
							["count"] = 2,
							["amount"] = 82571,
						},
						["英勇飞跃"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暴怒"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit (被格挡)"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit (被格挡)"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit (被格挡)"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Block"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 1,
								},
								["Block"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Parry"] = {
									["count"] = 0,
								},
							},
							["amount"] = 2,
						},
					},
					["TimeDamage"] = 1.8,
					["TimeDamaging"] = {
						["笨拙的地狱野猪"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 1.8,
								},
								["冲锋"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 1.8,
						},
						["团队副本训练假人"] = {
							["Details"] = {
								["巨龙怒吼"] = {
									["count"] = 0,
								},
								["嗜血"] = {
									["count"] = 0,
								},
								["冲锋"] = {
									["count"] = 0,
								},
								["怒击"] = {
									["count"] = 0,
								},
								["暴怒"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["亚维鲁"] = {
							["Details"] = {
								["英勇飞跃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["伊利达雷监工"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
								["英勇飞跃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["雄性小卡利鸟"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["卡利鸟飞扑者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["逃跑的残冠战士"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["残冠蛮徒"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["哈尔什风行者"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["哈尔什利爪卫兵"] = {
							["Details"] = {
								["旋风斩"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGain"] = 0,
					["Damage"] = 82571,
					["DispelledWho"] = {
					},
				},
			},
			["LastEventTimes"] = {
				13268.561, -- [1]
				13268.561, -- [2]
				13306.298, -- [3]
				13306.298, -- [4]
				13306.298, -- [5]
				13306.298, -- [6]
				13311.735, -- [7]
				13311.735, -- [8]
				13327.086, -- [9]
				13327.086, -- [10]
				13334.411, -- [11]
				13334.411, -- [12]
				13339.074, -- [13]
				13339.074, -- [14]
				13354.239, -- [15]
				13354.239, -- [16]
				13354.239, -- [17]
				13354.239, -- [18]
				13365.347, -- [19]
				13365.347, -- [20]
				13365.347, -- [21]
				13365.347, -- [22]
				13373.515, -- [23]
				13373.515, -- [24]
				13373.515, -- [25]
				13373.515, -- [26]
				13377.026, -- [27]
				13377.026, -- [28]
				13379.954, -- [29]
				13379.954, -- [30]
				13389.348, -- [31]
				13389.348, -- [32]
				13389.464, -- [33]
				13389.647, -- [34]
				13389.647, -- [35]
				13397.171, -- [36]
				13397.171, -- [37]
				13232.757, -- [38]
				13239.339, -- [39]
				13239.339, -- [40]
				13239.339, -- [41]
				13239.339, -- [42]
				13239.339, -- [43]
				13251.257, -- [44]
				13251.257, -- [45]
				13251.257, -- [46]
				13251.257, -- [47]
				13251.257, -- [48]
				13251.257, -- [49]
				13268.561, -- [50]
			},
			["Name"] = "蜀川",
			["LastEventHealthMax"] = {
				28100, -- [1]
				28100, -- [2]
				28100, -- [3]
				28100, -- [4]
				28100, -- [5]
				28100, -- [6]
				28100, -- [7]
				28100, -- [8]
				28100, -- [9]
				28100, -- [10]
				28100, -- [11]
				28100, -- [12]
				28100, -- [13]
				28100, -- [14]
				28100, -- [15]
				28100, -- [16]
				28100, -- [17]
				28100, -- [18]
				28100, -- [19]
				28100, -- [20]
				28100, -- [21]
				28100, -- [22]
				28100, -- [23]
				28100, -- [24]
				28100, -- [25]
				28100, -- [26]
				28100, -- [27]
				28100, -- [28]
				28100, -- [29]
				28100, -- [30]
				28100, -- [31]
				28100, -- [32]
				28100, -- [33]
				28100, -- [34]
				28100, -- [35]
				28100, -- [36]
				28100, -- [37]
				28100, -- [38]
				28100, -- [39]
				28100, -- [40]
				28100, -- [41]
				28100, -- [42]
				28100, -- [43]
				28100, -- [44]
				28100, -- [45]
				28100, -- [46]
				28100, -- [47]
				28100, -- [48]
				28100, -- [49]
				28100, -- [50]
			},
			["LastActive"] = 13396.456,
		},
	},
	["FightNum"] = 20,
	["CombatTimes"] = {
		{
			286363.477, -- [1]
			286447.477, -- [2]
			"00:03:07", -- [3]
			"00:04:31", -- [4]
			"团队副本训练假人", -- [5]
		}, -- [1]
		{
			286510.501, -- [1]
			286629.534, -- [2]
			"00:05:34", -- [3]
			"00:07:33", -- [4]
			"团队副本训练假人", -- [5]
		}, -- [2]
		{
			8941.458, -- [1]
			8945.458, -- [2]
			"21:26:42", -- [3]
			"21:26:45", -- [4]
			"啄骨秃鹫", -- [5]
		}, -- [3]
		{
			8953.456, -- [1]
			8957.459, -- [2]
			"21:26:53", -- [3]
			"21:26:57", -- [4]
			"啄骨秃鹫", -- [5]
		}, -- [4]
		{
			9141.459, -- [1]
			9146.458, -- [2]
			"21:30:02", -- [3]
			"21:30:06", -- [4]
			"雄性小卡利鸟", -- [5]
		}, -- [5]
		{
			9166.462, -- [1]
			9169.464, -- [2]
			"21:30:27", -- [3]
			"21:30:29", -- [4]
			"卡利鸟飞扑者", -- [5]
		}, -- [6]
		{
			9169.464, -- [1]
			9174.464, -- [2]
			"21:30:30", -- [3]
			"21:30:34", -- [4]
			"雄性小卡利鸟", -- [5]
		}, -- [7]
		{
			9193.461, -- [1]
			9204.452, -- [2]
			"21:30:53", -- [3]
			"21:31:04", -- [4]
			"亚维鲁", -- [5]
		}, -- [8]
		{
			9205.451000000001, -- [1]
			9210.452, -- [2]
			"21:31:05", -- [3]
			"21:31:10", -- [4]
			"雌性小卡利鸟", -- [5]
		}, -- [9]
		{
			9233.456, -- [1]
			9236.460000000001, -- [2]
			"21:31:33", -- [3]
			"21:31:36", -- [4]
			"埃拉纳斯", -- [5]
		}, -- [10]
		{
			9466.456, -- [1]
			9469.460000000001, -- [2]
			"21:35:27", -- [3]
			"21:35:29", -- [4]
			"哈尔什利爪卫兵", -- [5]
		}, -- [11]
		{
			9487.462, -- [1]
			9491.457, -- [2]
			"21:35:48", -- [3]
			"21:35:51", -- [4]
			"哈尔什风行者", -- [5]
		}, -- [12]
		{
			9496.455, -- [1]
			9499.461, -- [2]
			"21:35:56", -- [3]
			"21:35:59", -- [4]
			"哈尔什风行者", -- [5]
		}, -- [13]
		{
			9515.452, -- [1]
			9518.461, -- [2]
			"21:36:16", -- [3]
			"21:36:18", -- [4]
			"哈尔什利爪卫兵", -- [5]
		}, -- [14]
		{
			12421.456, -- [1]
			12424.462, -- [2]
			"22:24:42", -- [3]
			"22:24:44", -- [4]
			"恐惧魔", -- [5]
		}, -- [15]
		{
			12429.458, -- [1]
			12432.459, -- [2]
			"22:24:50", -- [3]
			"22:24:52", -- [4]
			"恐惧魔", -- [5]
		}, -- [16]
		{
			12534.454, -- [1]
			12538.469, -- [2]
			"22:26:35", -- [3]
			"22:26:38", -- [4]
			"末日女王", -- [5]
		}, -- [17]
		{
			12557.459, -- [1]
			12562.461, -- [2]
			"22:26:57", -- [3]
			"22:27:02", -- [4]
			"恐惧魔", -- [5]
		}, -- [18]
		{
			13212.459, -- [1]
			13215.463, -- [2]
			"22:37:53", -- [3]
			"22:37:55", -- [4]
			"伊利达雷监工", -- [5]
		}, -- [19]
		{
			13388.456, -- [1]
			13391.458, -- [2]
			"22:40:49", -- [3]
			"22:40:51", -- [4]
			"笨拙的地狱野猪", -- [5]
		}, -- [20]
	},
	["FoughtWho"] = {
		"笨拙的地狱野猪 22:40:49-22:40:51", -- [1]
		"伊利达雷监工 22:37:53-22:37:55", -- [2]
		"恐惧魔 22:26:57-22:27:02", -- [3]
		"末日女王 22:26:35-22:26:38", -- [4]
		"恐惧魔 22:24:50-22:24:52", -- [5]
	},
}
