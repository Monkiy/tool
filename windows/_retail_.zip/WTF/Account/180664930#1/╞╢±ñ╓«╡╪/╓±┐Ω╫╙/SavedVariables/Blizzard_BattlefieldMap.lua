
BattlefieldMapOptions = {
	["locked"] = true,
	["opacity"] = 0.7,
	["position"] = {
		["y"] = 470.999969482422,
		["x"] = 102.499847412109,
	},
	["showPlayers"] = true,
}
