
BattlefieldMinimapOptions = {
	["locked"] = true,
	["opacity"] = 0.699999988079071,
	["position"] = {
		["y"] = 421.000030517578,
		["x"] = 90.5000686645508,
	},
	["showPlayers"] = true,
}
