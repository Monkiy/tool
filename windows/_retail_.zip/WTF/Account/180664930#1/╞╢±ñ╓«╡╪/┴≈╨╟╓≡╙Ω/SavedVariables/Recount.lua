
RecountPerCharDB = {
	["version"] = "1.3",
	["combatants"] = {
		["No One"] = {
			["GUID"] = "",
			["type"] = "Ungrouped",
			["FightsSaved"] = 5,
			["LastAbility"] = 8381.057,
			["LastEventType"] = {
				"HEAL", -- [1]
			},
			["Owner"] = false,
			["LastFightIn"] = 13,
			["NextEventNum"] = 2,
			["UnitLockout"] = 3939.401,
			["LastEvents"] = {
				"No One 美味大餐 流星逐雨 Hit +42949 (42949 过量治疗)", -- [1]
			},
			["LastEventIncoming"] = {
				false, -- [1]
			},
			["Name"] = "No One",
			["Fights"] = {
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
			},
			["level"] = 0,
			["LastEventTimes"] = {
				3940.168, -- [1]
			},
			["LastActive"] = 3939.401,
		},
		["车队护卫 <流星逐雨>"] = {
			["GUID"] = "Creature-0-3917-1642-9039-148487-0000407623",
			["TimeLast"] = {
				["Damage"] = 5151.039,
				["OVERALL"] = 5151.039,
				["TimeDamage"] = 5151.039,
				["ActiveTime"] = 5151.039,
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
			},
			["TimeWindows"] = {
				["Damage"] = {
					3098, -- [1]
				},
				["TimeDamage"] = {
					4.54, -- [1]
				},
				["ActiveTime"] = {
					4.54, -- [1]
				},
			},
			["enClass"] = "PET",
			["level"] = 1,
			["LastFightIn"] = 9,
			["type"] = "Pet",
			["FightsSaved"] = 5,
			["ownerName"] = "流星逐雨",
			["LastActive"] = 5151.039,
			["LastEventTimes"] = {
				5130.124, -- [1]
				5131.439, -- [2]
				5131.655, -- [3]
				5151.74, -- [4]
			},
			["NextEventNum"] = 5,
			["LastDamageTime"] = 5151.74,
			["LastEvents"] = {
				"车队护卫 <流星逐雨> 肉搏 第七军团掠夺者 Hit -624 (Physical)", -- [1]
				"车队护卫 <流星逐雨> 肉搏 第七军团掠夺者 Crit -1142 (Physical)", -- [2]
				"车队护卫 <流星逐雨> 猛烈穿刺 第七军团掠夺者 Hit -682 (Physical)", -- [3]
				"车队护卫 <流星逐雨> 肉搏 第七军团焚化者 Hit -650 (Physical)", -- [4]
			},
			["Name"] = "车队护卫",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
			},
			["Fights"] = {
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["TimeSpent"] = {
						["第七军团掠夺者"] = {
							["Details"] = {
								["猛烈穿刺"] = {
									["count"] = 0.22,
								},
								["肉搏"] = {
									["count"] = 2.82,
								},
							},
							["amount"] = 3.04,
						},
						["第七军团焚化者"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["ElementDone"] = {
						["Melee"] = 2416,
						["Physical"] = 682,
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 3,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DamagedWho"] = {
						["第七军团掠夺者"] = {
							["Details"] = {
								["猛烈穿刺"] = {
									["count"] = 682,
								},
								["肉搏"] = {
									["count"] = 1766,
								},
							},
							["amount"] = 2448,
						},
						["第七军团焚化者"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 650,
								},
							},
							["amount"] = 650,
						},
					},
					["TimeDamage"] = 4.54,
					["TimeDamaging"] = {
						["第七军团掠夺者"] = {
							["Details"] = {
								["猛烈穿刺"] = {
									["count"] = 0.22,
								},
								["肉搏"] = {
									["count"] = 2.82,
								},
							},
							["amount"] = 3.04,
						},
						["第七军团焚化者"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["Attacks"] = {
						["猛烈穿刺"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 682,
									["min"] = 682,
									["count"] = 1,
									["amount"] = 682,
								},
							},
							["count"] = 1,
							["amount"] = 682,
						},
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1142,
									["min"] = 1142,
									["count"] = 1,
									["amount"] = 1142,
								},
								["Hit"] = {
									["max"] = 650,
									["min"] = 624,
									["count"] = 2,
									["amount"] = 1274,
								},
							},
							["count"] = 3,
							["amount"] = 2416,
						},
					},
					["ActiveTime"] = 4.54,
					["Damage"] = 3098,
				},
			},
			["LastFlags"] = 2600,
			["UnitLockout"] = 5151.039,
			["LastAbility"] = 8381.057,
		},
		["刃断-阿尔萨斯"] = {
			["GUID"] = "Player-844-01B23B4B",
			["LastEventHealth"] = {
				208220, -- [1]
				208220, -- [2]
				208220, -- [3]
				208220, -- [4]
				208220, -- [5]
				208220, -- [6]
				208220, -- [7]
				208220, -- [8]
				208220, -- [9]
				208220, -- [10]
				208220, -- [11]
				208220, -- [12]
				208220, -- [13]
				208220, -- [14]
				208220, -- [15]
				208220, -- [16]
				208220, -- [17]
				208220, -- [18]
				208220, -- [19]
				208220, -- [20]
				208220, -- [21]
				208220, -- [22]
				208220, -- [23]
				208220, -- [24]
				208220, -- [25]
				208220, -- [26]
				208220, -- [27]
				208220, -- [28]
				208220, -- [29]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
			},
			["TimeWindows"] = {
				["TimeDamage"] = {
					17.22, -- [1]
				},
				["Damage"] = {
					75907, -- [1]
				},
				["DOT_Time"] = {
					24, -- [1]
				},
				["ActiveTime"] = {
					17.22, -- [1]
				},
			},
			["enClass"] = "WARRIOR",
			["unit"] = "刃断-阿尔萨斯",
			["level"] = 120,
			["LastFightIn"] = 3,
			["type"] = "Ungrouped",
			["FightsSaved"] = 5,
			["LastActive"] = 4972.046,
			["LastEventHealthMax"] = {
				208220, -- [1]
				208220, -- [2]
				208220, -- [3]
				208220, -- [4]
				208220, -- [5]
				208220, -- [6]
				208220, -- [7]
				208220, -- [8]
				208220, -- [9]
				208220, -- [10]
				208220, -- [11]
				208220, -- [12]
				208220, -- [13]
				208220, -- [14]
				208220, -- [15]
				208220, -- [16]
				208220, -- [17]
				208220, -- [18]
				208220, -- [19]
				208220, -- [20]
				208220, -- [21]
				208220, -- [22]
				208220, -- [23]
				208220, -- [24]
				208220, -- [25]
				208220, -- [26]
				208220, -- [27]
				208220, -- [28]
				208220, -- [29]
			},
			["Owner"] = false,
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				true, -- [27]
				false, -- [28]
				false, -- [29]
			},
			["NextEventNum"] = 30,
			["LastDamageTime"] = 4972.063,
			["LastEvents"] = {
				"刃断-阿尔萨斯 冲锋 石怒 Hit -361 (Physical)", -- [1]
				"刃断-阿尔萨斯 灭战者 石怒 Hit -13530 (Physical)", -- [2]
				"刃断-阿尔萨斯 碎颅打击 石怒 Crit -6885 (Physical)", -- [3]
				"刃断-阿尔萨斯 致死打击 石怒 Hit -4877 (Physical)", -- [4]
				"刃断-阿尔萨斯 重伤 (伤害/跳) 石怒 Crit -5084 (Physical)", -- [5]
				"刃断-阿尔萨斯 压制 石怒 Hit -3098 (Physical)", -- [6]
				"刃断-阿尔萨斯 地震波 石怒 Crit -1315 (Physical)", -- [7]
				"刃断-阿尔萨斯 重伤 (伤害/跳) 石怒 Tick -2542 (Physical)", -- [8]
				"刃断-阿尔萨斯 猛击 石怒 Hit -1229 (Physical)", -- [9]
				"刃断-阿尔萨斯 重伤 (伤害/跳) 石怒 Tick -1271 (Physical)", -- [10]
				"刃断-阿尔萨斯 致死打击 石怒 Crit -5852 (Physical)", -- [11]
				"刃断-阿尔萨斯 压制 石怒 Hit -1994 (Physical)", -- [12]
				"刃断-阿尔萨斯 重伤 (伤害/跳) 石怒 Tick -1271 (Physical)", -- [13]
				"刃断-阿尔萨斯 地震波 石怒 Hit -328 (Physical)", -- [14]
				"刃断-阿尔萨斯 剑刃风暴 石怒 Hit -1147 (Physical)", -- [15]
				"刃断-阿尔萨斯 重伤 (伤害/跳) 石怒 Tick -1300 (Physical)", -- [16]
				"刃断-阿尔萨斯 剑刃风暴 石怒 Crit -2347 (Physical)", -- [17]
				"刃断-阿尔萨斯 剑刃风暴 石怒 Hit -1845 (Physical)", -- [18]
				"刃断-阿尔萨斯 重伤 (伤害/跳) 石怒 Tick -1905 (Physical)", -- [19]
				"刃断-阿尔萨斯 剑刃风暴 石怒 Hit -1886 (Physical)", -- [20]
				"刃断-阿尔萨斯 听从我的召唤 石怒 Hit -1636 (Nature)", -- [21]
				"刃断-阿尔萨斯 听从我的召唤 石怒 Hit -701 (Nature)", -- [22]
				"刃断-阿尔萨斯 剑刃风暴 石怒 Hit -1926 (Physical)", -- [23]
				"刃断-阿尔萨斯 重伤 (伤害/跳) 石怒 Tick -1986 (Physical)", -- [24]
				"刃断-阿尔萨斯 剑刃风暴 石怒 Hit -1966 (Physical)", -- [25]
				"刃断-阿尔萨斯 剑刃风暴 石怒 Hit -1672 (Physical)", -- [26]
				"石怒 肉搏 刃断-阿尔萨斯 Parry (1)", -- [27]
				"刃断-阿尔萨斯 重伤 (伤害/跳) 石怒 Tick -1689 (Physical)", -- [28]
				"刃断-阿尔萨斯 致死打击 石怒 Hit -4264 (Physical)", -- [29]
			},
			["Name"] = "刃断-阿尔萨斯",
			["LastEventTimes"] = {
				4956.142, -- [1]
				4957.009, -- [2]
				4958.256, -- [3]
				4959.563, -- [4]
				4961.264, -- [5]
				4962.038, -- [6]
				4962.158, -- [7]
				4962.782, -- [8]
				4963.268, -- [9]
				4964.243, -- [10]
				4964.444, -- [11]
				4965.786, -- [12]
				4965.786, -- [13]
				4965.914, -- [14]
				4967.134, -- [15]
				4967.416, -- [16]
				4967.635, -- [17]
				4968.476, -- [18]
				4968.768, -- [19]
				4969.188, -- [20]
				4969.531, -- [21]
				4969.531, -- [22]
				4970.146, -- [23]
				4970.261, -- [24]
				4970.688, -- [25]
				4971.366, -- [26]
				4971.69, -- [27]
				4971.69, -- [28]
				4972.063, -- [29]
			},
			["Fights"] = {
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["DOTs"] = {
						["重伤 (伤害/跳)"] = {
							["Details"] = {
								["石怒"] = {
									["count"] = 24,
								},
							},
							["amount"] = 24,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Attacks"] = {
						["致死打击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5852,
									["min"] = 5852,
									["count"] = 1,
									["amount"] = 5852,
								},
								["Hit"] = {
									["max"] = 4877,
									["min"] = 4264,
									["count"] = 2,
									["amount"] = 9141,
								},
							},
							["count"] = 3,
							["amount"] = 14993,
						},
						["压制"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 3098,
									["min"] = 1994,
									["count"] = 2,
									["amount"] = 5092,
								},
							},
							["count"] = 2,
							["amount"] = 5092,
						},
						["重伤 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5084,
									["min"] = 5084,
									["count"] = 1,
									["amount"] = 5084,
								},
								["Tick"] = {
									["max"] = 2542,
									["min"] = 1271,
									["count"] = 7,
									["amount"] = 11964,
								},
							},
							["count"] = 8,
							["amount"] = 17048,
						},
						["灭战者"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 13530,
									["min"] = 13530,
									["count"] = 1,
									["amount"] = 13530,
								},
							},
							["count"] = 1,
							["amount"] = 13530,
						},
						["猛击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1229,
									["min"] = 1229,
									["count"] = 1,
									["amount"] = 1229,
								},
							},
							["count"] = 1,
							["amount"] = 1229,
						},
						["剑刃风暴"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2347,
									["min"] = 2347,
									["count"] = 1,
									["amount"] = 2347,
								},
								["Hit"] = {
									["max"] = 1966,
									["min"] = 1147,
									["count"] = 6,
									["amount"] = 10442,
								},
							},
							["count"] = 7,
							["amount"] = 12789,
						},
						["听从我的召唤"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1636,
									["min"] = 701,
									["count"] = 2,
									["amount"] = 2337,
								},
							},
							["count"] = 2,
							["amount"] = 2337,
						},
						["冲锋"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 361,
									["min"] = 361,
									["count"] = 1,
									["amount"] = 361,
								},
							},
							["count"] = 1,
							["amount"] = 361,
						},
						["碎颅打击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6885,
									["min"] = 6885,
									["count"] = 1,
									["amount"] = 6885,
								},
							},
							["count"] = 1,
							["amount"] = 6885,
						},
						["地震波"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1315,
									["min"] = 1315,
									["count"] = 1,
									["amount"] = 1315,
								},
								["Hit"] = {
									["max"] = 328,
									["min"] = 328,
									["count"] = 1,
									["amount"] = 328,
								},
							},
							["count"] = 2,
							["amount"] = 1643,
						},
					},
					["TimeSpent"] = {
						["石怒"] = {
							["Details"] = {
								["致死打击"] = {
									["count"] = 1.88,
								},
								["压制"] = {
									["count"] = 2.11,
								},
								["重伤 (伤害/跳)"] = {
									["count"] = 4.11,
								},
								["灭战者"] = {
									["count"] = 0.87,
								},
								["猛击"] = {
									["count"] = 0.49,
								},
								["剑刃风暴"] = {
									["count"] = 4.42,
								},
								["听从我的召唤"] = {
									["count"] = 0.34,
								},
								["冲锋"] = {
									["count"] = 1.5,
								},
								["碎颅打击"] = {
									["count"] = 1.25,
								},
								["地震波"] = {
									["count"] = 0.25,
								},
							},
							["amount"] = 17.22,
						},
					},
					["ElementHitsDone"] = {
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 7,
								},
								["Crit"] = {
									["count"] = 5,
								},
								["Hit"] = {
									["count"] = 14,
								},
							},
							["amount"] = 26,
						},
					},
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Nature"] = 2337,
						["Physical"] = 73570,
					},
					["ActiveTime"] = 17.22,
					["DamagedWho"] = {
						["石怒"] = {
							["Details"] = {
								["致死打击"] = {
									["count"] = 14993,
								},
								["压制"] = {
									["count"] = 5092,
								},
								["重伤 (伤害/跳)"] = {
									["count"] = 17048,
								},
								["灭战者"] = {
									["count"] = 13530,
								},
								["猛击"] = {
									["count"] = 1229,
								},
								["剑刃风暴"] = {
									["count"] = 12789,
								},
								["听从我的召唤"] = {
									["count"] = 2337,
								},
								["冲锋"] = {
									["count"] = 361,
								},
								["碎颅打击"] = {
									["count"] = 6885,
								},
								["地震波"] = {
									["count"] = 1643,
								},
							},
							["amount"] = 75907,
						},
					},
					["TimeDamage"] = 17.22,
					["TimeDamaging"] = {
						["石怒"] = {
							["Details"] = {
								["致死打击"] = {
									["count"] = 1.88,
								},
								["压制"] = {
									["count"] = 2.11,
								},
								["重伤 (伤害/跳)"] = {
									["count"] = 4.11,
								},
								["灭战者"] = {
									["count"] = 0.87,
								},
								["猛击"] = {
									["count"] = 0.49,
								},
								["剑刃风暴"] = {
									["count"] = 4.42,
								},
								["听从我的召唤"] = {
									["count"] = 0.34,
								},
								["冲锋"] = {
									["count"] = 1.5,
								},
								["碎颅打击"] = {
									["count"] = 1.25,
								},
								["地震波"] = {
									["count"] = 0.25,
								},
							},
							["amount"] = 17.22,
						},
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
					},
					["DOT_Time"] = 24,
					["Damage"] = 75907,
				},
			},
			["TimeLast"] = {
				["ActiveTime"] = 4972.046,
				["TimeDamage"] = 4972.046,
				["OVERALL"] = 4972.046,
				["DOT_Time"] = 4971.045,
				["Damage"] = 4972.046,
			},
			["UnitLockout"] = 4956.046,
			["LastAbility"] = 8381.057,
		},
		["流星逐雨"] = {
			["GUID"] = "Player-1950-05E85D53",
			["LastEventHealth"] = {
				36037, -- [1]
				36037, -- [2]
				36037, -- [3]
				36037, -- [4]
				18847, -- [5]
				32236, -- [6]
				32236, -- [7]
				32236, -- [8]
				32258, -- [9]
				32258, -- [10]
				32258, -- [11]
				32280, -- [12]
				32635, -- [13]
				32635, -- [14]
				34630, -- [15]
				34630, -- [16]
				34630, -- [17]
				34630, -- [18]
				34673, -- [19]
				34673, -- [20]
				34673, -- [21]
				34673, -- [22]
				34673, -- [23]
				34673, -- [24]
				34673, -- [25]
				34673, -- [26]
				34673, -- [27]
				34673, -- [28]
				34673, -- [29]
				35309, -- [30]
				35309, -- [31]
				35353, -- [32]
				35353, -- [33]
				35353, -- [34]
				35353, -- [35]
				35353, -- [36]
				35353, -- [37]
				35353, -- [38]
				35353, -- [39]
				35353, -- [40]
				35353, -- [41]
				35353, -- [42]
				35353, -- [43]
				35353, -- [44]
				35353, -- [45]
				35396, -- [46]
				36037, -- [47]
				36037, -- [48]
				36037, -- [49]
				36037, -- [50]
			},
			["LastAttackedBy"] = "Environment",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"HEAL", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"HEAL", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"HEAL", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"HEAL", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					314.92, -- [1]
				},
				["Healing"] = {
					153731, -- [1]
				},
				["DamageTaken"] = {
					344714, -- [1]
				},
				["HOT_Time"] = {
					57, -- [1]
				},
				["Absorbs"] = {
					116304, -- [1]
				},
				["HealingTaken"] = {
					271844, -- [1]
				},
				["Overhealing"] = {
					70084, -- [1]
				},
				["Interrupts"] = {
					4, -- [1]
				},
				["TimeDamage"] = {
					477.730000000001, -- [1]
				},
				["ActiveTime"] = {
					792.650000000001, -- [1]
				},
				["DOT_Time"] = {
					1977, -- [1]
				},
				["Damage"] = {
					1353047, -- [1]
				},
			},
			["enClass"] = "PRIEST",
			["unit"] = "流星逐雨",
			["LastActive"] = 5167.405,
			["LastEventHealthMax"] = {
				39060, -- [1]
				39060, -- [2]
				39060, -- [3]
				39060, -- [4]
				39060, -- [5]
				39060, -- [6]
				39060, -- [7]
				39060, -- [8]
				39060, -- [9]
				39060, -- [10]
				39060, -- [11]
				39060, -- [12]
				39060, -- [13]
				39060, -- [14]
				39060, -- [15]
				39060, -- [16]
				39060, -- [17]
				39060, -- [18]
				39060, -- [19]
				39060, -- [20]
				39060, -- [21]
				39060, -- [22]
				39060, -- [23]
				39060, -- [24]
				39060, -- [25]
				39060, -- [26]
				39060, -- [27]
				39060, -- [28]
				39060, -- [29]
				39060, -- [30]
				39060, -- [31]
				39060, -- [32]
				39060, -- [33]
				39060, -- [34]
				39060, -- [35]
				39060, -- [36]
				39060, -- [37]
				39060, -- [38]
				39060, -- [39]
				39060, -- [40]
				39060, -- [41]
				39060, -- [42]
				39060, -- [43]
				39060, -- [44]
				39060, -- [45]
				39060, -- [46]
				39060, -- [47]
				39060, -- [48]
				39060, -- [49]
				39060, -- [50]
			},
			["LastHealTime"] = 5130.574,
			["level"] = 111,
			["LastDamageAbility"] = "Falling",
			["LastFightIn"] = 34,
			["TimeLast"] = {
				["TimeHeal"] = 5130.398,
				["OVERALL"] = 5167.405,
				["Healing"] = 5129.398,
				["DamageTaken"] = 5167.405,
				["HOT_Time"] = 4830.402,
				["Absorbs"] = 5130.398,
				["HealingTaken"] = 5130.398,
				["Overhealing"] = 5101.416,
				["TimeDamage"] = 5130.398,
				["Interrupts"] = 5102.416,
				["ActiveTime"] = 5130.398,
				["DOT_Time"] = 5130.398,
				["Damage"] = 5130.398,
			},
			["type"] = "Self",
			["FightsSaved"] = 5,
			["GuardianReverseGUIDs"] = {
				["车队护卫"] = {
					["LatestGuardian"] = 1,
					["GUIDs"] = {
						"Creature-0-3917-1642-9039-148487-0000407623", -- [1]
						[0] = "Creature-0-3917-1642-9039-148487-0000407608",
					},
				},
				["塔兰吉公主"] = {
					["LatestGuardian"] = 0,
					["GUIDs"] = {
						[0] = "Creature-0-3046-1642-16762-121241-0000431BF2",
					},
				},
			},
			["LastEventIncoming"] = {
				false, -- [1]
				true, -- [2]
				false, -- [3]
				false, -- [4]
				true, -- [5]
				true, -- [6]
				true, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				true, -- [11]
				false, -- [12]
				true, -- [13]
				false, -- [14]
				true, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				true, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				true, -- [30]
				false, -- [31]
				true, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				false, -- [37]
				false, -- [38]
				false, -- [39]
				false, -- [40]
				false, -- [41]
				true, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				false, -- [46]
				true, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["Owner"] = false,
			["Pet"] = {
				"车队护卫 <流星逐雨>", -- [1]
				"塔兰吉公主 <流星逐雨>", -- [2]
			},
			["NextEventNum"] = 6,
			["LastDamageTime"] = 5131.145,
			["LastEvents"] = {
				"流星逐雨 心灵震爆 原始恐天飞龙 Crit -4662 (Shadow)", -- [1]
				"原始恐天飞龙 肉搏 流星逐雨 Absorb -472 (472 被吸收) (1)", -- [2]
				"流星逐雨 暗影幻灵 原始恐天飞龙 Hit -389 (Shadow)", -- [3]
				"流星逐雨 暗言术：痛 (伤害/跳) 原始恐天飞龙 Tick -384 (Shadow)", -- [4]
				"Environment Falling 流星逐雨 Hit -20213 (Physical)", -- [5]
				"流星逐雨 吸血鬼之触 流星逐雨 Hit +355", -- [6]
				"加卡迪克斯 肉搏 流星逐雨 Miss (1)", -- [7]
				"流星逐雨 暗影幻灵 加卡迪克斯 Hit -434 (Shadow)", -- [8]
				"流星逐雨 暗言术：灭 加卡迪克斯 Hit -3257 (Shadow)", -- [9]
				"流星逐雨 暗言术：痛 (伤害/跳) 加卡迪克斯 Crit -853 (Shadow)", -- [10]
				"加卡迪克斯 肉搏 流星逐雨 Absorb -846 (846 被吸收) (1)", -- [11]
				"流星逐雨 吸血鬼之触 (伤害/跳) 加卡迪克斯 Tick -711 (Shadow)", -- [12]
				"流星逐雨 吸血鬼之触 流星逐雨 Hit +355", -- [13]
				"流星逐雨 虚空箭 加卡迪克斯 Hit -2587 (Shadow)", -- [14]
				"原始恐天飞龙 肉搏 流星逐雨 Absorb -517 (517 被吸收) (1)", -- [15]
				"流星逐雨 被勾住 (伤害/跳) 原始恐天飞龙 Tick -691 (Physical)", -- [16]
				"流星逐雨 被勾住 (伤害/跳) 原始恐天飞龙 Tick -692 (Physical)", -- [17]
				"流星逐雨 被勾住 (伤害/跳) 原始恐天飞龙 Tick -692 (Physical)", -- [18]
				"流星逐雨 被勾住 (伤害/跳) 原始恐天飞龙 Tick -692 (Physical)", -- [19]
				"流星逐雨 被勾住 (伤害/跳) 原始恐天飞龙 Tick -692 (Physical)", -- [20]
				"原始恐天飞龙 肉搏 流星逐雨 Absorb -607 (607 被吸收) (1)", -- [21]
				"流星逐雨 被勾住 (伤害/跳) 原始恐天飞龙 Tick -691 (Physical)", -- [22]
				"流星逐雨 心灵震爆 原始恐天飞龙 Hit -2313 (Shadow)", -- [23]
				"流星逐雨 暗言术：痛 (伤害/跳) 原始恐天飞龙 Tick -382 (Shadow)", -- [24]
				"流星逐雨 被勾住 (伤害/跳) 原始恐天飞龙 Tick -692 (Physical)", -- [25]
				"流星逐雨 被勾住 (伤害/跳) 原始恐天飞龙 Tick -691 (Physical)", -- [26]
				"流星逐雨 被勾住 (伤害/跳) 原始恐天飞龙 Tick -692 (Physical)", -- [27]
				"流星逐雨 精神鞭笞 (伤害/跳) 原始恐天飞龙 Tick -715 (Shadow)", -- [28]
				"流星逐雨 吸血鬼之触 (伤害/跳) 原始恐天飞龙 Crit -1272 (Shadow)", -- [29]
				"流星逐雨 吸血鬼之触 流星逐雨 Hit +636", -- [30]
				"流星逐雨 被勾住 (伤害/跳) 原始恐天飞龙 Tick -692 (Physical)", -- [31]
				"原始恐天飞龙 肉搏 流星逐雨 Absorb -516 (516 被吸收) (1)", -- [32]
				"流星逐雨 被勾住 (伤害/跳) 原始恐天飞龙 Tick -691 (Physical)", -- [33]
				"流星逐雨 精神鞭笞 (伤害/跳) 原始恐天飞龙 Tick -715 (Shadow)", -- [34]
				"流星逐雨 被勾住 (伤害/跳) 原始恐天飞龙 Tick -691 (Physical)", -- [35]
				"流星逐雨 暗言术：痛 (伤害/跳) 原始恐天飞龙 Crit -763 (Shadow)", -- [36]
				"流星逐雨 被勾住 (伤害/跳) 原始恐天飞龙 Tick -692 (Physical)", -- [37]
				"流星逐雨 精神鞭笞 (伤害/跳) 原始恐天飞龙 Tick -715 (Shadow)", -- [38]
				"流星逐雨 被勾住 (伤害/跳) 原始恐天飞龙 Tick -691 (Physical)", -- [39]
				"流星逐雨 精神鞭笞 (伤害/跳) 原始恐天飞龙 Tick -715 (Shadow)", -- [40]
				"流星逐雨 被勾住 (伤害/跳) 原始恐天飞龙 Tick -692 (Physical)", -- [41]
				"原始恐天飞龙 肉搏 流星逐雨 Absorb -421 (421 被吸收) (1)", -- [42]
				"流星逐雨 被勾住 (伤害/跳) 原始恐天飞龙 Tick -693 (Physical)", -- [43]
				"流星逐雨 暗影幻灵 原始恐天飞龙 Hit -389 (Shadow)", -- [44]
				"流星逐雨 被勾住 (伤害/跳) 原始恐天飞龙 Tick -462 (Physical)", -- [45]
				"流星逐雨 吸血鬼之触 (伤害/跳) 原始恐天飞龙 Crit -1282 (Shadow)", -- [46]
				"流星逐雨 吸血鬼之触 流星逐雨 Hit +641", -- [47]
				"流星逐雨 暗言术：痛 (伤害/跳) 原始恐天飞龙 Crit -769 (Shadow)", -- [48]
				"流星逐雨 精神鞭笞 (伤害/跳) 原始恐天飞龙 Tick -721 (Shadow)", -- [49]
				"流星逐雨 精神鞭笞 (伤害/跳) 原始恐天飞龙 Tick -721 (Shadow)", -- [50]
			},
			["Name"] = "流星逐雨",
			["LastEventTimes"] = {
				5130.356, -- [1]
				5130.574, -- [2]
				5130.778, -- [3]
				5131.145, -- [4]
				5168.038, -- [5]
				5110.226, -- [6]
				5110.325, -- [7]
				5110.744, -- [8]
				5111.132, -- [9]
				5111.744, -- [10]
				5111.899, -- [11]
				5112.53, -- [12]
				5112.53, -- [13]
				5112.659, -- [14]
				5124.549, -- [15]
				5124.549, -- [16]
				5124.944, -- [17]
				5125.262, -- [18]
				5125.559, -- [19]
				5125.779, -- [20]
				5126.079, -- [21]
				5126.168, -- [22]
				5126.28, -- [23]
				5126.48, -- [24]
				5126.48, -- [25]
				5126.731, -- [26]
				5127, -- [27]
				5127, -- [28]
				5127.215, -- [29]
				5127.215, -- [30]
				5127.325, -- [31]
				5127.566, -- [32]
				5127.566, -- [33]
				5127.675, -- [34]
				5127.969, -- [35]
				5127.969, -- [36]
				5128.225, -- [37]
				5128.225, -- [38]
				5128.537, -- [39]
				5128.832, -- [40]
				5128.832, -- [41]
				5128.996, -- [42]
				5129.159, -- [43]
				5129.159, -- [44]
				5129.287, -- [45]
				5129.56, -- [46]
				5129.56, -- [47]
				5129.56, -- [48]
				5129.671, -- [49]
				5130.226, -- [50]
			},
			["Fights"] = {
				["Fight3"] = {
					["Ressed"] = 0,
					["ElementTakenBlock"] = {
					},
					["DOTs"] = {
						["精神鞭笞 (伤害/跳)"] = {
							["Details"] = {
								["鲜血巨魔妖术师"] = {
									["count"] = 0,
								},
								["原始恐天飞龙"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["吸血鬼之触 (伤害/跳)"] = {
							["Details"] = {
								["鲜血巨魔妖术师"] = {
									["count"] = 0,
								},
								["生病的细颚龙"] = {
									["count"] = 0,
								},
								["原始恐天飞龙"] = {
									["count"] = 30,
								},
							},
							["amount"] = 30,
						},
						["暗言术：痛 (伤害/跳)"] = {
							["Details"] = {
								["原始恐天飞龙"] = {
									["count"] = 48,
								},
								["生病的细颚龙"] = {
									["count"] = 0,
								},
								["鲜血巨魔妖术师"] = {
									["count"] = 0,
								},
								["盐脊三叶虫"] = {
									["count"] = 0,
								},
								["第七军团掠夺者"] = {
									["count"] = 0,
								},
							},
							["amount"] = 48,
						},
						["被勾住 (伤害/跳)"] = {
							["Details"] = {
								["原始恐天飞龙"] = {
									["count"] = 102,
								},
							},
							["amount"] = 102,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementDoneResist"] = {
					},
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 1,
								},
								["Absorb"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 0,
								},
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 2,
						},
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 9,
								},
								["Hit"] = {
									["count"] = 9,
								},
								["Miss"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Dodge"] = {
									["count"] = 0,
								},
							},
							["amount"] = 20,
						},
						["Shadow"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamageTaken"] = 10715,
					["RageGainedFrom"] = {
					},
					["Absorbs"] = 5415,
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["DOT_Time"] = 182,
					["ElementDoneAbsorb"] = {
					},
					["ElementTaken"] = {
						["Physical"] = 778,
						["Melee"] = 9937,
						["Shadow"] = 0,
					},
					["HOTs"] = {
						["消散"] = {
							["Details"] = {
								["流星逐雨"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Damage"] = 60273,
					["PartialAbsorb"] = {
						["割裂"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["尖叫之嚎"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 778,
									["min"] = 778,
									["count"] = 1,
									["amount"] = 778,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 778,
						},
						["割裂 (伤害/跳)"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["斜掠 (伤害/跳)"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["斜掠"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗影箭"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["噬咬"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["低吼冲锋"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 11,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 607,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 4637,
								},
							},
							["count"] = 20,
							["amount"] = 4637,
						},
					},
					["TimeHeal"] = 18.96,
					["ShieldedWho"] = {
						["流星逐雨"] = {
							["Details"] = {
								["真言术：盾"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
					},
					["Dispels"] = 0,
					["HealingTaken"] = 8386,
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 9,
								},
								["Crit"] = {
									["count"] = 16,
								},
								["Tick"] = {
									["count"] = 17,
								},
							},
							["amount"] = 42,
						},
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 34,
								},
							},
							["amount"] = 34,
						},
					},
					["FAttacks"] = {
					},
					["CCBroken"] = {
					},
					["ElementDone"] = {
						["Shadow"] = 37392,
						["Physical"] = 22881,
					},
					["ManaGainedFrom"] = {
					},
					["DamagedWho"] = {
						["原始恐天飞龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 1155,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 9410,
								},
								["暗言术：灭"] = {
									["count"] = 5807,
								},
								["被勾住 (伤害/跳)"] = {
									["count"] = 22881,
								},
								["心灵震爆"] = {
									["count"] = 6837,
								},
								["精神灼烧"] = {
									["count"] = 4597,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 7471,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 2115,
								},
							},
							["amount"] = 60273,
						},
						["生病的细颚龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛"] = {
									["count"] = 0,
								},
								["精神灼烧"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鲜血巨魔妖术师"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["第七军团掠夺者"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["纳兹曼尼象鼻虫"] = {
							["Details"] = {
								["精神灼烧"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["盐脊三叶虫"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恐虱幼虫"] = {
							["Details"] = {
								["精神灼烧"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGainedFrom"] = {
					},
					["WhoDamaged"] = {
						["鲜血巨魔妖术师"] = {
							["Details"] = {
								["暗影箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["生病的细颚龙"] = {
							["Details"] = {
								["斜掠 (伤害/跳)"] = {
									["count"] = 0,
								},
								["斜掠"] = {
									["count"] = 0,
								},
								["割裂"] = {
									["count"] = 0,
								},
								["割裂 (伤害/跳)"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["盐脊三叶虫"] = {
							["Details"] = {
								["低吼冲锋"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始恐天飞龙"] = {
							["Details"] = {
								["尖叫之嚎"] = {
									["count"] = 778,
								},
								["肉搏"] = {
									["count"] = 9937,
								},
							},
							["amount"] = 10715,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["RageGained"] = {
					},
					["Absorbed"] = {
						["真言术：盾"] = {
							["Details"] = {
								["流星逐雨"] = {
									["max"] = 778,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 5415,
								},
							},
							["count"] = 10,
							["amount"] = 5415,
						},
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["流星逐雨"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 1.5,
								},
								["真言术：盾"] = {
									["count"] = 11.71,
								},
								["消散"] = {
									["count"] = 0,
								},
								["吸血鬼之触"] = {
									["count"] = 5.75,
								},
							},
							["amount"] = 18.96,
						},
					},
					["Dispelled"] = 0,
					["HealedWho"] = {
						["流星逐雨"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 759,
								},
								["真言术：盾"] = {
									["count"] = 5415,
								},
								["消散"] = {
									["count"] = 0,
								},
								["吸血鬼之触"] = {
									["count"] = 2212,
								},
							},
							["amount"] = 8386,
						},
					},
					["EnergyGain"] = 0,
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
						["Shadow"] = 0,
						["Melee"] = 4637,
						["Physical"] = 778,
					},
					["Overhealing"] = 5803,
					["PartialResist"] = {
						["割裂"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["尖叫之嚎"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["割裂 (伤害/跳)"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["斜掠 (伤害/跳)"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["斜掠"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗影箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["噬咬"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["低吼冲锋"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 20,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 20,
						},
					},
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["ActiveTime"] = 42.47,
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["原始恐天飞龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 1.48,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 4.72,
								},
								["暗言术：灭"] = {
									["count"] = 0.11,
								},
								["被勾住 (伤害/跳)"] = {
									["count"] = 8.82,
								},
								["心灵震爆"] = {
									["count"] = 1.72,
								},
								["精神灼烧"] = {
									["count"] = 1.09,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 5.22,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0.35,
								},
							},
							["amount"] = 23.51,
						},
						["生病的细颚龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["精神灼烧"] = {
									["count"] = 0,
								},
								["暗言术：痛"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["流星逐雨"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 1.5,
								},
								["真言术：盾"] = {
									["count"] = 11.71,
								},
								["消散"] = {
									["count"] = 0,
								},
								["吸血鬼之触"] = {
									["count"] = 5.75,
								},
							},
							["amount"] = 18.96,
						},
						["鲜血巨魔妖术师"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["第七军团掠夺者"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["盐脊三叶虫"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恐虱幼虫"] = {
							["Details"] = {
								["精神灼烧"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RessedWho"] = {
					},
					["InterruptData"] = {
					},
					["Interrupts"] = 0,
					["Heals"] = {
						["冷漠面容"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 169,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 169,
								},
								["Hit"] = {
									["max"] = 590,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 590,
								},
							},
							["count"] = 2,
							["amount"] = 759,
						},
						["真言术：盾"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 778,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 5415,
								},
							},
							["count"] = 10,
							["amount"] = 5415,
						},
						["消散"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["吸血鬼之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 631,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 2212,
								},
							},
							["count"] = 6,
							["amount"] = 2212,
						},
					},
					["WhoHealed"] = {
						["流星逐雨"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 759,
								},
								["真言术：盾"] = {
									["count"] = 5415,
								},
								["消散"] = {
									["count"] = 0,
								},
								["吸血鬼之触"] = {
									["count"] = 2212,
								},
							},
							["amount"] = 8386,
						},
					},
					["EnergyGained"] = {
					},
					["OverHeals"] = {
						["冷漠面容"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 3802,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 3802,
								},
								["Hit"] = {
									["max"] = 1389,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 1389,
								},
							},
							["count"] = 2,
							["amount"] = 5191,
						},
						["吸血鬼之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 612,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 612,
								},
							},
							["count"] = 1,
							["amount"] = 612,
						},
					},
					["Healing"] = 2971,
					["RunicPowerGained"] = {
					},
					["FDamagedWho"] = {
					},
					["Attacks"] = {
						["暗影幻灵"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 385,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 1155,
								},
							},
							["count"] = 3,
							["amount"] = 1155,
						},
						["暗言术：灭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5807,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 5807,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 5807,
						},
						["虚空箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["心灵震爆"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 2296,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 6837,
								},
							},
							["count"] = 3,
							["amount"] = 6837,
						},
						["暗言术：痛"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["精神鞭笞 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1410,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 1410,
								},
								["Tick"] = {
									["max"] = 705,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 705,
								},
							},
							["count"] = 2,
							["amount"] = 2115,
						},
						["精神灼烧"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 886,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 3377,
								},
								["Hit"] = {
									["max"] = 424,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 1220,
								},
							},
							["count"] = 7,
							["amount"] = 4597,
						},
						["虚空爆发"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["吸血鬼之触 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1263,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 6275,
								},
								["Tick"] = {
									["max"] = 631,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 3135,
								},
							},
							["count"] = 10,
							["amount"] = 9410,
						},
						["暗言术：痛 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 752,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 3334,
								},
								["Tick"] = {
									["max"] = 379,
									["min"] = 0,
									["count"] = 11,
									["amount"] = 4137,
								},
							},
							["count"] = 16,
							["amount"] = 7471,
						},
						["被勾住 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 687,
									["min"] = 458,
									["count"] = 34,
									["amount"] = 22881,
								},
							},
							["count"] = 34,
							["amount"] = 22881,
						},
					},
					["RageGain"] = 0,
					["PartialBlock"] = {
					},
					["TimeDamage"] = 23.51,
					["TimeDamaging"] = {
						["原始恐天飞龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 1.48,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 4.72,
								},
								["暗言术：灭"] = {
									["count"] = 0.11,
								},
								["被勾住 (伤害/跳)"] = {
									["count"] = 8.82,
								},
								["心灵震爆"] = {
									["count"] = 1.72,
								},
								["精神灼烧"] = {
									["count"] = 1.09,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 5.22,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0.35,
								},
							},
							["amount"] = 23.51,
						},
						["生病的细颚龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["精神灼烧"] = {
									["count"] = 0,
								},
								["暗言术：痛"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鲜血巨魔妖术师"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["第七军团掠夺者"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["盐脊三叶虫"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恐虱幼虫"] = {
							["Details"] = {
								["精神灼烧"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["ElementTakenResist"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight5"] = {
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
								["Absorb"] = {
									["count"] = 8,
								},
								["Crit"] = {
									["count"] = 2,
								},
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 13,
						},
						["Arcane"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTakenBlock"] = {
					},
					["DOTs"] = {
						["吸血鬼之触 (伤害/跳)"] = {
							["Details"] = {
								["原始钳嘴鳄"] = {
									["count"] = 0,
								},
								["鲜血巨魔妖术师"] = {
									["count"] = 0,
								},
								["原始恐天飞龙"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
						["暗言术：痛 (伤害/跳)"] = {
							["Details"] = {
								["鲜血巨魔妖术师"] = {
									["count"] = 0,
								},
								["第七军团掠夺者"] = {
									["count"] = 0,
								},
								["原始钳嘴鳄"] = {
									["count"] = 0,
								},
								["原始恐天飞龙"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
						["精神鞭笞 (伤害/跳)"] = {
							["Details"] = {
								["原始钳嘴鳄"] = {
									["count"] = 0,
								},
								["鲜血巨魔妖术师"] = {
									["count"] = 0,
								},
								["原始恐天飞龙"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 6904,
					["RageGainedFrom"] = {
					},
					["Absorbs"] = 4569,
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["DOT_Time"] = 25,
					["ElementTaken"] = {
						["Physical"] = 0,
						["Melee"] = 6904,
						["Arcane"] = 0,
					},
					["HOTs"] = {
						["消散"] = {
							["Details"] = {
								["流星逐雨"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Damage"] = 28658,
					["RunicPowerGainedFrom"] = {
					},
					["TimeHeal"] = 13.49,
					["ShieldedWho"] = {
						["流星逐雨"] = {
							["Details"] = {
								["真言术：盾"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Dispels"] = 0,
					["HealingTaken"] = 5068,
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 9,
								},
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 17,
						},
					},
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Shadow"] = 28658,
					},
					["CCBroken"] = {
					},
					["DamagedWho"] = {
						["原始钳嘴鳄"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["生病的细颚龙"] = {
							["Details"] = {
								["虚空爆发"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["第七军团掠夺者"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鲜血巨魔妖术师"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始恐天飞龙"] = {
							["Details"] = {
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 2103,
								},
								["虚空爆发"] = {
									["count"] = 3608,
								},
								["虚空箭"] = {
									["count"] = 5097,
								},
								["心灵震爆"] = {
									["count"] = 15006,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 2056,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 788,
								},
							},
							["amount"] = 28658,
						},
					},
					["RageGained"] = {
					},
					["WhoDamaged"] = {
						["原始钳嘴鳄"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["艾泽里特融石者"] = {
							["Details"] = {
								["艾泽里特冲击"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鲜血巨魔妖术师"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始恐天飞龙"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 6904,
								},
							},
							["amount"] = 6904,
						},
						["亡刺幼体"] = {
							["Details"] = {
								["爪击"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["Absorbed"] = {
						["真言术：盾"] = {
							["Details"] = {
								["流星逐雨"] = {
									["max"] = 769,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 4569,
								},
							},
							["count"] = 8,
							["amount"] = 4569,
						},
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["流星逐雨"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 0,
								},
								["真言术：盾"] = {
									["count"] = 11.99,
								},
								["消散"] = {
									["count"] = 0,
								},
								["吸血鬼之触"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 13.49,
						},
					},
					["Dispelled"] = 0,
					["RessedWho"] = {
					},
					["HealedWho"] = {
						["流星逐雨"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 149,
								},
								["真言术：盾"] = {
									["count"] = 4569,
								},
								["消散"] = {
									["count"] = 0,
								},
								["吸血鬼之触"] = {
									["count"] = 350,
								},
							},
							["amount"] = 5068,
						},
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
						["Physical"] = 0,
						["Melee"] = 4569,
						["Arcane"] = 0,
					},
					["FDamage"] = 0,
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["PartialAbsorb"] = {
						["艾泽里特冲击"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["爪击"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 769,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 4569,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 13,
							["amount"] = 4569,
						},
					},
					["ActiveTime"] = 24.22,
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["原始钳嘴鳄"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["生病的细颚龙"] = {
							["Details"] = {
								["虚空爆发"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["流星逐雨"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 0,
								},
								["真言术：盾"] = {
									["count"] = 11.99,
								},
								["消散"] = {
									["count"] = 0,
								},
								["吸血鬼之触"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 13.49,
						},
						["鲜血巨魔妖术师"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["第七军团掠夺者"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始恐天飞龙"] = {
							["Details"] = {
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 1.52,
								},
								["虚空爆发"] = {
									["count"] = 0.11,
								},
								["虚空箭"] = {
									["count"] = 0.54,
								},
								["心灵震爆"] = {
									["count"] = 3.89,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 3.62,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 1.05,
								},
							},
							["amount"] = 10.73,
						},
					},
					["Overhealing"] = 1837,
					["InterruptData"] = {
						["原始恐天飞龙"] = {
							["Details"] = {
								["尖叫之嚎 (沉默)"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Interrupts"] = 1,
					["Heals"] = {
						["冷漠面容"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 149,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 149,
								},
							},
							["count"] = 1,
							["amount"] = 149,
						},
						["真言术：盾"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 769,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 4569,
								},
							},
							["count"] = 8,
							["amount"] = 4569,
						},
						["消散"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["吸血鬼之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 350,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 350,
								},
							},
							["count"] = 1,
							["amount"] = 350,
						},
					},
					["PartialResist"] = {
						["艾泽里特冲击"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["爪击"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 13,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 13,
						},
					},
					["EnergyGained"] = {
					},
					["WhoHealed"] = {
						["流星逐雨"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 149,
								},
								["真言术：盾"] = {
									["count"] = 4569,
								},
								["消散"] = {
									["count"] = 0,
								},
								["吸血鬼之触"] = {
									["count"] = 350,
								},
							},
							["amount"] = 5068,
						},
					},
					["Healing"] = 499,
					["OverHeals"] = {
						["冷漠面容"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1837,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 1837,
								},
							},
							["count"] = 1,
							["amount"] = 1837,
						},
						["消散"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["暗影幻灵"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗言术：灭"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["虚空箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 2549,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 5097,
								},
							},
							["count"] = 2,
							["amount"] = 5097,
						},
						["心灵震爆"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5098,
									["min"] = 5098,
									["count"] = 2,
									["amount"] = 10196,
								},
								["Hit"] = {
									["max"] = 2548,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 4810,
								},
							},
							["count"] = 4,
							["amount"] = 15006,
						},
						["暗言术：痛"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["精神鞭笞 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 788,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 788,
								},
							},
							["count"] = 1,
							["amount"] = 788,
						},
						["吸血鬼之触 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 701,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 2103,
								},
							},
							["count"] = 3,
							["amount"] = 2103,
						},
						["虚空爆发"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 1804,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 3608,
								},
							},
							["count"] = 2,
							["amount"] = 3608,
						},
						["暗言术：痛 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 420,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 2056,
								},
							},
							["count"] = 5,
							["amount"] = 2056,
						},
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 10.73,
					["TimeDamaging"] = {
						["原始钳嘴鳄"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["生病的细颚龙"] = {
							["Details"] = {
								["虚空爆发"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["第七军团掠夺者"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鲜血巨魔妖术师"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始恐天飞龙"] = {
							["Details"] = {
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 1.52,
								},
								["虚空爆发"] = {
									["count"] = 0.11,
								},
								["虚空箭"] = {
									["count"] = 0.54,
								},
								["心灵震爆"] = {
									["count"] = 3.89,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 3.62,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 1.05,
								},
							},
							["amount"] = 10.73,
						},
					},
					["ManaGain"] = 0,
					["ElementTakenResist"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["Ressed"] = 0,
					["ElementTakenBlock"] = {
					},
					["DOTs"] = {
						["精神鞭笞 (伤害/跳)"] = {
							["Details"] = {
								["原始钳嘴鳄"] = {
									["count"] = 0,
								},
								["生病的细颚龙"] = {
									["count"] = 0,
								},
								["第七军团掠夺者"] = {
									["count"] = 0,
								},
								["原始恐天飞龙"] = {
									["count"] = 0,
								},
								["鲜血巨魔蛮兵"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["吸血鬼之触 (伤害/跳)"] = {
							["Details"] = {
								["原始钳嘴鳄"] = {
									["count"] = 0,
								},
								["生病的细颚龙"] = {
									["count"] = 0,
								},
								["第七军团掠夺者"] = {
									["count"] = 0,
								},
								["原始恐天飞龙"] = {
									["count"] = 0,
								},
								["鲜血巨魔蛮兵"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暗言术：痛 (伤害/跳)"] = {
							["Details"] = {
								["原始钳嘴鳄"] = {
									["count"] = 0,
								},
								["生病的细颚龙"] = {
									["count"] = 0,
								},
								["第七军团掠夺者"] = {
									["count"] = 0,
								},
								["原始恐天飞龙"] = {
									["count"] = 0,
								},
								["鲜血巨魔蛮兵"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被勾住 (伤害/跳)"] = {
							["Details"] = {
								["原始恐天飞龙"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementDoneResist"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Dodge"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
								["Absorb"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["Absorbs"] = 0,
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["DOT_Time"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["ElementTaken"] = {
						["Melee"] = 0,
						["Physical"] = 0,
					},
					["HOTs"] = {
					},
					["Damage"] = 0,
					["PartialAbsorb"] = {
						["割裂"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["斜掠"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Falling"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["斜掠 (伤害/跳)"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["割裂 (伤害/跳)"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["TimeHeal"] = 0,
					["ShieldedWho"] = {
						["伊琳德丶星歌"] = {
							["Details"] = {
								["真言术：盾"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["流星逐雨"] = {
							["Details"] = {
								["真言术：盾"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Dispels"] = 0,
					["HealingTaken"] = 0,
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["FAttacks"] = {
					},
					["CCBroken"] = {
					},
					["ElementDone"] = {
						["Shadow"] = 0,
						["Physical"] = 0,
					},
					["ManaGainedFrom"] = {
					},
					["DamagedWho"] = {
						["原始钳嘴鳄"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["精神灼烧"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["第七军团焚化者"] = {
							["Details"] = {
								["暗言术：痛"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["生病的细颚龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["精神灼烧"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["第七军团掠夺者"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始恐天飞龙"] = {
							["Details"] = {
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["被勾住 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鲜血巨魔蛮兵"] = {
							["Details"] = {
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGainedFrom"] = {
					},
					["WhoDamaged"] = {
						["原始恐天飞龙"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["生病的细颚龙"] = {
							["Details"] = {
								["割裂"] = {
									["count"] = 0,
								},
								["斜掠"] = {
									["count"] = 0,
								},
								["斜掠 (伤害/跳)"] = {
									["count"] = 0,
								},
								["割裂 (伤害/跳)"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Environment"] = {
							["Details"] = {
								["Falling"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始钳嘴鳄"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鲜血巨魔蛮兵"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["RageGained"] = {
					},
					["Absorbed"] = {
						["真言术：盾"] = {
							["Details"] = {
								["流星逐雨"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["流星逐雨"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 0,
								},
								["真言术：盾"] = {
									["count"] = 0,
								},
								["吸血鬼之触"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Dispelled"] = 0,
					["HealedWho"] = {
						["流星逐雨"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 0,
								},
								["真言术：盾"] = {
									["count"] = 0,
								},
								["吸血鬼之触"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGain"] = 0,
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
						["Melee"] = 0,
						["Physical"] = 0,
					},
					["Overhealing"] = 0,
					["PartialResist"] = {
						["割裂"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["斜掠"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Falling"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["斜掠 (伤害/跳)"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["割裂 (伤害/跳)"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["ActiveTime"] = 0,
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["原始钳嘴鳄"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["精神灼烧"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["第七军团焚化者"] = {
							["Details"] = {
								["暗言术：痛"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["生病的细颚龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["精神灼烧"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["流星逐雨"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 0,
								},
								["真言术：盾"] = {
									["count"] = 0,
								},
								["吸血鬼之触"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["第七军团掠夺者"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始恐天飞龙"] = {
							["Details"] = {
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["被勾住 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鲜血巨魔蛮兵"] = {
							["Details"] = {
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RessedWho"] = {
					},
					["InterruptData"] = {
					},
					["Interrupts"] = 0,
					["Heals"] = {
						["冷漠面容"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["真言术：盾"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["吸血鬼之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
						["流星逐雨"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 0,
								},
								["真言术：盾"] = {
									["count"] = 0,
								},
								["吸血鬼之触"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGained"] = {
					},
					["OverHeals"] = {
						["冷漠面容"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["FDamagedWho"] = {
					},
					["Attacks"] = {
						["暗影幻灵"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗言术：灭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["虚空箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["心灵震爆"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗言术：痛"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["精神鞭笞 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["吸血鬼之触 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["虚空爆发"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["精神灼烧"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗言术：痛 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["被勾住 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["PartialBlock"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["原始钳嘴鳄"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["精神灼烧"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["第七军团焚化者"] = {
							["Details"] = {
								["暗言术：痛"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["生病的细颚龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["精神灼烧"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["第七军团掠夺者"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始恐天飞龙"] = {
							["Details"] = {
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["被勾住 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鲜血巨魔蛮兵"] = {
							["Details"] = {
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["ElementTakenResist"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight2"] = {
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 5,
								},
								["Dodge"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 13,
						},
						["Physical"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
								["Tick"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTakenBlock"] = {
					},
					["DOTs"] = {
						["精神鞭笞 (伤害/跳)"] = {
							["Details"] = {
								["原始钳嘴鳄"] = {
									["count"] = 0,
								},
								["鲜血巨魔妖术师"] = {
									["count"] = 0,
								},
								["原始恐天飞龙"] = {
									["count"] = 0,
								},
								["加卡迪克斯"] = {
									["count"] = 5,
								},
								["盐脊三叶虫"] = {
									["count"] = 0,
								},
							},
							["amount"] = 5,
						},
						["吸血鬼之触 (伤害/跳)"] = {
							["Details"] = {
								["原始钳嘴鳄"] = {
									["count"] = 0,
								},
								["鲜血巨魔妖术师"] = {
									["count"] = 0,
								},
								["原始恐天飞龙"] = {
									["count"] = 0,
								},
								["加卡迪克斯"] = {
									["count"] = 27,
								},
								["盐脊三叶虫"] = {
									["count"] = 0,
								},
							},
							["amount"] = 27,
						},
						["暗言术：痛 (伤害/跳)"] = {
							["Details"] = {
								["原始钳嘴鳄"] = {
									["count"] = 0,
								},
								["第七军团沙行者"] = {
									["count"] = 0,
								},
								["鲜血巨魔妖术师"] = {
									["count"] = 0,
								},
								["盐脊三叶虫"] = {
									["count"] = 0,
								},
								["加卡迪克斯"] = {
									["count"] = 39,
								},
								["原始恐天飞龙"] = {
									["count"] = 0,
								},
							},
							["amount"] = 39,
						},
						["被勾住 (伤害/跳)"] = {
							["Details"] = {
								["原始恐天飞龙"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 16991,
					["RageGainedFrom"] = {
					},
					["Absorbs"] = 6886,
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["DOT_Time"] = 71,
					["ElementTaken"] = {
						["Melee"] = 16991,
						["Physical"] = 0,
					},
					["HOTs"] = {
					},
					["Damage"] = 58791,
					["RunicPowerGainedFrom"] = {
					},
					["TimeHeal"] = 14.95,
					["ShieldedWho"] = {
						["流星逐雨"] = {
							["Details"] = {
								["真言术：盾"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["Dispels"] = 0,
					["HealingTaken"] = 10631,
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 20,
								},
								["Crit"] = {
									["count"] = 9,
								},
								["Hit"] = {
									["count"] = 13,
								},
							},
							["amount"] = 42,
						},
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Shadow"] = 58791,
						["Physical"] = 0,
					},
					["CCBroken"] = {
					},
					["DamagedWho"] = {
						["原始钳嘴鳄"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始恐天飞龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["被勾住 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["第七军团沙行者"] = {
							["Details"] = {
								["暗言术：痛"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鲜血巨魔妖术师"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["盐脊三叶虫"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神灼烧"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["加卡迪克斯"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 868,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 8513,
								},
								["虚空爆发"] = {
									["count"] = 3636,
								},
								["虚空箭"] = {
									["count"] = 18052,
								},
								["心灵震爆"] = {
									["count"] = 12916,
								},
								["暗言术：灭"] = {
									["count"] = 3257,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 6761,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 4788,
								},
							},
							["amount"] = 58791,
						},
						["三叶虫幼崽"] = {
							["Details"] = {
								["精神灼烧"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RageGained"] = {
					},
					["WhoDamaged"] = {
						["原始钳嘴鳄"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["生病的细颚龙"] = {
							["Details"] = {
								["斜掠 (伤害/跳)"] = {
									["count"] = 0,
								},
								["割裂 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始恐天飞龙"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["盐脊三叶虫"] = {
							["Details"] = {
								["噬咬 (伤害/跳)"] = {
									["count"] = 0,
								},
								["噬咬"] = {
									["count"] = 0,
								},
								["低吼冲锋"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["加卡迪克斯"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 16991,
								},
							},
							["amount"] = 16991,
						},
						["三叶虫幼崽"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["Absorbed"] = {
						["真言术：盾"] = {
							["Details"] = {
								["流星逐雨"] = {
									["max"] = 1591,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 6886,
								},
							},
							["count"] = 6,
							["amount"] = 6886,
						},
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["流星逐雨"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 1.5,
								},
								["真言术：盾"] = {
									["count"] = 8.37,
								},
								["暗影愈合"] = {
									["count"] = 0,
								},
								["吸血鬼之触"] = {
									["count"] = 5.08,
								},
							},
							["amount"] = 14.95,
						},
					},
					["Dispelled"] = 0,
					["RessedWho"] = {
					},
					["HealedWho"] = {
						["流星逐雨"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 1730,
								},
								["真言术：盾"] = {
									["count"] = 6886,
								},
								["暗影愈合"] = {
									["count"] = 0,
								},
								["吸血鬼之触"] = {
									["count"] = 2015,
								},
							},
							["amount"] = 10631,
						},
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
						["Melee"] = 6886,
						["Physical"] = 0,
					},
					["FDamage"] = 0,
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["PartialAbsorb"] = {
						["斜掠 (伤害/跳)"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["噬咬"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["噬咬 (伤害/跳)"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["低吼冲锋"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["割裂 (伤害/跳)"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 1591,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 6886,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 13,
							["amount"] = 6886,
						},
					},
					["ActiveTime"] = 36.5,
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["原始钳嘴鳄"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始恐天飞龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["被勾住 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["第七军团沙行者"] = {
							["Details"] = {
								["暗言术：痛"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["流星逐雨"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 1.5,
								},
								["真言术：盾"] = {
									["count"] = 8.37,
								},
								["暗影愈合"] = {
									["count"] = 0,
								},
								["吸血鬼之触"] = {
									["count"] = 5.08,
								},
							},
							["amount"] = 14.95,
						},
						["鲜血巨魔妖术师"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["盐脊三叶虫"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["加卡迪克斯"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0.97,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 3.76,
								},
								["虚空爆发"] = {
									["count"] = 0.11,
								},
								["虚空箭"] = {
									["count"] = 1.59,
								},
								["心灵震爆"] = {
									["count"] = 4.25,
								},
								["暗言术：灭"] = {
									["count"] = 0.39,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 7.46,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 3.02,
								},
							},
							["amount"] = 21.55,
						},
						["三叶虫幼崽"] = {
							["Details"] = {
								["精神灼烧"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Overhealing"] = 736,
					["InterruptData"] = {
						["加卡迪克斯"] = {
							["Details"] = {
								["尖叫之嚎 (沉默)"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Interrupts"] = 1,
					["Heals"] = {
						["冷漠面容"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 1730,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 1730,
								},
							},
							["count"] = 1,
							["amount"] = 1730,
						},
						["真言术：盾"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 1591,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 6886,
								},
							},
							["count"] = 6,
							["amount"] = 6886,
						},
						["暗影愈合"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["吸血鬼之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 711,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 2015,
								},
							},
							["count"] = 5,
							["amount"] = 2015,
						},
					},
					["PartialResist"] = {
						["斜掠 (伤害/跳)"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["噬咬"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["噬咬 (伤害/跳)"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["低吼冲锋"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["割裂 (伤害/跳)"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 13,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 13,
						},
					},
					["EnergyGained"] = {
					},
					["WhoHealed"] = {
						["流星逐雨"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 1730,
								},
								["真言术：盾"] = {
									["count"] = 6886,
								},
								["暗影愈合"] = {
									["count"] = 0,
								},
								["吸血鬼之触"] = {
									["count"] = 2015,
								},
							},
							["amount"] = 10631,
						},
					},
					["Healing"] = 3745,
					["OverHeals"] = {
						["冷漠面容"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 269,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 269,
								},
							},
							["count"] = 1,
							["amount"] = 269,
						},
						["吸血鬼之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 467,
									["min"] = 467,
									["count"] = 1,
									["amount"] = 467,
								},
							},
							["count"] = 1,
							["amount"] = 467,
						},
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["暗影幻灵"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 434,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 868,
								},
							},
							["count"] = 2,
							["amount"] = 868,
						},
						["暗言术：灭"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 3257,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 3257,
								},
							},
							["count"] = 1,
							["amount"] = 3257,
						},
						["虚空箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5136,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 5136,
								},
								["Hit"] = {
									["max"] = 2587,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 12916,
								},
							},
							["count"] = 6,
							["amount"] = 18052,
						},
						["心灵震爆"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5174,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 5174,
								},
								["Hit"] = {
									["max"] = 2587,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 7742,
								},
							},
							["count"] = 4,
							["amount"] = 12916,
						},
						["暗言术：痛"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["精神鞭笞 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1600,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 1600,
								},
								["Tick"] = {
									["max"] = 800,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 3188,
								},
							},
							["count"] = 5,
							["amount"] = 4788,
						},
						["吸血鬼之触 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1423,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 4258,
								},
								["Tick"] = {
									["max"] = 711,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 4255,
								},
							},
							["count"] = 9,
							["amount"] = 8513,
						},
						["虚空爆发"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 1818,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 3636,
								},
							},
							["count"] = 2,
							["amount"] = 3636,
						},
						["精神灼烧"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗言术：痛 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 853,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 2559,
								},
								["Tick"] = {
									["max"] = 427,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 4202,
								},
							},
							["count"] = 13,
							["amount"] = 6761,
						},
						["被勾住 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 21.55,
					["TimeDamaging"] = {
						["原始钳嘴鳄"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始恐天飞龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["被勾住 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["第七军团沙行者"] = {
							["Details"] = {
								["暗言术：痛"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鲜血巨魔妖术师"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["盐脊三叶虫"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["加卡迪克斯"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0.97,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 3.76,
								},
								["虚空爆发"] = {
									["count"] = 0.11,
								},
								["虚空箭"] = {
									["count"] = 1.59,
								},
								["心灵震爆"] = {
									["count"] = 4.25,
								},
								["暗言术：灭"] = {
									["count"] = 0.39,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 7.46,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 3.02,
								},
							},
							["amount"] = 21.55,
						},
						["三叶虫幼崽"] = {
							["Details"] = {
								["精神灼烧"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["ElementTakenResist"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight4"] = {
					["DOTs"] = {
						["吸血鬼之触 (伤害/跳)"] = {
							["Details"] = {
								["石怒"] = {
									["count"] = 0,
								},
								["生病的细颚龙"] = {
									["count"] = 0,
								},
								["第七军团掠夺者"] = {
									["count"] = 0,
								},
								["原始钳嘴鳄"] = {
									["count"] = 0,
								},
								["奥尔敏·箭击"] = {
									["count"] = 0,
								},
								["原始恐天飞龙"] = {
									["count"] = 12,
								},
								["鲜血幻影"] = {
									["count"] = 0,
								},
								["攻城的哨兵"] = {
									["count"] = 0,
								},
								["长母阿提娜"] = {
									["count"] = 0,
								},
							},
							["amount"] = 12,
						},
						["暗言术：痛 (伤害/跳)"] = {
							["Details"] = {
								["石怒"] = {
									["count"] = 0,
								},
								["生病的细颚龙"] = {
									["count"] = 0,
								},
								["第七军团掠夺者"] = {
									["count"] = 0,
								},
								["盐脊三叶虫"] = {
									["count"] = 0,
								},
								["原始钳嘴鳄"] = {
									["count"] = 0,
								},
								["奥尔敏·箭击"] = {
									["count"] = 0,
								},
								["原始恐天飞龙"] = {
									["count"] = 15,
								},
								["鲜血幻影"] = {
									["count"] = 0,
								},
								["攻城的哨兵"] = {
									["count"] = 0,
								},
								["长母阿提娜"] = {
									["count"] = 0,
								},
							},
							["amount"] = 15,
						},
						["精神鞭笞 (伤害/跳)"] = {
							["Details"] = {
								["石怒"] = {
									["count"] = 0,
								},
								["奥尔敏·箭击"] = {
									["count"] = 0,
								},
								["第七军团掠夺者"] = {
									["count"] = 0,
								},
								["原始恐天飞龙"] = {
									["count"] = 5,
								},
								["攻城的哨兵"] = {
									["count"] = 0,
								},
								["长母阿提娜"] = {
									["count"] = 0,
								},
							},
							["amount"] = 5,
						},
					},
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
								["Absorb"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 8,
								},
								["Absorb"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 8,
						},
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
						["流星逐雨"] = {
							["Details"] = {
								["吸血鬼之触"] = {
									["count"] = 1476,
								},
								["真言术：盾"] = {
									["count"] = 0,
								},
								["冷漠面容"] = {
									["count"] = 3127,
								},
							},
							["amount"] = 4603,
						},
					},
					["Absorbs"] = 0,
					["Overhealing"] = 843,
					["ElementTaken"] = {
						["Physical"] = 0,
						["Melee"] = 4162,
						["Shadow"] = 0,
					},
					["HOTs"] = {
						["生命之岩"] = {
							["Details"] = {
								["流星逐雨"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Damage"] = 28742,
					["TimeHeal"] = 6.8,
					["ShieldedWho"] = {
						["流星逐雨"] = {
							["Details"] = {
								["真言术：盾"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Shadow"] = 28742,
					},
					["DamagedWho"] = {
						["石怒"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["愤怒的守护者"] = {
							["Details"] = {
								["虚空爆发"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["生病的细颚龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神灼烧"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["第七军团掠夺者"] = {
							["Details"] = {
								["心灵震爆"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["盐脊三叶虫"] = {
							["Details"] = {
								["暗言术：痛"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恐虱幼虫"] = {
							["Details"] = {
								["精神灼烧"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始钳嘴鳄"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["精神灼烧"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["奥尔敏·箭击"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["艾泽里特融石者"] = {
							["Details"] = {
								["虚空爆发"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始恐天飞龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 1349,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 4308,
								},
								["虚空箭"] = {
									["count"] = 8065,
								},
								["心灵震爆"] = {
									["count"] = 7691,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 3424,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 3905,
								},
							},
							["amount"] = 28742,
						},
						["鲜血幻影"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["精神灼烧"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["攻城的哨兵"] = {
							["Details"] = {
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["长母阿提娜"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["精神灼烧"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDamaged"] = {
						["原始钳嘴鳄"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["生病的细颚龙"] = {
							["Details"] = {
								["割裂"] = {
									["count"] = 0,
								},
								["斜掠"] = {
									["count"] = 0,
								},
								["斜掠 (伤害/跳)"] = {
									["count"] = 0,
								},
								["割裂 (伤害/跳)"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Environment"] = {
							["Details"] = {
								["Falling"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始恐天飞龙"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 4162,
								},
							},
							["amount"] = 4162,
						},
						["鲜血幻影"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["攻城的哨兵"] = {
							["Details"] = {
								["射击"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
								["乱射"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["长母阿提娜"] = {
							["Details"] = {
								["噬血箭"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Absorbed"] = {
						["真言术：盾"] = {
							["Details"] = {
								["流星逐雨"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["TimeHealing"] = {
						["流星逐雨"] = {
							["Details"] = {
								["吸血鬼之触"] = {
									["count"] = 3.8,
								},
								["真言术：盾"] = {
									["count"] = 0,
								},
								["冷漠面容"] = {
									["count"] = 3,
								},
							},
							["amount"] = 6.8,
						},
					},
					["OverHeals"] = {
						["冷漠面容"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 840,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 843,
								},
							},
							["count"] = 2,
							["amount"] = 843,
						},
						["生命之岩"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["吸血鬼之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["PartialResist"] = {
						["噬血箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["割裂 (伤害/跳)"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Falling"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["斜掠"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 8,
						},
						["割裂"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["射击"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["斜掠 (伤害/跳)"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["乱射"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["噬血箭"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["割裂 (伤害/跳)"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["Falling"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["斜掠"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
						["割裂"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["射击"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["斜掠 (伤害/跳)"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["乱射"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 16.76,
					["InterruptData"] = {
						["石怒"] = {
							["Details"] = {
								["硬化 (沉默)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["长母阿提娜"] = {
							["Details"] = {
								["噬血箭 (沉默)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Heals"] = {
						["吸血鬼之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 758,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 1476,
								},
							},
							["count"] = 3,
							["amount"] = 1476,
						},
						["真言术：盾"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["冷漠面容"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 1982,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 3127,
								},
							},
							["count"] = 2,
							["amount"] = 3127,
						},
					},
					["HealedWho"] = {
						["流星逐雨"] = {
							["Details"] = {
								["吸血鬼之触"] = {
									["count"] = 1476,
								},
								["真言术：盾"] = {
									["count"] = 0,
								},
								["冷漠面容"] = {
									["count"] = 3127,
								},
							},
							["amount"] = 4603,
						},
					},
					["DOT_Time"] = 32,
					["Healing"] = 4603,
					["HOT_Time"] = 0,
					["DamageTaken"] = 4162,
					["Attacks"] = {
						["暗影幻灵"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 466,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 1349,
								},
							},
							["count"] = 3,
							["amount"] = 1349,
						},
						["暗言术：灭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["虚空箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5516,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 5516,
								},
								["Hit"] = {
									["max"] = 2549,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 2549,
								},
							},
							["count"] = 2,
							["amount"] = 8065,
						},
						["沉默"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗言术：痛"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["精神鞭笞 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 853,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 3905,
								},
							},
							["count"] = 5,
							["amount"] = 3905,
						},
						["吸血鬼之触 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1516,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 2872,
								},
								["Tick"] = {
									["max"] = 758,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 1436,
								},
							},
							["count"] = 4,
							["amount"] = 4308,
						},
						["虚空爆发"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["心灵震爆"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 4933,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 4933,
								},
								["Hit"] = {
									["max"] = 2758,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 2758,
								},
							},
							["count"] = 2,
							["amount"] = 7691,
						},
						["暗言术：痛 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 910,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 2564,
								},
								["Tick"] = {
									["max"] = 454,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 860,
								},
							},
							["count"] = 5,
							["amount"] = 3424,
						},
						["精神灼烧"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 4603,
					["Interrupts"] = 0,
					["TimeDamage"] = 9.96,
					["TimeDamaging"] = {
						["石怒"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["沉默"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["愤怒的守护者"] = {
							["Details"] = {
								["虚空爆发"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["生病的细颚龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神灼烧"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["第七军团掠夺者"] = {
							["Details"] = {
								["心灵震爆"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["盐脊三叶虫"] = {
							["Details"] = {
								["暗言术：痛"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恐虱幼虫"] = {
							["Details"] = {
								["精神灼烧"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始钳嘴鳄"] = {
							["Details"] = {
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["奥尔敏·箭击"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始恐天飞龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0.4,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 1.46,
								},
								["虚空箭"] = {
									["count"] = 2.22,
								},
								["心灵震爆"] = {
									["count"] = 1.65,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 2,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 2.23,
								},
							},
							["amount"] = 9.96,
						},
						["鲜血幻影"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["精神灼烧"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["攻城的哨兵"] = {
							["Details"] = {
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["长母阿提娜"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeSpent"] = {
						["石怒"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["沉默"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["愤怒的守护者"] = {
							["Details"] = {
								["虚空爆发"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["生病的细颚龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神灼烧"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["第七军团掠夺者"] = {
							["Details"] = {
								["心灵震爆"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["盐脊三叶虫"] = {
							["Details"] = {
								["暗言术：痛"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["恐虱幼虫"] = {
							["Details"] = {
								["精神灼烧"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始钳嘴鳄"] = {
							["Details"] = {
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["奥尔敏·箭击"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["流星逐雨"] = {
							["Details"] = {
								["吸血鬼之触"] = {
									["count"] = 3.8,
								},
								["真言术：盾"] = {
									["count"] = 0,
								},
								["冷漠面容"] = {
									["count"] = 3,
								},
							},
							["amount"] = 6.8,
						},
						["原始恐天飞龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0.4,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 1.46,
								},
								["虚空箭"] = {
									["count"] = 2.22,
								},
								["心灵震爆"] = {
									["count"] = 1.65,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 2,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 2.23,
								},
							},
							["amount"] = 9.96,
						},
						["鲜血幻影"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["精神灼烧"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["攻城的哨兵"] = {
							["Details"] = {
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["长母阿提娜"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 9,
								},
								["Immune"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 7,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 21,
						},
					},
					["ElementTakenAbsorb"] = {
						["Shadow"] = 0,
						["Melee"] = 0,
						["Physical"] = 0,
					},
				},
				["LastFightData"] = {
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
								["Absorb"] = {
									["count"] = 0,
								},
								["Dodge"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
								["Absorb"] = {
									["count"] = 5,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 5,
						},
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTakenBlock"] = {
					},
					["DOTs"] = {
						["精神鞭笞 (伤害/跳)"] = {
							["Details"] = {
								["原始钳嘴鳄"] = {
									["count"] = 0,
								},
								["第七军团焚化者"] = {
									["count"] = 0,
								},
								["原始恐天飞龙"] = {
									["count"] = 6,
								},
								["鲜血巨魔蛮兵"] = {
									["count"] = 0,
								},
							},
							["amount"] = 6,
						},
						["吸血鬼之触 (伤害/跳)"] = {
							["Details"] = {
								["原始钳嘴鳄"] = {
									["count"] = 0,
								},
								["第七军团焚化者"] = {
									["count"] = 0,
								},
								["鲜血巨魔妖术师"] = {
									["count"] = 0,
								},
								["原始恐天飞龙"] = {
									["count"] = 6,
								},
								["鲜血巨魔蛮兵"] = {
									["count"] = 0,
								},
							},
							["amount"] = 6,
						},
						["暗言术：痛 (伤害/跳)"] = {
							["Details"] = {
								["原始钳嘴鳄"] = {
									["count"] = 0,
								},
								["第七军团焚化者"] = {
									["count"] = 0,
								},
								["鲜血巨魔妖术师"] = {
									["count"] = 0,
								},
								["原始恐天飞龙"] = {
									["count"] = 12,
								},
								["第七军团掠夺者"] = {
									["count"] = 0,
								},
								["鲜血巨魔蛮兵"] = {
									["count"] = 0,
								},
							},
							["amount"] = 12,
						},
						["被勾住 (伤害/跳)"] = {
							["Details"] = {
								["原始恐天飞龙"] = {
									["count"] = 51,
								},
							},
							["amount"] = 51,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 2533,
					["RageGainedFrom"] = {
					},
					["Absorbs"] = 2533,
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["DOT_Time"] = 75,
					["ElementTaken"] = {
						["Physical"] = 0,
						["Melee"] = 2533,
						["Shadow"] = 0,
					},
					["HOTs"] = {
					},
					["Damage"] = 28436,
					["RunicPowerGainedFrom"] = {
					},
					["TimeHeal"] = 7.49,
					["ShieldedWho"] = {
						["流星逐雨"] = {
							["Details"] = {
								["真言术：盾"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Dispels"] = 0,
					["HealingTaken"] = 3810,
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 8,
								},
								["Crit"] = {
									["count"] = 5,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 16,
						},
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 17,
								},
							},
							["amount"] = 17,
						},
					},
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Shadow"] = 16907,
						["Physical"] = 11529,
					},
					["CCBroken"] = {
					},
					["DamagedWho"] = {
						["原始钳嘴鳄"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["第七军团焚化者"] = {
							["Details"] = {
								["心灵震爆"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["翠绿灵蜂"] = {
							["Details"] = {
								["虚空爆发"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鲜血巨魔妖术师"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始恐天飞龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 778,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 2554,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 6975,
								},
								["被勾住 (伤害/跳)"] = {
									["count"] = 11529,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 2298,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 4302,
								},
							},
							["amount"] = 28436,
						},
						["第七军团掠夺者"] = {
							["Details"] = {
								["暗言术：痛"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鲜血巨魔蛮兵"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RageGained"] = {
					},
					["WhoDamaged"] = {
						["原始钳嘴鳄"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鲜血巨魔妖术师"] = {
							["Details"] = {
								["暗影箭"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始恐天飞龙"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 2533,
								},
							},
							["amount"] = 2533,
						},
						["盐脊三叶虫"] = {
							["Details"] = {
								["噬咬 (伤害/跳)"] = {
									["count"] = 0,
								},
								["噬咬"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鲜血巨魔蛮兵"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
								["野蛮打击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["Absorbed"] = {
						["真言术：盾"] = {
							["Details"] = {
								["流星逐雨"] = {
									["max"] = 607,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 2533,
								},
							},
							["count"] = 5,
							["amount"] = 2533,
						},
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["流星逐雨"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 0,
								},
								["真言术：盾"] = {
									["count"] = 5.79,
								},
								["吸血鬼之触"] = {
									["count"] = 1.7,
								},
							},
							["amount"] = 7.49,
						},
					},
					["Dispelled"] = 0,
					["RessedWho"] = {
					},
					["HealedWho"] = {
						["流星逐雨"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 0,
								},
								["真言术：盾"] = {
									["count"] = 2533,
								},
								["吸血鬼之触"] = {
									["count"] = 1277,
								},
							},
							["amount"] = 3810,
						},
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
						["Melee"] = 2533,
						["Physical"] = 0,
					},
					["FDamage"] = 0,
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["PartialAbsorb"] = {
						["野蛮打击"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗影箭"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["噬咬 (伤害/跳)"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["噬咬"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 607,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 2533,
								},
							},
							["count"] = 5,
							["amount"] = 2533,
						},
					},
					["ActiveTime"] = 15.6,
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["原始钳嘴鳄"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["第七军团焚化者"] = {
							["Details"] = {
								["心灵震爆"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["翠绿灵蜂"] = {
							["Details"] = {
								["虚空爆发"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["流星逐雨"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 0,
								},
								["真言术：盾"] = {
									["count"] = 5.79,
								},
								["吸血鬼之触"] = {
									["count"] = 1.7,
								},
							},
							["amount"] = 7.49,
						},
						["第七军团掠夺者"] = {
							["Details"] = {
								["暗言术：痛"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始恐天飞龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0.42,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0.49,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0.24,
								},
								["被勾住 (伤害/跳)"] = {
									["count"] = 5.32,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0.57,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 1.07,
								},
							},
							["amount"] = 8.11,
						},
						["鲜血巨魔妖术师"] = {
							["Details"] = {
								["虚空爆发"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鲜血巨魔蛮兵"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Overhealing"] = 0,
					["InterruptData"] = {
					},
					["Interrupts"] = 0,
					["Heals"] = {
						["冷漠面容"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["真言术：盾"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 607,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 2533,
								},
							},
							["count"] = 5,
							["amount"] = 2533,
						},
						["吸血鬼之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 641,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 1277,
								},
							},
							["count"] = 2,
							["amount"] = 1277,
						},
					},
					["PartialResist"] = {
						["野蛮打击"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗影箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["噬咬 (伤害/跳)"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["噬咬"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 5,
						},
					},
					["EnergyGained"] = {
					},
					["WhoHealed"] = {
						["流星逐雨"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 0,
								},
								["真言术：盾"] = {
									["count"] = 2533,
								},
								["吸血鬼之触"] = {
									["count"] = 1277,
								},
							},
							["amount"] = 3810,
						},
					},
					["Healing"] = 1277,
					["OverHeals"] = {
						["冷漠面容"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["吸血鬼之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["暗影幻灵"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 389,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 778,
								},
							},
							["count"] = 2,
							["amount"] = 778,
						},
						["暗言术：灭"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["虚空箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["心灵震爆"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 4662,
									["min"] = 4662,
									["count"] = 1,
									["amount"] = 4662,
								},
								["Hit"] = {
									["max"] = 2313,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 2313,
								},
							},
							["count"] = 2,
							["amount"] = 6975,
						},
						["暗言术：痛"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["精神鞭笞 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 721,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 4302,
								},
							},
							["count"] = 6,
							["amount"] = 4302,
						},
						["吸血鬼之触 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1282,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 2554,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 2554,
						},
						["虚空爆发"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗言术：痛 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 769,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 1532,
								},
								["Tick"] = {
									["max"] = 384,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 766,
								},
							},
							["count"] = 4,
							["amount"] = 2298,
						},
						["被勾住 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 693,
									["min"] = 0,
									["count"] = 17,
									["amount"] = 11529,
								},
							},
							["count"] = 17,
							["amount"] = 11529,
						},
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 8.11,
					["TimeDamaging"] = {
						["原始钳嘴鳄"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["第七军团焚化者"] = {
							["Details"] = {
								["心灵震爆"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["翠绿灵蜂"] = {
							["Details"] = {
								["虚空爆发"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鲜血巨魔妖术师"] = {
							["Details"] = {
								["虚空爆发"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始恐天飞龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0.42,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0.49,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0.24,
								},
								["被勾住 (伤害/跳)"] = {
									["count"] = 5.32,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0.57,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 1.07,
								},
							},
							["amount"] = 8.11,
						},
						["第七军团掠夺者"] = {
							["Details"] = {
								["暗言术：痛"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鲜血巨魔蛮兵"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["ElementTakenResist"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
								["Absorb"] = {
									["count"] = 0,
								},
								["Dodge"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
								["Absorb"] = {
									["count"] = 5,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 5,
						},
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTakenBlock"] = {
					},
					["DOTs"] = {
						["精神鞭笞 (伤害/跳)"] = {
							["Details"] = {
								["原始钳嘴鳄"] = {
									["count"] = 0,
								},
								["第七军团焚化者"] = {
									["count"] = 0,
								},
								["原始恐天飞龙"] = {
									["count"] = 6,
								},
								["鲜血巨魔蛮兵"] = {
									["count"] = 0,
								},
							},
							["amount"] = 6,
						},
						["吸血鬼之触 (伤害/跳)"] = {
							["Details"] = {
								["原始钳嘴鳄"] = {
									["count"] = 0,
								},
								["第七军团焚化者"] = {
									["count"] = 0,
								},
								["鲜血巨魔妖术师"] = {
									["count"] = 0,
								},
								["原始恐天飞龙"] = {
									["count"] = 6,
								},
								["鲜血巨魔蛮兵"] = {
									["count"] = 0,
								},
							},
							["amount"] = 6,
						},
						["暗言术：痛 (伤害/跳)"] = {
							["Details"] = {
								["原始钳嘴鳄"] = {
									["count"] = 0,
								},
								["第七军团焚化者"] = {
									["count"] = 0,
								},
								["鲜血巨魔妖术师"] = {
									["count"] = 0,
								},
								["原始恐天飞龙"] = {
									["count"] = 12,
								},
								["第七军团掠夺者"] = {
									["count"] = 0,
								},
								["鲜血巨魔蛮兵"] = {
									["count"] = 0,
								},
							},
							["amount"] = 12,
						},
						["被勾住 (伤害/跳)"] = {
							["Details"] = {
								["原始恐天飞龙"] = {
									["count"] = 51,
								},
							},
							["amount"] = 51,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 2533,
					["RageGainedFrom"] = {
					},
					["Absorbs"] = 2533,
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["DOT_Time"] = 75,
					["ElementTaken"] = {
						["Physical"] = 0,
						["Melee"] = 2533,
						["Shadow"] = 0,
					},
					["HOTs"] = {
					},
					["Damage"] = 28436,
					["RunicPowerGainedFrom"] = {
					},
					["TimeHeal"] = 7.49,
					["ShieldedWho"] = {
						["流星逐雨"] = {
							["Details"] = {
								["真言术：盾"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Dispels"] = 0,
					["HealingTaken"] = 3810,
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 8,
								},
								["Crit"] = {
									["count"] = 5,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 16,
						},
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 17,
								},
							},
							["amount"] = 17,
						},
					},
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Shadow"] = 16907,
						["Physical"] = 11529,
					},
					["CCBroken"] = {
					},
					["DamagedWho"] = {
						["原始钳嘴鳄"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["第七军团焚化者"] = {
							["Details"] = {
								["心灵震爆"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["翠绿灵蜂"] = {
							["Details"] = {
								["虚空爆发"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鲜血巨魔妖术师"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始恐天飞龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 778,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 2554,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 6975,
								},
								["被勾住 (伤害/跳)"] = {
									["count"] = 11529,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 2298,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 4302,
								},
							},
							["amount"] = 28436,
						},
						["第七军团掠夺者"] = {
							["Details"] = {
								["暗言术：痛"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鲜血巨魔蛮兵"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RageGained"] = {
					},
					["WhoDamaged"] = {
						["原始钳嘴鳄"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鲜血巨魔妖术师"] = {
							["Details"] = {
								["暗影箭"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始恐天飞龙"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 2533,
								},
							},
							["amount"] = 2533,
						},
						["盐脊三叶虫"] = {
							["Details"] = {
								["噬咬 (伤害/跳)"] = {
									["count"] = 0,
								},
								["噬咬"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鲜血巨魔蛮兵"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
								["野蛮打击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["Absorbed"] = {
						["真言术：盾"] = {
							["Details"] = {
								["流星逐雨"] = {
									["max"] = 607,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 2533,
								},
							},
							["count"] = 5,
							["amount"] = 2533,
						},
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["流星逐雨"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 0,
								},
								["真言术：盾"] = {
									["count"] = 5.79,
								},
								["吸血鬼之触"] = {
									["count"] = 1.7,
								},
							},
							["amount"] = 7.49,
						},
					},
					["Dispelled"] = 0,
					["RessedWho"] = {
					},
					["HealedWho"] = {
						["流星逐雨"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 0,
								},
								["真言术：盾"] = {
									["count"] = 2533,
								},
								["吸血鬼之触"] = {
									["count"] = 1277,
								},
							},
							["amount"] = 3810,
						},
					},
					["CCBreak"] = 0,
					["ElementTakenAbsorb"] = {
						["Melee"] = 2533,
						["Physical"] = 0,
					},
					["FDamage"] = 0,
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["PartialAbsorb"] = {
						["野蛮打击"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗影箭"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["噬咬 (伤害/跳)"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["噬咬"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 607,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 2533,
								},
							},
							["count"] = 5,
							["amount"] = 2533,
						},
					},
					["ActiveTime"] = 15.6,
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["原始钳嘴鳄"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["第七军团焚化者"] = {
							["Details"] = {
								["心灵震爆"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["翠绿灵蜂"] = {
							["Details"] = {
								["虚空爆发"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["流星逐雨"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 0,
								},
								["真言术：盾"] = {
									["count"] = 5.79,
								},
								["吸血鬼之触"] = {
									["count"] = 1.7,
								},
							},
							["amount"] = 7.49,
						},
						["第七军团掠夺者"] = {
							["Details"] = {
								["暗言术：痛"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始恐天飞龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0.42,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0.49,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0.24,
								},
								["被勾住 (伤害/跳)"] = {
									["count"] = 5.32,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0.57,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 1.07,
								},
							},
							["amount"] = 8.11,
						},
						["鲜血巨魔妖术师"] = {
							["Details"] = {
								["虚空爆发"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鲜血巨魔蛮兵"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Overhealing"] = 0,
					["InterruptData"] = {
					},
					["Interrupts"] = 0,
					["Heals"] = {
						["冷漠面容"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["真言术：盾"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 607,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 2533,
								},
							},
							["count"] = 5,
							["amount"] = 2533,
						},
						["吸血鬼之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 641,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 1277,
								},
							},
							["count"] = 2,
							["amount"] = 1277,
						},
					},
					["PartialResist"] = {
						["野蛮打击"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗影箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["噬咬 (伤害/跳)"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["噬咬"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 5,
						},
					},
					["EnergyGained"] = {
					},
					["WhoHealed"] = {
						["流星逐雨"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 0,
								},
								["真言术：盾"] = {
									["count"] = 2533,
								},
								["吸血鬼之触"] = {
									["count"] = 1277,
								},
							},
							["amount"] = 3810,
						},
					},
					["Healing"] = 1277,
					["OverHeals"] = {
						["冷漠面容"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["吸血鬼之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["暗影幻灵"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 389,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 778,
								},
							},
							["count"] = 2,
							["amount"] = 778,
						},
						["暗言术：灭"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["虚空箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["心灵震爆"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 4662,
									["min"] = 4662,
									["count"] = 1,
									["amount"] = 4662,
								},
								["Hit"] = {
									["max"] = 2313,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 2313,
								},
							},
							["count"] = 2,
							["amount"] = 6975,
						},
						["暗言术：痛"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["精神鞭笞 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 721,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 4302,
								},
							},
							["count"] = 6,
							["amount"] = 4302,
						},
						["吸血鬼之触 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1282,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 2554,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 2554,
						},
						["虚空爆发"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗言术：痛 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 769,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 1532,
								},
								["Tick"] = {
									["max"] = 384,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 766,
								},
							},
							["count"] = 4,
							["amount"] = 2298,
						},
						["被勾住 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 693,
									["min"] = 0,
									["count"] = 17,
									["amount"] = 11529,
								},
							},
							["count"] = 17,
							["amount"] = 11529,
						},
					},
					["RageGain"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 8.11,
					["TimeDamaging"] = {
						["原始钳嘴鳄"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["第七军团焚化者"] = {
							["Details"] = {
								["心灵震爆"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["翠绿灵蜂"] = {
							["Details"] = {
								["虚空爆发"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鲜血巨魔妖术师"] = {
							["Details"] = {
								["虚空爆发"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["原始恐天飞龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0.42,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0.49,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0.24,
								},
								["被勾住 (伤害/跳)"] = {
									["count"] = 5.32,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0.57,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 1.07,
								},
							},
							["amount"] = 8.11,
						},
						["第七军团掠夺者"] = {
							["Details"] = {
								["暗言术：痛"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["鲜血巨魔蛮兵"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0,
								},
								["虚空爆发"] = {
									["count"] = 0,
								},
								["虚空箭"] = {
									["count"] = 0,
								},
								["心灵震爆"] = {
									["count"] = 0,
								},
								["暗言术：灭"] = {
									["count"] = 0,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 0,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["ElementTakenResist"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["DOTs"] = {
						["精神鞭笞 (伤害/跳)"] = {
							["Details"] = {
								["石怒"] = {
									["count"] = 19,
								},
								["生病的细颚龙"] = {
									["count"] = 4,
								},
								["第七军团掠夺者"] = {
									["count"] = 8,
								},
								["盐脊三叶虫"] = {
									["count"] = 1,
								},
								["鲜血巨魔蛮兵"] = {
									["count"] = 4,
								},
								["原始钳嘴鳄"] = {
									["count"] = 13,
								},
								["奥尔敏·箭击"] = {
									["count"] = 3,
								},
								["加卡迪克斯"] = {
									["count"] = 5,
								},
								["原始恐天飞龙"] = {
									["count"] = 22,
								},
								["第七军团焚化者"] = {
									["count"] = 4,
								},
								["鲜血巨魔妖术师"] = {
									["count"] = 16,
								},
								["攻城的哨兵"] = {
									["count"] = 4,
								},
								["长母阿提娜"] = {
									["count"] = 20,
								},
							},
							["amount"] = 123,
						},
						["吸血鬼之触 (伤害/跳)"] = {
							["Details"] = {
								["石怒"] = {
									["count"] = 54,
								},
								["生病的细颚龙"] = {
									["count"] = 57,
								},
								["第七军团掠夺者"] = {
									["count"] = 21,
								},
								["盐脊三叶虫"] = {
									["count"] = 9,
								},
								["加卡迪克斯"] = {
									["count"] = 27,
								},
								["鲜血巨魔蛮兵"] = {
									["count"] = 30,
								},
								["原始钳嘴鳄"] = {
									["count"] = 132,
								},
								["奥尔敏·箭击"] = {
									["count"] = 15,
								},
								["原始恐天飞龙"] = {
									["count"] = 75,
								},
								["第七军团焚化者"] = {
									["count"] = 6,
								},
								["鲜血巨魔妖术师"] = {
									["count"] = 24,
								},
								["鲜血幻影"] = {
									["count"] = 36,
								},
								["攻城的哨兵"] = {
									["count"] = 9,
								},
								["长母阿提娜"] = {
									["count"] = 57,
								},
							},
							["amount"] = 552,
						},
						["暗言术：痛 (伤害/跳)"] = {
							["Details"] = {
								["石怒"] = {
									["count"] = 81,
								},
								["生病的细颚龙"] = {
									["count"] = 150,
								},
								["原始恐天飞龙"] = {
									["count"] = 117,
								},
								["第七军团掠夺者"] = {
									["count"] = 63,
								},
								["第七军团沙行者"] = {
									["count"] = 9,
								},
								["加卡迪克斯"] = {
									["count"] = 39,
								},
								["鲜血巨魔蛮兵"] = {
									["count"] = 48,
								},
								["原始钳嘴鳄"] = {
									["count"] = 198,
								},
								["奥尔敏·箭击"] = {
									["count"] = 27,
								},
								["鲜血巨魔妖术师"] = {
									["count"] = 39,
								},
								["第七军团焚化者"] = {
									["count"] = 9,
								},
								["盐脊三叶虫"] = {
									["count"] = 63,
								},
								["鲜血幻影"] = {
									["count"] = 51,
								},
								["攻城的哨兵"] = {
									["count"] = 15,
								},
								["长母阿提娜"] = {
									["count"] = 87,
								},
							},
							["amount"] = 996,
						},
						["被勾住 (伤害/跳)"] = {
							["Details"] = {
								["原始恐天飞龙"] = {
									["count"] = 306,
								},
							},
							["amount"] = 306,
						},
					},
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 45,
								},
								["Hit"] = {
									["count"] = 40,
								},
								["Dodge"] = {
									["count"] = 1,
								},
								["Tick"] = {
									["count"] = 101,
								},
								["Miss"] = {
									["count"] = 6,
								},
							},
							["amount"] = 193,
						},
						["Shadow"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 7,
								},
							},
							["amount"] = 10,
						},
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 171,
								},
								["Hit"] = {
									["count"] = 250,
								},
								["Dodge"] = {
									["count"] = 4,
								},
								["Crit"] = {
									["count"] = 22,
								},
								["Miss"] = {
									["count"] = 17,
								},
							},
							["amount"] = 464,
						},
						["Arcane"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
					},
					["HealedWho"] = {
						["流星逐雨"] = {
							["Details"] = {
								["吸血鬼之触"] = {
									["count"] = 32244,
								},
								["真言术：盾"] = {
									["count"] = 116304,
								},
								["消散"] = {
									["count"] = 21974,
								},
								["冷漠面容"] = {
									["count"] = 94876,
								},
								["暗影愈合"] = {
									["count"] = 4637,
								},
							},
							["amount"] = 270035,
						},
					},
					["Absorbs"] = 116304,
					["Overhealing"] = 70084,
					["ElementTaken"] = {
						["Physical"] = 100301,
						["Shadow"] = 13893,
						["Melee"] = 228304,
						["Arcane"] = 2216,
					},
					["DOT_Time"] = 1977,
					["Damage"] = 1353047,
					["TimeHeal"] = 314.92,
					["ShieldedWho"] = {
						["伊琳德丶星歌"] = {
							["Details"] = {
								["真言术：盾"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["流星逐雨"] = {
							["Details"] = {
								["真言术：盾"] = {
									["count"] = 51,
								},
							},
							["amount"] = 51,
						},
					},
					["ElementDone"] = {
						["Shadow"] = 1284331,
						["Physical"] = 68716,
					},
					["DamagedWho"] = {
						["原始恐天飞龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 3666,
								},
								["暗言术：灭"] = {
									["count"] = 14933,
								},
								["虚空箭"] = {
									["count"] = 18259,
								},
								["心灵震爆"] = {
									["count"] = 52834,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 18651,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 22998,
								},
								["虚空爆发"] = {
									["count"] = 9021,
								},
								["精神灼烧"] = {
									["count"] = 4597,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 19528,
								},
								["被勾住 (伤害/跳)"] = {
									["count"] = 68716,
								},
							},
							["amount"] = 233203,
						},
						["恐虱幼虫"] = {
							["Details"] = {
								["精神灼烧"] = {
									["count"] = 3389,
								},
							},
							["amount"] = 3389,
						},
						["第七军团焚化者"] = {
							["Details"] = {
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 1893,
								},
								["心灵震爆"] = {
									["count"] = 2295,
								},
								["暗言术：痛"] = {
									["count"] = 505,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 1515,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 4295,
								},
							},
							["amount"] = 10503,
						},
						["鲜血巨魔妖术师"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 1952,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 6517,
								},
								["暗言术：灭"] = {
									["count"] = 5957,
								},
								["虚空箭"] = {
									["count"] = 2789,
								},
								["心灵震爆"] = {
									["count"] = 7008,
								},
								["虚空爆发"] = {
									["count"] = 3604,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 7715,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 14328,
								},
							},
							["amount"] = 49870,
						},
						["攻城的哨兵"] = {
							["Details"] = {
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 2798,
								},
								["虚空爆发"] = {
									["count"] = 1772,
								},
								["虚空箭"] = {
									["count"] = 7636,
								},
								["心灵震爆"] = {
									["count"] = 2545,
								},
								["暗言术：灭"] = {
									["count"] = 3139,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 2098,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 3148,
								},
							},
							["amount"] = 23136,
						},
						["石怒"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 1988,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 15143,
								},
								["虚空爆发"] = {
									["count"] = 8950,
								},
								["虚空箭"] = {
									["count"] = 27617,
								},
								["心灵震爆"] = {
									["count"] = 21302,
								},
								["暗言术：灭"] = {
									["count"] = 5592,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 13053,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 19516,
								},
							},
							["amount"] = 113161,
						},
						["愤怒的守护者"] = {
							["Details"] = {
								["虚空爆发"] = {
									["count"] = 7088,
								},
							},
							["amount"] = 7088,
						},
						["生病的细颚龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 3384,
								},
								["暗言术：灭"] = {
									["count"] = 18222,
								},
								["虚空箭"] = {
									["count"] = 12898,
								},
								["心灵震爆"] = {
									["count"] = 9269,
								},
								["暗言术：痛"] = {
									["count"] = 2016,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 4208,
								},
								["精神灼烧"] = {
									["count"] = 119179,
								},
								["虚空爆发"] = {
									["count"] = 93784,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 22727,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 14312,
								},
							},
							["amount"] = 299999,
						},
						["鲜血幻影"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 1858,
								},
								["精神灼烧"] = {
									["count"] = 4502,
								},
								["心灵震爆"] = {
									["count"] = 4499,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 8117,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 10452,
								},
							},
							["amount"] = 29428,
						},
						["第七军团掠夺者"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 1211,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 6133,
								},
								["暗言术：灭"] = {
									["count"] = 6124,
								},
								["心灵震爆"] = {
									["count"] = 9945,
								},
								["暗言术：痛"] = {
									["count"] = 2037,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 9980,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 7695,
								},
							},
							["amount"] = 43125,
						},
						["三叶虫幼崽"] = {
							["Details"] = {
								["精神灼烧"] = {
									["count"] = 4188,
								},
								["虚空爆发"] = {
									["count"] = 7088,
								},
								["虚空箭"] = {
									["count"] = 5006,
								},
							},
							["amount"] = 16282,
						},
						["加卡迪克斯"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 868,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 8513,
								},
								["虚空爆发"] = {
									["count"] = 3636,
								},
								["虚空箭"] = {
									["count"] = 18052,
								},
								["心灵震爆"] = {
									["count"] = 12916,
								},
								["暗言术：灭"] = {
									["count"] = 3257,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 6761,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 4788,
								},
							},
							["amount"] = 58791,
						},
						["鲜血巨魔蛮兵"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 795,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 10036,
								},
								["虚空爆发"] = {
									["count"] = 10813,
								},
								["虚空箭"] = {
									["count"] = 7657,
								},
								["心灵震爆"] = {
									["count"] = 10158,
								},
								["暗言术：灭"] = {
									["count"] = 10022,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 7273,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 5024,
								},
							},
							["amount"] = 61778,
						},
						["原始钳嘴鳄"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 6956,
								},
								["暗言术：灭"] = {
									["count"] = 7581,
								},
								["虚空箭"] = {
									["count"] = 37473,
								},
								["心灵震爆"] = {
									["count"] = 25245,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 12580,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 33925,
								},
								["虚空爆发"] = {
									["count"] = 9405,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 31013,
								},
								["精神灼烧"] = {
									["count"] = 13468,
								},
							},
							["amount"] = 177646,
						},
						["奥尔敏·箭击"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 1229,
								},
								["暗言术：灭"] = {
									["count"] = 9925,
								},
								["虚空箭"] = {
									["count"] = 2673,
								},
								["心灵震爆"] = {
									["count"] = 5043,
								},
								["暗言术：痛"] = {
									["count"] = 521,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 2217,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 3519,
								},
								["虚空爆发"] = {
									["count"] = 5676,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 5392,
								},
							},
							["amount"] = 36195,
						},
						["翠绿灵蜂"] = {
							["Details"] = {
								["虚空爆发"] = {
									["count"] = 5409,
								},
							},
							["amount"] = 5409,
						},
						["艾泽里特融石者"] = {
							["Details"] = {
								["虚空爆发"] = {
									["count"] = 5407,
								},
							},
							["amount"] = 5407,
						},
						["盐脊三叶虫"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 1519,
								},
								["暗言术：灭"] = {
									["count"] = 9307,
								},
								["虚空箭"] = {
									["count"] = 5048,
								},
								["心灵震爆"] = {
									["count"] = 19430,
								},
								["暗言术：痛"] = {
									["count"] = 2089,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 780,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 2618,
								},
								["虚空爆发"] = {
									["count"] = 15948,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 9818,
								},
								["精神灼烧"] = {
									["count"] = 4540,
								},
							},
							["amount"] = 71097,
						},
						["纳兹曼尼象鼻虫"] = {
							["Details"] = {
								["精神灼烧"] = {
									["count"] = 412,
								},
							},
							["amount"] = 412,
						},
						["第七军团沙行者"] = {
							["Details"] = {
								["暗言术：痛"] = {
									["count"] = 500,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 1877,
								},
							},
							["amount"] = 2377,
						},
						["长母阿提娜"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 2998,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 17067,
								},
								["虚空爆发"] = {
									["count"] = 5754,
								},
								["虚空箭"] = {
									["count"] = 18748,
								},
								["心灵震爆"] = {
									["count"] = 24519,
								},
								["精神灼烧"] = {
									["count"] = 1677,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 14353,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 19635,
								},
							},
							["amount"] = 104751,
						},
					},
					["WhoDamaged"] = {
						["原始恐天飞龙"] = {
							["Details"] = {
								["尖叫之嚎"] = {
									["count"] = 778,
								},
								["肉搏"] = {
									["count"] = 35399,
								},
							},
							["amount"] = 36177,
						},
						["生病的细颚龙"] = {
							["Details"] = {
								["割裂"] = {
									["count"] = 6890,
								},
								["斜掠"] = {
									["count"] = 13432,
								},
								["斜掠 (伤害/跳)"] = {
									["count"] = 25831,
								},
								["割裂 (伤害/跳)"] = {
									["count"] = 6906,
								},
								["肉搏"] = {
									["count"] = 72518,
								},
							},
							["amount"] = 125577,
						},
						["鲜血巨魔妖术师"] = {
							["Details"] = {
								["暗影箭"] = {
									["count"] = 4998,
								},
								["肉搏"] = {
									["count"] = 1114,
								},
							},
							["amount"] = 6112,
						},
						["亡刺幼体"] = {
							["Details"] = {
								["爪击"] = {
									["count"] = 2983,
								},
								["肉搏"] = {
									["count"] = 7789,
								},
							},
							["amount"] = 10772,
						},
						["加卡迪克斯"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 16991,
								},
							},
							["amount"] = 16991,
						},
						["三叶虫幼崽"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 2088,
								},
							},
							["amount"] = 2088,
						},
						["原始钳嘴鳄"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 34050,
								},
							},
							["amount"] = 34050,
						},
						["盐脊三叶虫"] = {
							["Details"] = {
								["噬咬 (伤害/跳)"] = {
									["count"] = 1779,
								},
								["噬咬"] = {
									["count"] = 3879,
								},
								["低吼冲锋"] = {
									["count"] = 2931,
								},
								["肉搏"] = {
									["count"] = 31808,
								},
							},
							["amount"] = 40397,
						},
						["Environment"] = {
							["Details"] = {
								["Falling"] = {
									["count"] = 21613,
								},
							},
							["amount"] = 21613,
						},
						["艾泽里特融石者"] = {
							["Details"] = {
								["艾泽里特冲击"] = {
									["count"] = 2216,
								},
								["肉搏"] = {
									["count"] = 2723,
								},
							},
							["amount"] = 4939,
						},
						["鲜血巨魔蛮兵"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 10852,
								},
								["野蛮打击"] = {
									["count"] = 1702,
								},
							},
							["amount"] = 12554,
						},
						["鲜血幻影"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 4000,
								},
							},
							["amount"] = 4000,
						},
						["攻城的哨兵"] = {
							["Details"] = {
								["射击"] = {
									["count"] = 3588,
								},
								["肉搏"] = {
									["count"] = 2806,
								},
								["乱射"] = {
									["count"] = 7989,
								},
							},
							["amount"] = 14383,
						},
						["长母阿提娜"] = {
							["Details"] = {
								["噬血箭"] = {
									["count"] = 8895,
								},
								["肉搏"] = {
									["count"] = 6166,
								},
							},
							["amount"] = 15061,
						},
					},
					["Absorbed"] = {
						["真言术：盾"] = {
							["Details"] = {
								["流星逐雨"] = {
									["max"] = 2703,
									["min"] = 31,
									["count"] = 221,
									["amount"] = 116304,
								},
							},
							["count"] = 221,
							["amount"] = 116304,
						},
					},
					["TimeHealing"] = {
						["流星逐雨"] = {
							["Details"] = {
								["吸血鬼之触"] = {
									["count"] = 89.49,
								},
								["真言术：盾"] = {
									["count"] = 168.34,
								},
								["消散"] = {
									["count"] = 6.76,
								},
								["冷漠面容"] = {
									["count"] = 48.83,
								},
								["暗影愈合"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 314.92,
						},
					},
					["OverHeals"] = {
						["冷漠面容"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 3802,
									["min"] = 139,
									["count"] = 7,
									["amount"] = 14416,
								},
								["Hit"] = {
									["max"] = 1953,
									["min"] = 3,
									["count"] = 23,
									["amount"] = 26482,
								},
							},
							["count"] = 30,
							["amount"] = 40898,
						},
						["生命之岩"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 2164,
									["min"] = 2163,
									["count"] = 5,
									["amount"] = 10817,
								},
							},
							["count"] = 5,
							["amount"] = 10817,
						},
						["消散"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 2655,
									["min"] = 205,
									["count"] = 7,
									["amount"] = 16134,
								},
							},
							["count"] = 7,
							["amount"] = 16134,
						},
						["吸血鬼之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 612,
									["min"] = 40,
									["count"] = 8,
									["amount"] = 2235,
								},
							},
							["count"] = 8,
							["amount"] = 2235,
						},
					},
					["PartialResist"] = {
						["割裂"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 9,
						},
						["野蛮打击"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["射击"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 5,
						},
						["噬血箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 8,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 464,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 464,
						},
						["尖叫之嚎"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["噬咬 (伤害/跳)"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 13,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 13,
						},
						["割裂 (伤害/跳)"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 30,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 30,
						},
						["爪击"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 5,
						},
						["艾泽里特冲击"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["斜掠"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 29,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 29,
						},
						["暗影箭"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["噬咬"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 9,
						},
						["Falling"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["斜掠 (伤害/跳)"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 81,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 81,
						},
						["低吼冲锋"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["乱射"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 4,
						},
					},
					["PartialAbsorb"] = {
						["割裂"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 865,
									["min"] = 862,
									["count"] = 4,
									["amount"] = 3454,
								},
							},
							["count"] = 9,
							["amount"] = 3454,
						},
						["野蛮打击"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["射击"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["噬血箭"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 1201,
									["min"] = 499,
									["count"] = 2,
									["amount"] = 1700,
								},
							},
							["count"] = 8,
							["amount"] = 1700,
						},
						["肉搏"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 1591,
									["min"] = 31,
									["count"] = 171,
									["amount"] = 90923,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 293,
									["amount"] = 0,
								},
							},
							["count"] = 464,
							["amount"] = 90923,
						},
						["尖叫之嚎"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 778,
									["min"] = 778,
									["count"] = 1,
									["amount"] = 778,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 778,
						},
						["噬咬 (伤害/跳)"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 151,
									["min"] = 81,
									["count"] = 4,
									["amount"] = 528,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 9,
									["amount"] = 0,
								},
							},
							["count"] = 13,
							["amount"] = 528,
						},
						["割裂 (伤害/跳)"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 25,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 250,
									["min"] = 247,
									["count"] = 5,
									["amount"] = 1243,
								},
							},
							["count"] = 30,
							["amount"] = 1243,
						},
						["爪击"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 853,
									["min"] = 213,
									["count"] = 5,
									["amount"] = 2983,
								},
							},
							["count"] = 5,
							["amount"] = 2983,
						},
						["艾泽里特冲击"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 1108,
									["min"] = 1108,
									["count"] = 1,
									["amount"] = 1108,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 1108,
						},
						["斜掠"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 772,
									["min"] = 106,
									["count"] = 11,
									["amount"] = 5754,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 18,
									["amount"] = 0,
								},
							},
							["count"] = 29,
							["amount"] = 5754,
						},
						["暗影箭"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 2703,
									["min"] = 2703,
									["count"] = 1,
									["amount"] = 2703,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 2703,
						},
						["噬咬"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 641,
									["min"] = 641,
									["count"] = 1,
									["amount"] = 641,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 9,
							["amount"] = 641,
						},
						["Falling"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["斜掠 (伤害/跳)"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 330,
									["min"] = 326,
									["count"] = 14,
									["amount"] = 4586,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 67,
									["amount"] = 0,
								},
							},
							["count"] = 81,
							["amount"] = 4586,
						},
						["低吼冲锋"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["乱射"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
					},
					["Interrupts"] = 4,
					["InterruptData"] = {
						["石怒"] = {
							["Details"] = {
								["硬化 (沉默)"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["原始恐天飞龙"] = {
							["Details"] = {
								["尖叫之嚎 (沉默)"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["加卡迪克斯"] = {
							["Details"] = {
								["尖叫之嚎 (沉默)"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["长母阿提娜"] = {
							["Details"] = {
								["噬血箭 (沉默)"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Heals"] = {
						["吸血鬼之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 758,
									["min"] = 14,
									["count"] = 87,
									["amount"] = 32244,
								},
							},
							["count"] = 87,
							["amount"] = 32244,
						},
						["真言术：盾"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 2703,
									["min"] = 31,
									["count"] = 221,
									["amount"] = 116304,
								},
							},
							["count"] = 221,
							["amount"] = 116304,
						},
						["消散"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 2790,
									["min"] = 2450,
									["count"] = 8,
									["amount"] = 21974,
								},
							},
							["count"] = 8,
							["amount"] = 21974,
						},
						["冷漠面容"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 4042,
									["min"] = 169,
									["count"] = 16,
									["amount"] = 49559,
								},
								["Hit"] = {
									["max"] = 2040,
									["min"] = 53,
									["count"] = 36,
									["amount"] = 45317,
								},
							},
							["count"] = 52,
							["amount"] = 94876,
						},
						["暗影愈合"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 4637,
									["min"] = 4637,
									["count"] = 1,
									["amount"] = 4637,
								},
							},
							["count"] = 1,
							["amount"] = 4637,
						},
					},
					["HOTs"] = {
						["生命之岩"] = {
							["Details"] = {
								["流星逐雨"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
						["消散"] = {
							["Details"] = {
								["流星逐雨"] = {
									["count"] = 42,
								},
							},
							["amount"] = 42,
						},
					},
					["HOT_Time"] = 57,
					["Healing"] = 153731,
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 454,
								},
								["Immune"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 343,
								},
								["Hit"] = {
									["count"] = 440,
								},
							},
							["amount"] = 1238,
						},
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 102,
								},
							},
							["amount"] = 102,
						},
					},
					["ElementTakenAbsorb"] = {
						["Physical"] = 19967,
						["Shadow"] = 4403,
						["Melee"] = 90923,
						["Arcane"] = 1108,
					},
					["Attacks"] = {
						["暗影幻灵"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 466,
									["min"] = 289,
									["count"] = 73,
									["amount"] = 28424,
								},
							},
							["count"] = 73,
							["amount"] = 28424,
						},
						["暗言术：灭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6872,
									["min"] = 5807,
									["count"] = 7,
									["amount"] = 43950,
								},
								["Hit"] = {
									["max"] = 3308,
									["min"] = 2106,
									["count"] = 17,
									["amount"] = 50109,
								},
							},
							["count"] = 24,
							["amount"] = 94059,
						},
						["虚空箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5516,
									["min"] = 3804,
									["count"] = 17,
									["amount"] = 84940,
								},
								["Hit"] = {
									["max"] = 2789,
									["min"] = 1870,
									["count"] = 31,
									["amount"] = 78916,
								},
							},
							["count"] = 48,
							["amount"] = 163856,
						},
						["沉默"] = {
							["Details"] = {
								["Immune"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["暗言术：痛"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1089,
									["min"] = 993,
									["count"] = 3,
									["amount"] = 3092,
								},
								["Hit"] = {
									["max"] = 544,
									["min"] = 500,
									["count"] = 9,
									["amount"] = 4576,
								},
							},
							["count"] = 12,
							["amount"] = 7668,
						},
						["精神鞭笞 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1725,
									["min"] = 1052,
									["count"] = 34,
									["amount"] = 50682,
								},
								["Tick"] = {
									["max"] = 853,
									["min"] = 526,
									["count"] = 89,
									["amount"] = 66183,
								},
							},
							["count"] = 123,
							["amount"] = 116865,
						},
						["吸血鬼之触 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1516,
									["min"] = 935,
									["count"] = 59,
									["amount"] = 76289,
								},
								["Tick"] = {
									["max"] = 767,
									["min"] = 459,
									["count"] = 125,
									["amount"] = 79635,
								},
							},
							["count"] = 184,
							["amount"] = 155924,
						},
						["虚空爆发"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 3836,
									["min"] = 3544,
									["count"] = 22,
									["amount"] = 79594,
								},
								["Hit"] = {
									["max"] = 1918,
									["min"] = 1346,
									["count"] = 64,
									["amount"] = 113761,
								},
							},
							["count"] = 86,
							["amount"] = 193355,
						},
						["精神灼烧"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1002,
									["min"] = 593,
									["count"] = 91,
									["amount"] = 75578,
								},
								["Hit"] = {
									["max"] = 500,
									["min"] = 281,
									["count"] = 195,
									["amount"] = 80374,
								},
							},
							["count"] = 286,
							["amount"] = 155952,
						},
						["心灵震爆"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5418,
									["min"] = 3665,
									["count"] = 18,
									["amount"] = 84876,
								},
								["Hit"] = {
									["max"] = 2789,
									["min"] = 1700,
									["count"] = 51,
									["amount"] = 122132,
								},
							},
							["count"] = 69,
							["amount"] = 207008,
						},
						["暗言术：痛 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 910,
									["min"] = 326,
									["count"] = 92,
									["amount"] = 69530,
								},
								["Tick"] = {
									["max"] = 460,
									["min"] = 126,
									["count"] = 240,
									["amount"] = 91690,
								},
							},
							["count"] = 332,
							["amount"] = 161220,
						},
						["被勾住 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 693,
									["min"] = 456,
									["count"] = 102,
									["amount"] = 68716,
								},
							},
							["count"] = 102,
							["amount"] = 68716,
						},
					},
					["HealingTaken"] = 271844,
					["TimeSpent"] = {
						["原始恐天飞龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 2.78,
								},
								["暗言术：灭"] = {
									["count"] = 0.68,
								},
								["虚空箭"] = {
									["count"] = 3.32,
								},
								["心灵震爆"] = {
									["count"] = 10.33,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 8.59,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 11.88,
								},
								["虚空爆发"] = {
									["count"] = 0.29,
								},
								["精神灼烧"] = {
									["count"] = 1.09,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 15.1,
								},
								["被勾住 (伤害/跳)"] = {
									["count"] = 30.69,
								},
							},
							["amount"] = 84.7499999999999,
						},
						["恐虱幼虫"] = {
							["Details"] = {
								["精神灼烧"] = {
									["count"] = 2.53,
								},
							},
							["amount"] = 2.53,
						},
						["第七军团焚化者"] = {
							["Details"] = {
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0.73,
								},
								["心灵震爆"] = {
									["count"] = 0.23,
								},
								["暗言术：痛"] = {
									["count"] = 1.5,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 1.47,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 1.05,
								},
							},
							["amount"] = 4.98,
						},
						["第七军团掠夺者"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 2.13,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 3.58,
								},
								["暗言术：灭"] = {
									["count"] = 0.23,
								},
								["心灵震爆"] = {
									["count"] = 2.61,
								},
								["暗言术：痛"] = {
									["count"] = 4.5,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 14.97,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 1.93,
								},
							},
							["amount"] = 29.95,
						},
						["石怒"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 1.02,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 4.97,
								},
								["虚空爆发"] = {
									["count"] = 1.16,
								},
								["虚空箭"] = {
									["count"] = 3.01,
								},
								["心灵震爆"] = {
									["count"] = 5.75,
								},
								["沉默"] = {
									["count"] = 0.61,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 16.06,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 8.86,
								},
							},
							["amount"] = 41.44,
						},
						["愤怒的守护者"] = {
							["Details"] = {
								["虚空爆发"] = {
									["count"] = 0.64,
								},
							},
							["amount"] = 0.64,
						},
						["生病的细颚龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 2.8,
								},
								["暗言术：灭"] = {
									["count"] = 1.96,
								},
								["虚空箭"] = {
									["count"] = 2.42,
								},
								["心灵震爆"] = {
									["count"] = 0.43,
								},
								["暗言术：痛"] = {
									["count"] = 3.99,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0.78,
								},
								["精神灼烧"] = {
									["count"] = 25.09,
								},
								["虚空爆发"] = {
									["count"] = 1.05,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 22.6,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 7.97,
								},
							},
							["amount"] = 69.09,
						},
						["攻城的哨兵"] = {
							["Details"] = {
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 1.62,
								},
								["暗言术：灭"] = {
									["count"] = 0.23,
								},
								["虚空箭"] = {
									["count"] = 1.5,
								},
								["心灵震爆"] = {
									["count"] = 0.84,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 2.15,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 1.78,
								},
							},
							["amount"] = 8.12,
						},
						["鲜血巨魔妖术师"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 1.27,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 1.13,
								},
								["暗言术：灭"] = {
									["count"] = 0.45,
								},
								["虚空箭"] = {
									["count"] = 1.5,
								},
								["心灵震爆"] = {
									["count"] = 3,
								},
								["虚空爆发"] = {
									["count"] = 0.09,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 4.86,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 6.9,
								},
							},
							["amount"] = 19.2,
						},
						["盐脊三叶虫"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 3.24,
								},
								["暗言术：灭"] = {
									["count"] = 2.04,
								},
								["虚空箭"] = {
									["count"] = 1.67,
								},
								["心灵震爆"] = {
									["count"] = 4.23,
								},
								["暗言术：痛"] = {
									["count"] = 4.5,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 1.5,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 1,
								},
								["虚空爆发"] = {
									["count"] = 0.1,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 12.4,
								},
							},
							["amount"] = 30.68,
						},
						["加卡迪克斯"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0.97,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 3.76,
								},
								["虚空爆发"] = {
									["count"] = 0.11,
								},
								["虚空箭"] = {
									["count"] = 1.59,
								},
								["心灵震爆"] = {
									["count"] = 4.25,
								},
								["暗言术：灭"] = {
									["count"] = 0.39,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 7.46,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 3.02,
								},
							},
							["amount"] = 21.55,
						},
						["鲜血巨魔蛮兵"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0.43,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 2.03,
								},
								["虚空爆发"] = {
									["count"] = 0.12,
								},
								["虚空箭"] = {
									["count"] = 3.35,
								},
								["心灵震爆"] = {
									["count"] = 2.03,
								},
								["暗言术：灭"] = {
									["count"] = 0.98,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 8.64,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 1.33,
								},
							},
							["amount"] = 18.91,
						},
						["原始钳嘴鳄"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 4.63,
								},
								["暗言术：灭"] = {
									["count"] = 0.95,
								},
								["虚空箭"] = {
									["count"] = 5.55,
								},
								["心灵震爆"] = {
									["count"] = 6.25,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 5.61,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 17.5,
								},
								["虚空爆发"] = {
									["count"] = 0.28,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 27.48,
								},
								["精神灼烧"] = {
									["count"] = 2.28,
								},
							},
							["amount"] = 70.53,
						},
						["奥尔敏·箭击"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 1.71,
								},
								["暗言术：灭"] = {
									["count"] = 0.63,
								},
								["虚空箭"] = {
									["count"] = 0.86,
								},
								["心灵震爆"] = {
									["count"] = 2.06,
								},
								["暗言术：痛"] = {
									["count"] = 1.5,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 1.26,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 1.35,
								},
								["虚空爆发"] = {
									["count"] = 1.37,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 5.07,
								},
							},
							["amount"] = 15.81,
						},
						["翠绿灵蜂"] = {
							["Details"] = {
								["虚空爆发"] = {
									["count"] = 0.3,
								},
							},
							["amount"] = 0.3,
						},
						["流星逐雨"] = {
							["Details"] = {
								["吸血鬼之触"] = {
									["count"] = 89.49,
								},
								["真言术：盾"] = {
									["count"] = 168.34,
								},
								["消散"] = {
									["count"] = 6.76,
								},
								["冷漠面容"] = {
									["count"] = 48.83,
								},
								["暗影愈合"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 314.92,
						},
						["三叶虫幼崽"] = {
							["Details"] = {
								["精神灼烧"] = {
									["count"] = 4.26,
								},
								["虚空爆发"] = {
									["count"] = 0.91,
								},
								["虚空箭"] = {
									["count"] = 0.12,
								},
							},
							["amount"] = 5.29,
						},
						["鲜血幻影"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 1.44,
								},
								["精神灼烧"] = {
									["count"] = 1.02,
								},
								["心灵震爆"] = {
									["count"] = 0.79,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 6.22,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 4.4,
								},
							},
							["amount"] = 13.87,
						},
						["第七军团沙行者"] = {
							["Details"] = {
								["暗言术：痛"] = {
									["count"] = 1.5,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 4.29,
								},
							},
							["amount"] = 5.79,
						},
						["长母阿提娜"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 3.89,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 5.68,
								},
								["虚空爆发"] = {
									["count"] = 0.78,
								},
								["虚空箭"] = {
									["count"] = 0.63,
								},
								["心灵震爆"] = {
									["count"] = 4.34,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 10.1,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 8.88,
								},
							},
							["amount"] = 34.3,
						},
					},
					["TimeDamage"] = 477.730000000001,
					["TimeDamaging"] = {
						["原始恐天飞龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 2.78,
								},
								["暗言术：灭"] = {
									["count"] = 0.68,
								},
								["虚空箭"] = {
									["count"] = 3.32,
								},
								["心灵震爆"] = {
									["count"] = 10.33,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 8.59,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 11.88,
								},
								["虚空爆发"] = {
									["count"] = 0.29,
								},
								["精神灼烧"] = {
									["count"] = 1.09,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 15.1,
								},
								["被勾住 (伤害/跳)"] = {
									["count"] = 30.69,
								},
							},
							["amount"] = 84.7499999999999,
						},
						["恐虱幼虫"] = {
							["Details"] = {
								["精神灼烧"] = {
									["count"] = 2.53,
								},
							},
							["amount"] = 2.53,
						},
						["第七军团焚化者"] = {
							["Details"] = {
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 0.73,
								},
								["心灵震爆"] = {
									["count"] = 0.23,
								},
								["暗言术：痛"] = {
									["count"] = 1.5,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 1.47,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 1.05,
								},
							},
							["amount"] = 4.98,
						},
						["石怒"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 1.02,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 4.97,
								},
								["虚空爆发"] = {
									["count"] = 1.16,
								},
								["虚空箭"] = {
									["count"] = 3.01,
								},
								["心灵震爆"] = {
									["count"] = 5.75,
								},
								["沉默"] = {
									["count"] = 0.61,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 16.06,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 8.86,
								},
							},
							["amount"] = 41.44,
						},
						["愤怒的守护者"] = {
							["Details"] = {
								["虚空爆发"] = {
									["count"] = 0.64,
								},
							},
							["amount"] = 0.64,
						},
						["生病的细颚龙"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 2.8,
								},
								["暗言术：灭"] = {
									["count"] = 1.96,
								},
								["虚空箭"] = {
									["count"] = 2.42,
								},
								["心灵震爆"] = {
									["count"] = 0.43,
								},
								["暗言术：痛"] = {
									["count"] = 3.99,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 0.78,
								},
								["精神灼烧"] = {
									["count"] = 25.09,
								},
								["虚空爆发"] = {
									["count"] = 1.05,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 22.6,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 7.97,
								},
							},
							["amount"] = 69.09,
						},
						["第七军团掠夺者"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 2.13,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 3.58,
								},
								["暗言术：灭"] = {
									["count"] = 0.23,
								},
								["心灵震爆"] = {
									["count"] = 2.61,
								},
								["暗言术：痛"] = {
									["count"] = 4.5,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 14.97,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 1.93,
								},
							},
							["amount"] = 29.95,
						},
						["鲜血巨魔妖术师"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 1.27,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 1.13,
								},
								["暗言术：灭"] = {
									["count"] = 0.45,
								},
								["虚空箭"] = {
									["count"] = 1.5,
								},
								["心灵震爆"] = {
									["count"] = 3,
								},
								["虚空爆发"] = {
									["count"] = 0.09,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 4.86,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 6.9,
								},
							},
							["amount"] = 19.2,
						},
						["攻城的哨兵"] = {
							["Details"] = {
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 1.62,
								},
								["暗言术：灭"] = {
									["count"] = 0.23,
								},
								["虚空箭"] = {
									["count"] = 1.5,
								},
								["心灵震爆"] = {
									["count"] = 0.84,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 2.15,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 1.78,
								},
							},
							["amount"] = 8.12,
						},
						["加卡迪克斯"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0.97,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 3.76,
								},
								["虚空爆发"] = {
									["count"] = 0.11,
								},
								["虚空箭"] = {
									["count"] = 1.59,
								},
								["心灵震爆"] = {
									["count"] = 4.25,
								},
								["暗言术：灭"] = {
									["count"] = 0.39,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 7.46,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 3.02,
								},
							},
							["amount"] = 21.55,
						},
						["鲜血巨魔蛮兵"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 0.43,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 2.03,
								},
								["虚空爆发"] = {
									["count"] = 0.12,
								},
								["虚空箭"] = {
									["count"] = 3.35,
								},
								["心灵震爆"] = {
									["count"] = 2.03,
								},
								["暗言术：灭"] = {
									["count"] = 0.98,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 8.64,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 1.33,
								},
							},
							["amount"] = 18.91,
						},
						["原始钳嘴鳄"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 4.63,
								},
								["暗言术：灭"] = {
									["count"] = 0.95,
								},
								["虚空箭"] = {
									["count"] = 5.55,
								},
								["心灵震爆"] = {
									["count"] = 6.25,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 5.61,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 17.5,
								},
								["虚空爆发"] = {
									["count"] = 0.28,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 27.48,
								},
								["精神灼烧"] = {
									["count"] = 2.28,
								},
							},
							["amount"] = 70.53,
						},
						["奥尔敏·箭击"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 1.71,
								},
								["暗言术：灭"] = {
									["count"] = 0.63,
								},
								["虚空箭"] = {
									["count"] = 0.86,
								},
								["心灵震爆"] = {
									["count"] = 2.06,
								},
								["暗言术：痛"] = {
									["count"] = 1.5,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 1.26,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 1.35,
								},
								["虚空爆发"] = {
									["count"] = 1.37,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 5.07,
								},
							},
							["amount"] = 15.81,
						},
						["翠绿灵蜂"] = {
							["Details"] = {
								["虚空爆发"] = {
									["count"] = 0.3,
								},
							},
							["amount"] = 0.3,
						},
						["盐脊三叶虫"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 3.24,
								},
								["暗言术：灭"] = {
									["count"] = 2.04,
								},
								["虚空箭"] = {
									["count"] = 1.67,
								},
								["心灵震爆"] = {
									["count"] = 4.23,
								},
								["暗言术：痛"] = {
									["count"] = 4.5,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 1.5,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 1,
								},
								["虚空爆发"] = {
									["count"] = 0.1,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 12.4,
								},
							},
							["amount"] = 30.68,
						},
						["三叶虫幼崽"] = {
							["Details"] = {
								["精神灼烧"] = {
									["count"] = 4.26,
								},
								["虚空爆发"] = {
									["count"] = 0.91,
								},
								["虚空箭"] = {
									["count"] = 0.12,
								},
							},
							["amount"] = 5.29,
						},
						["鲜血幻影"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 1.44,
								},
								["精神灼烧"] = {
									["count"] = 1.02,
								},
								["心灵震爆"] = {
									["count"] = 0.79,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 6.22,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 4.4,
								},
							},
							["amount"] = 13.87,
						},
						["第七军团沙行者"] = {
							["Details"] = {
								["暗言术：痛"] = {
									["count"] = 1.5,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 4.29,
								},
							},
							["amount"] = 5.79,
						},
						["长母阿提娜"] = {
							["Details"] = {
								["暗影幻灵"] = {
									["count"] = 3.89,
								},
								["吸血鬼之触 (伤害/跳)"] = {
									["count"] = 5.68,
								},
								["虚空爆发"] = {
									["count"] = 0.78,
								},
								["虚空箭"] = {
									["count"] = 0.63,
								},
								["心灵震爆"] = {
									["count"] = 4.34,
								},
								["暗言术：痛 (伤害/跳)"] = {
									["count"] = 10.1,
								},
								["精神鞭笞 (伤害/跳)"] = {
									["count"] = 8.88,
								},
							},
							["amount"] = 34.3,
						},
					},
					["DamageTaken"] = 344714,
					["WhoHealed"] = {
						["流星逐雨"] = {
							["Details"] = {
								["吸血鬼之触"] = {
									["count"] = 32244,
								},
								["真言术：盾"] = {
									["count"] = 116304,
								},
								["消散"] = {
									["count"] = 21974,
								},
								["冷漠面容"] = {
									["count"] = 94876,
								},
								["暗影愈合"] = {
									["count"] = 4637,
								},
							},
							["amount"] = 270035,
						},
					},
					["ActiveTime"] = 792.650000000001,
				},
			},
			["LastDamageTaken"] = 20213,
			["UnitLockout"] = 4826.041,
			["LastAbility"] = 8381.057,
		},
	},
	["FightNum"] = 34,
	["CombatTimes"] = {
		{
			4826.041, -- [1]
			4901.041, -- [2]
			"22:38:36", -- [3]
			"22:39:50", -- [4]
			"石怒", -- [5]
		}, -- [1]
		{
			4907.043, -- [1]
			4915.047, -- [2]
			"22:39:57", -- [3]
			"22:40:04", -- [4]
			"盐脊三叶虫", -- [5]
		}, -- [2]
		{
			4920.034, -- [1]
			4949.048, -- [2]
			"22:40:10", -- [3]
			"22:40:38", -- [4]
			"盐脊三叶虫", -- [5]
		}, -- [3]
		{
			4955.046, -- [1]
			4979.042, -- [2]
			"22:40:45", -- [3]
			"22:41:08", -- [4]
			"盐脊三叶虫", -- [5]
		}, -- [4]
		{
			5047.045, -- [1]
			5058.049, -- [2]
			"22:42:17", -- [3]
			"22:42:27", -- [4]
			"第七军团掠夺者", -- [5]
		}, -- [5]
		{
			5060.051, -- [1]
			5067.043, -- [2]
			"22:42:30", -- [3]
			"22:42:36", -- [4]
			"第七军团掠夺者", -- [5]
		}, -- [6]
		{
			5111.038, -- [1]
			5114.045, -- [2]
			"22:43:21", -- [3]
			"22:43:23", -- [4]
			"第七军团掠夺者", -- [5]
		}, -- [7]
		{
			5127.045, -- [1]
			5134.035, -- [2]
			"22:43:37", -- [3]
			"22:43:43", -- [4]
			"第七军团掠夺者", -- [5]
		}, -- [8]
		{
			5137.041, -- [1]
			5145.049, -- [2]
			"22:43:47", -- [3]
			"22:43:54", -- [4]
			"第七军团沙行者", -- [5]
		}, -- [9]
		{
			5145.049, -- [1]
			5153.05, -- [2]
			"22:43:55", -- [3]
			"22:44:02", -- [4]
			"第七军团掠夺者", -- [5]
		}, -- [10]
		{
			5162.036, -- [1]
			5165.049, -- [2]
			"22:44:12", -- [3]
			"22:44:14", -- [4]
			"第七军团焚化者", -- [5]
		}, -- [11]
		{
			5239.038, -- [1]
			5262.046, -- [2]
			"22:45:29", -- [3]
			"22:45:51", -- [4]
			"亡刺幼体", -- [5]
		}, -- [12]
		{
			5807.048, -- [1]
			5823.038, -- [2]
			"22:54:57", -- [3]
			"22:55:12", -- [4]
			"奥尔敏·箭击", -- [5]
		}, -- [13]
		{
			3967.402, -- [1]
			3974.414, -- [2]
			"22:56:47", -- [3]
			"22:56:54", -- [4]
			"鲜血巨魔妖术师", -- [5]
		}, -- [14]
		{
			3991.418, -- [1]
			3997.41, -- [2]
			"22:57:11", -- [3]
			"22:57:17", -- [4]
			"鲜血巨魔妖术师", -- [5]
		}, -- [15]
		{
			4006.405, -- [1]
			4022.406, -- [2]
			"22:57:26", -- [3]
			"22:57:42", -- [4]
			"鲜血巨魔蛮兵", -- [5]
		}, -- [16]
		{
			4024.42, -- [1]
			4033.405, -- [2]
			"22:57:45", -- [3]
			"22:57:53", -- [4]
			"鲜血巨魔蛮兵", -- [5]
		}, -- [17]
		{
			4034.425, -- [1]
			4041.4, -- [2]
			"22:57:54", -- [3]
			"22:58:01", -- [4]
			"鲜血巨魔妖术师", -- [5]
		}, -- [18]
		{
			4128.417, -- [1]
			4178.424, -- [2]
			"22:59:29", -- [3]
			"23:00:18", -- [4]
			"长母阿提娜", -- [5]
		}, -- [19]
		{
			4596.418, -- [1]
			4608.398, -- [2]
			"23:07:17", -- [3]
			"23:07:28", -- [4]
			"生病的细颚龙", -- [5]
		}, -- [20]
		{
			4614.419, -- [1]
			4633.412, -- [2]
			"23:07:35", -- [3]
			"23:07:53", -- [4]
			"原始钳嘴鳄", -- [5]
		}, -- [21]
		{
			4636.406, -- [1]
			4642.411, -- [2]
			"23:07:56", -- [3]
			"23:08:02", -- [4]
			"原始钳嘴鳄", -- [5]
		}, -- [22]
		{
			4655.403, -- [1]
			4714.405, -- [2]
			"23:08:15", -- [3]
			"23:09:14", -- [4]
			"原始钳嘴鳄", -- [5]
		}, -- [23]
		{
			4734.413, -- [1]
			4756.405, -- [2]
			"23:09:35", -- [3]
			"23:09:56", -- [4]
			"原始钳嘴鳄", -- [5]
		}, -- [24]
		{
			4767.4, -- [1]
			4790.399, -- [2]
			"23:10:07", -- [3]
			"23:10:30", -- [4]
			"生病的细颚龙", -- [5]
		}, -- [25]
		{
			4805.408, -- [1]
			4834.411, -- [2]
			"23:10:46", -- [3]
			"23:11:14", -- [4]
			"生病的细颚龙", -- [5]
		}, -- [26]
		{
			4907.417, -- [1]
			4918.412, -- [2]
			"23:12:27", -- [3]
			"23:12:38", -- [4]
			"原始恐天飞龙", -- [5]
		}, -- [27]
		{
			4926.412, -- [1]
			4936.414, -- [2]
			"23:12:46", -- [3]
			"23:12:56", -- [4]
			"原始恐天飞龙", -- [5]
		}, -- [28]
		{
			4977.419, -- [1]
			4989.406, -- [2]
			"23:13:37", -- [3]
			"23:13:49", -- [4]
			"原始恐天飞龙", -- [5]
		}, -- [29]
		{
			4995.413, -- [1]
			5013.399, -- [2]
			"23:13:55", -- [3]
			"23:14:13", -- [4]
			"原始恐天飞龙", -- [5]
		}, -- [30]
		{
			5019.405, -- [1]
			5029.406, -- [2]
			"23:14:19", -- [3]
			"23:14:29", -- [4]
			"原始恐天飞龙", -- [5]
		}, -- [31]
		{
			5059.418, -- [1]
			5083.402, -- [2]
			"23:14:59", -- [3]
			"23:15:23", -- [4]
			"原始恐天飞龙", -- [5]
		}, -- [32]
		{
			5091.401, -- [1]
			5113.418, -- [2]
			"23:15:32", -- [3]
			"23:15:53", -- [4]
			"加卡迪克斯", -- [5]
		}, -- [33]
		{
			5124.414, -- [1]
			5132.407, -- [2]
			"23:16:04", -- [3]
			"23:16:12", -- [4]
			"原始恐天飞龙", -- [5]
		}, -- [34]
	},
	["FoughtWho"] = {
		"原始恐天飞龙 23:16:04-23:16:12", -- [1]
		"加卡迪克斯 23:15:32-23:15:53", -- [2]
		"原始恐天飞龙 23:14:59-23:15:23", -- [3]
		"原始恐天飞龙 23:14:19-23:14:29", -- [4]
		"原始恐天飞龙 23:13:55-23:14:13", -- [5]
	},
}
