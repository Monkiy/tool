
BattlefieldMapOptions = {
	["locked"] = true,
	["opacity"] = 0.7,
	["position"] = {
		["y"] = 470.9999694824219,
		["x"] = 102.4998474121094,
	},
	["showPlayers"] = true,
}
