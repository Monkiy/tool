
RecountPerCharDB = {
	["version"] = "1.3",
	["combatants"] = {
		["水元素 <节省了空间是>"] = {
			["GUID"] = "Pet-0-3148-1949-18912-78116-01026DFD69",
			["LastEventHealth"] = {
				1606, -- [1]
				1187, -- [2]
				1389, -- [3]
				1389, -- [4]
				997, -- [5]
				997, -- [6]
				1199, -- [7]
				812, -- [8]
				812, -- [9]
				523, -- [10]
				523, -- [11]
				421, -- [12]
				421, -- [13]
				421, -- [14]
				69, -- [15]
				69, -- [16]
				0, -- [17]
				4332, -- [18]
				3954, -- [19]
				4156, -- [20]
				4156, -- [21]
				3868, -- [22]
				3868, -- [23]
				3752, -- [24]
				3752, -- [25]
				3752, -- [26]
				3393, -- [27]
				3595, -- [28]
				3595, -- [29]
				3309, -- [30]
				3309, -- [31]
				3170, -- [32]
				3170, -- [33]
				3170, -- [34]
				2971, -- [35]
				2971, -- [36]
				2971, -- [37]
				2586, -- [38]
				2586, -- [39]
				2297, -- [40]
				2297, -- [41]
				2499, -- [42]
				2207, -- [43]
				1913, -- [44]
				2115, -- [45]
				2115, -- [46]
				1781, -- [47]
				1781, -- [48]
				1606, -- [49]
				1606, -- [50]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"HEAL", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"HEAL", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"HEAL", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"MISC", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"HEAL", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"HEAL", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"HEAL", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"HEAL", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"HEAL", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"HEAL", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"HEAL", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"HEAL", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["DeathCount"] = {
					2, -- [1]
				},
				["ActiveTime"] = {
					206.6, -- [1]
				},
				["HealingTaken"] = {
					7272, -- [1]
				},
				["TimeDamage"] = {
					206.6, -- [1]
				},
				["DamageTaken"] = {
					31613, -- [1]
				},
				["Damage"] = {
					31583, -- [1]
				},
			},
			["enClass"] = "PET",
			["unit"] = "水元素",
			["LastAbility"] = 11477.809,
			["LastFlags"] = 4648,
			["level"] = 1,
			["LastDamageAbility"] = "肉搏",
			["LastFightIn"] = 5,
			["UnitLockout"] = 10798.551,
			["type"] = "Pet",
			["FightsSaved"] = 5,
			["ownerName"] = "节省了空间是",
			["Fights"] = {
				["Fight1"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 31613,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 130,
								},
								["Parry"] = {
									["count"] = 3,
								},
								["Miss"] = {
									["count"] = 6,
								},
								["Dodge"] = {
									["count"] = 2,
								},
							},
							["amount"] = 141,
						},
					},
					["DeathCount"] = 2,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
						["Melee"] = 31613,
					},
					["DOT_Time"] = 0,
					["Damage"] = 8960,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 141,
									["amount"] = 0,
								},
							},
							["count"] = 141,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Frost"] = 8960,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 8,
								},
								["Hit"] = {
									["count"] = 34,
								},
							},
							["amount"] = 42,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
						["部落步兵"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 21574,
								},
							},
							["amount"] = 21574,
						},
						["双足飞龙骑手"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 10039,
								},
							},
							["amount"] = 10039,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 62.6,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 141,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 141,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["部落步兵"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
						["双足飞龙骑手"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 58.1,
								},
							},
							["amount"] = 58.1,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["水箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 359,
									["min"] = 359,
									["count"] = 8,
									["amount"] = 2872,
								},
								["Hit"] = {
									["max"] = 180,
									["min"] = 179,
									["count"] = 34,
									["amount"] = 6088,
								},
							},
							["count"] = 42,
							["amount"] = 8960,
						},
					},
					["HealingTaken"] = 7272,
					["DamagedWho"] = {
						["部落步兵"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 539,
								},
							},
							["amount"] = 539,
						},
						["双足飞龙骑手"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 8421,
								},
							},
							["amount"] = 8421,
						},
					},
					["TimeDamage"] = 62.6,
					["TimeDamaging"] = {
						["部落步兵"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
						["双足飞龙骑手"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 58.1,
								},
							},
							["amount"] = 58.1,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["TimeSpent"] = {
						["目标假人"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Frost"] = 0,
					},
					["DamagedWho"] = {
						["目标假人"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["目标假人"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 0,
					["Attacks"] = {
						["水箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["Damage"] = 0,
				},
				["OverallData"] = {
					["TimeSpent"] = {
						["双足飞龙骑手"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 58.1,
								},
							},
							["amount"] = 58.1,
						},
						["目标假人"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 115.5,
								},
							},
							["amount"] = 115.5,
						},
						["联盟步兵"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 19.5,
								},
							},
							["amount"] = 19.5,
						},
						["部落步兵"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
						["奥术构造体"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["DamageTaken"] = 31613,
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 141,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 141,
						},
					},
					["DeathCount"] = 2,
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 141,
									["amount"] = 0,
								},
							},
							["count"] = 141,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 206.6,
					["ElementTaken"] = {
						["Melee"] = 31613,
					},
					["Damage"] = 31583,
					["WhoDamaged"] = {
						["部落步兵"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 21574,
								},
							},
							["amount"] = 21574,
						},
						["双足飞龙骑手"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 10039,
								},
							},
							["amount"] = 10039,
						},
					},
					["ElementDone"] = {
						["Frost"] = 31583,
					},
					["HealingTaken"] = 7272,
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 38,
								},
								["Hit"] = {
									["count"] = 100,
								},
							},
							["amount"] = 138,
						},
					},
					["TimeDamage"] = 206.6,
					["TimeDamaging"] = {
						["双足飞龙骑手"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 58.1,
								},
							},
							["amount"] = 58.1,
						},
						["目标假人"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 115.5,
								},
							},
							["amount"] = 115.5,
						},
						["联盟步兵"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 19.5,
								},
							},
							["amount"] = 19.5,
						},
						["部落步兵"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
						["奥术构造体"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["Attacks"] = {
						["水箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 360,
									["min"] = 359,
									["count"] = 38,
									["amount"] = 13644,
								},
								["Hit"] = {
									["max"] = 180,
									["min"] = 179,
									["count"] = 100,
									["amount"] = 17939,
								},
							},
							["count"] = 138,
							["amount"] = 31583,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 130,
								},
								["Parry"] = {
									["count"] = 3,
								},
								["Miss"] = {
									["count"] = 6,
								},
								["Dodge"] = {
									["count"] = 2,
								},
							},
							["amount"] = 141,
						},
					},
					["DamagedWho"] = {
						["双足飞龙骑手"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 8421,
								},
							},
							["amount"] = 8421,
						},
						["目标假人"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 17962,
								},
							},
							["amount"] = 17962,
						},
						["联盟步兵"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 3227,
								},
							},
							["amount"] = 3227,
						},
						["部落步兵"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 539,
								},
							},
							["amount"] = 539,
						},
						["奥术构造体"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 1434,
								},
							},
							["amount"] = 1434,
						},
					},
				},
				["Fight4"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 1434,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Frost"] = 1434,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 6,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 9,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["奥术构造体"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["水箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 359,
									["min"] = 359,
									["count"] = 2,
									["amount"] = 718,
								},
								["Hit"] = {
									["max"] = 179,
									["min"] = 179,
									["count"] = 4,
									["amount"] = 716,
								},
							},
							["count"] = 6,
							["amount"] = 1434,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["奥术构造体"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 1434,
								},
							},
							["amount"] = 1434,
						},
					},
					["TimeDamage"] = 9,
					["TimeDamaging"] = {
						["奥术构造体"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 31613,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 130,
								},
								["Parry"] = {
									["count"] = 3,
								},
								["Miss"] = {
									["count"] = 6,
								},
								["Dodge"] = {
									["count"] = 2,
								},
							},
							["amount"] = 141,
						},
					},
					["DeathCount"] = 2,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
						["Melee"] = 31613,
					},
					["DOT_Time"] = 0,
					["Damage"] = 8960,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 141,
									["amount"] = 0,
								},
							},
							["count"] = 141,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Frost"] = 8960,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 8,
								},
								["Hit"] = {
									["count"] = 34,
								},
							},
							["amount"] = 42,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
						["部落步兵"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 21574,
								},
							},
							["amount"] = 21574,
						},
						["双足飞龙骑手"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 10039,
								},
							},
							["amount"] = 10039,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 62.6,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 141,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 141,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["部落步兵"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
						["双足飞龙骑手"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 58.1,
								},
							},
							["amount"] = 58.1,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["水箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 359,
									["min"] = 359,
									["count"] = 8,
									["amount"] = 2872,
								},
								["Hit"] = {
									["max"] = 180,
									["min"] = 179,
									["count"] = 34,
									["amount"] = 6088,
								},
							},
							["count"] = 42,
							["amount"] = 8960,
						},
					},
					["HealingTaken"] = 7272,
					["DamagedWho"] = {
						["部落步兵"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 539,
								},
							},
							["amount"] = 539,
						},
						["双足飞龙骑手"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 8421,
								},
							},
							["amount"] = 8421,
						},
					},
					["TimeDamage"] = 62.6,
					["TimeDamaging"] = {
						["部落步兵"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
						["双足飞龙骑手"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 58.1,
								},
							},
							["amount"] = 58.1,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight2"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 1972,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Frost"] = 1972,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 8,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 12,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["联盟步兵"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["水箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 359,
									["min"] = 359,
									["count"] = 3,
									["amount"] = 1077,
								},
								["Hit"] = {
									["max"] = 179,
									["min"] = 179,
									["count"] = 5,
									["amount"] = 895,
								},
							},
							["count"] = 8,
							["amount"] = 1972,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["联盟步兵"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 1972,
								},
							},
							["amount"] = 1972,
						},
					},
					["TimeDamage"] = 12,
					["TimeDamaging"] = {
						["联盟步兵"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight3"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 1255,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Frost"] = 1255,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 5,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 7.5,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["联盟步兵"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 7.5,
								},
							},
							["amount"] = 7.5,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["水箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 359,
									["min"] = 359,
									["count"] = 2,
									["amount"] = 718,
								},
								["Hit"] = {
									["max"] = 179,
									["min"] = 179,
									["count"] = 3,
									["amount"] = 537,
								},
							},
							["count"] = 5,
							["amount"] = 1255,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["联盟步兵"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 1255,
								},
							},
							["amount"] = 1255,
						},
					},
					["TimeDamage"] = 7.5,
					["TimeDamaging"] = {
						["联盟步兵"] = {
							["Details"] = {
								["水箭"] = {
									["count"] = 7.5,
								},
							},
							["amount"] = 7.5,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
			},
			["LastEventTimes"] = {
				11580.457, -- [1]
				11581.249, -- [2]
				11581.589, -- [3]
				11582.45, -- [4]
				11583.451, -- [5]
				11584.46, -- [6]
				11584.602, -- [7]
				11585.657, -- [8]
				11586.467, -- [9]
				11587.839, -- [10]
				11588.459, -- [11]
				11589.664, -- [12]
				11590.048, -- [13]
				11590.482, -- [14]
				11592.24, -- [15]
				11592.479, -- [16]
				11592.496, -- [17]
				11554.393, -- [18]
				11554.889, -- [19]
				11555.548, -- [20]
				11556.406, -- [21]
				11557.076, -- [22]
				11558.4, -- [23]
				11558.544, -- [24]
				11559.297, -- [25]
				11560.401, -- [26]
				11561.485, -- [27]
				11561.54, -- [28]
				11562.407, -- [29]
				11563.686, -- [30]
				11564.406, -- [31]
				11564.549, -- [32]
				11565.88, -- [33]
				11566.41, -- [34]
				11567.545, -- [35]
				11568.084, -- [36]
				11568.42, -- [37]
				11570.265, -- [38]
				11570.421, -- [39]
				11572.436, -- [40]
				11572.47, -- [41]
				11572.592, -- [42]
				11574.433, -- [43]
				11574.661, -- [44]
				11575.582, -- [45]
				11576.448, -- [46]
				11576.854, -- [47]
				11578.449, -- [48]
				11578.591, -- [49]
				11579.045, -- [50]
			},
			["LastEventIncoming"] = {
				true, -- [1]
				false, -- [2]
				true, -- [3]
				true, -- [4]
				false, -- [5]
				true, -- [6]
				true, -- [7]
				false, -- [8]
				true, -- [9]
				false, -- [10]
				true, -- [11]
				true, -- [12]
				false, -- [13]
				true, -- [14]
				false, -- [15]
				true, -- [16]
				true, -- [17]
				true, -- [18]
				false, -- [19]
				true, -- [20]
				true, -- [21]
				false, -- [22]
				true, -- [23]
				true, -- [24]
				false, -- [25]
				true, -- [26]
				false, -- [27]
				true, -- [28]
				true, -- [29]
				false, -- [30]
				true, -- [31]
				true, -- [32]
				false, -- [33]
				true, -- [34]
				true, -- [35]
				false, -- [36]
				true, -- [37]
				false, -- [38]
				true, -- [39]
				true, -- [40]
				false, -- [41]
				true, -- [42]
				true, -- [43]
				false, -- [44]
				true, -- [45]
				true, -- [46]
				false, -- [47]
				true, -- [48]
				true, -- [49]
				false, -- [50]
			},
			["NextEventNum"] = 18,
			["LastDamageTime"] = 11592.24,
			["LastEvents"] = {
				"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -419 (Physical)", -- [1]
				"水元素 <节省了空间是> 水箭 双足飞龙骑手 Hit -179 (Frost)", -- [2]
				"学者塔里娅 恢复 水元素 <节省了空间是> Tick +202", -- [3]
				"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -392 (Physical)", -- [4]
				"水元素 <节省了空间是> 水箭 双足飞龙骑手 Hit -179 (Frost)", -- [5]
				"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -387 (Physical)", -- [6]
				"学者塔里娅 恢复 水元素 <节省了空间是> Tick +202", -- [7]
				"水元素 <节省了空间是> 水箭 双足飞龙骑手 Hit -179 (Frost)", -- [8]
				"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -289 (Physical)", -- [9]
				"水元素 <节省了空间是> 水箭 双足飞龙骑手 Hit -179 (Frost)", -- [10]
				"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -304 (Physical)", -- [11]
				"学者塔里娅 恢复 水元素 <节省了空间是> Tick +202", -- [12]
				"水元素 <节省了空间是> 水箭 双足飞龙骑手 Hit -179 (Frost)", -- [13]
				"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -352 (Physical)", -- [14]
				"水元素 <节省了空间是> 水箭 双足飞龙骑手 Crit -359 (Frost)", -- [15]
				"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -359 (Physical)", -- [16]
				"水元素 <节省了空间是>死亡。", -- [17]
				"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -378 (Physical)", -- [18]
				"水元素 <节省了空间是> 水箭 双足飞龙骑手 Hit -179 (Frost)", -- [19]
				"学者塔里娅 恢复 水元素 <节省了空间是> Tick +202", -- [20]
				"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -288 (Physical)", -- [21]
				"水元素 <节省了空间是> 水箭 双足飞龙骑手 Hit -179 (Frost)", -- [22]
				"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -318 (Physical)", -- [23]
				"学者塔里娅 恢复 水元素 <节省了空间是> Tick +202", -- [24]
				"水元素 <节省了空间是> 水箭 双足飞龙骑手 Hit -179 (Frost)", -- [25]
				"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -359 (Physical)", -- [26]
				"水元素 <节省了空间是> 水箭 双足飞龙骑手 Hit -179 (Frost)", -- [27]
				"学者塔里娅 恢复 水元素 <节省了空间是> Tick +202", -- [28]
				"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -286 (Physical)", -- [29]
				"水元素 <节省了空间是> 水箭 双足飞龙骑手 Crit -359 (Frost)", -- [30]
				"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -341 (Physical)", -- [31]
				"学者塔里娅 恢复 水元素 <节省了空间是> Tick +202", -- [32]
				"水元素 <节省了空间是> 水箭 双足飞龙骑手 Hit -179 (Frost)", -- [33]
				"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -401 (Physical)", -- [34]
				"学者塔里娅 恢复 水元素 <节省了空间是> Tick +202", -- [35]
				"水元素 <节省了空间是> 水箭 双足飞龙骑手 Hit -179 (Frost)", -- [36]
				"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -385 (Physical)", -- [37]
				"水元素 <节省了空间是> 水箭 双足飞龙骑手 Hit -179 (Frost)", -- [38]
				"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -289 (Physical)", -- [39]
				"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -292 (Physical)", -- [40]
				"水元素 <节省了空间是> 水箭 双足飞龙骑手 Hit -179 (Frost)", -- [41]
				"学者塔里娅 恢复 水元素 <节省了空间是> Tick +202", -- [42]
				"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -294 (Physical)", -- [43]
				"水元素 <节省了空间是> 水箭 双足飞龙骑手 Crit -359 (Frost)", -- [44]
				"学者塔里娅 恢复 水元素 <节省了空间是> Tick +202", -- [45]
				"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -334 (Physical)", -- [46]
				"水元素 <节省了空间是> 水箭 双足飞龙骑手 Hit -179 (Frost)", -- [47]
				"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -377 (Physical)", -- [48]
				"学者塔里娅 恢复 水元素 <节省了空间是> Tick +202", -- [49]
				"水元素 <节省了空间是> 水箭 双足飞龙骑手 Hit -179 (Frost)", -- [50]
			},
			["Name"] = "水元素",
			["DeathLogs"] = {
				{
					["MessageIncoming"] = {
						true, -- [1]
						true, -- [2]
						false, -- [3]
						true, -- [4]
						false, -- [5]
						true, -- [6]
						true, -- [7]
						false, -- [8]
						true, -- [9]
						true, -- [10]
						false, -- [11]
						true, -- [12]
						false, -- [13]
						true, -- [14]
						true, -- [15]
						false, -- [16]
						true, -- [17]
						false, -- [18]
						true, -- [19]
						true, -- [20]
					},
					["Messages"] = {
						"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -377 (Physical)", -- [1]
						"学者塔里娅 恢复 水元素 <节省了空间是> Tick +202", -- [2]
						"水元素 <节省了空间是> 水箭 双足飞龙骑手 Hit -179 (Frost)", -- [3]
						"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -419 (Physical)", -- [4]
						"水元素 <节省了空间是> 水箭 双足飞龙骑手 Hit -179 (Frost)", -- [5]
						"学者塔里娅 恢复 水元素 <节省了空间是> Tick +202", -- [6]
						"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -392 (Physical)", -- [7]
						"水元素 <节省了空间是> 水箭 双足飞龙骑手 Hit -179 (Frost)", -- [8]
						"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -387 (Physical)", -- [9]
						"学者塔里娅 恢复 水元素 <节省了空间是> Tick +202", -- [10]
						"水元素 <节省了空间是> 水箭 双足飞龙骑手 Hit -179 (Frost)", -- [11]
						"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -289 (Physical)", -- [12]
						"水元素 <节省了空间是> 水箭 双足飞龙骑手 Hit -179 (Frost)", -- [13]
						"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -304 (Physical)", -- [14]
						"学者塔里娅 恢复 水元素 <节省了空间是> Tick +202", -- [15]
						"水元素 <节省了空间是> 水箭 双足飞龙骑手 Hit -179 (Frost)", -- [16]
						"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -352 (Physical)", -- [17]
						"水元素 <节省了空间是> 水箭 双足飞龙骑手 Crit -359 (Frost)", -- [18]
						"双足飞龙骑手 肉搏 水元素 <节省了空间是> Hit -359 (Physical)", -- [19]
						"水元素 <节省了空间是>死亡。", -- [20]
					},
					["DeathAt"] = 11594.261,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
					},
					["MessageTimes"] = {
						-14.0470000000005, -- [1]
						-13.9050000000007, -- [2]
						-13.4510000000009, -- [3]
						-12.0390000000007, -- [4]
						-11.2470000000012, -- [5]
						-10.9070000000011, -- [6]
						-10.0460000000003, -- [7]
						-9.04500000000007, -- [8]
						-8.03600000000006, -- [9]
						-7.89400000000023, -- [10]
						-6.83899999999994, -- [11]
						-6.02900000000045, -- [12]
						-4.65700000000106, -- [13]
						-4.03700000000026, -- [14]
						-2.83200000000034, -- [15]
						-2.44800000000032, -- [16]
						-2.01400000000103, -- [17]
						-0.256000000001222, -- [18]
						-0.0170000000016444, -- [19]
						0, -- [20]
					},
					["HealthMax"] = {
						11928, -- [1]
						11928, -- [2]
						11928, -- [3]
						11928, -- [4]
						11928, -- [5]
						11928, -- [6]
						11928, -- [7]
						11928, -- [8]
						11928, -- [9]
						11928, -- [10]
						11928, -- [11]
						11928, -- [12]
						11928, -- [13]
						11928, -- [14]
						11928, -- [15]
						11928, -- [16]
						11928, -- [17]
						11928, -- [18]
						11928, -- [19]
						11928, -- [20]
					},
					["Health"] = {
						1781, -- [1]
						1606, -- [2]
						1606, -- [3]
						1606, -- [4]
						1187, -- [5]
						1389, -- [6]
						1389, -- [7]
						997, -- [8]
						997, -- [9]
						1199, -- [10]
						812, -- [11]
						812, -- [12]
						523, -- [13]
						523, -- [14]
						421, -- [15]
						421, -- [16]
						421, -- [17]
						69, -- [18]
						69, -- [19]
						0, -- [20]
					},
					["KilledBy"] = "双足飞龙骑手",
					["MessageType"] = {
						"DAMAGE", -- [1]
						"HEAL", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"HEAL", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"HEAL", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"HEAL", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"MISC", -- [20]
					},
				}, -- [1]
				{
					["MessageIncoming"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						true, -- [4]
						true, -- [5]
						true, -- [6]
						true, -- [7]
						true, -- [8]
						true, -- [9]
						true, -- [10]
						true, -- [11]
						true, -- [12]
						true, -- [13]
						true, -- [14]
						true, -- [15]
						true, -- [16]
						true, -- [17]
						true, -- [18]
						true, -- [19]
						true, -- [20]
						true, -- [21]
						true, -- [22]
						true, -- [23]
						true, -- [24]
						true, -- [25]
						true, -- [26]
						true, -- [27]
						true, -- [28]
						true, -- [29]
						true, -- [30]
						true, -- [31]
						true, -- [32]
						true, -- [33]
						true, -- [34]
						true, -- [35]
						true, -- [36]
						true, -- [37]
						true, -- [38]
						true, -- [39]
						true, -- [40]
						true, -- [41]
						true, -- [42]
						true, -- [43]
						true, -- [44]
						true, -- [45]
						true, -- [46]
						true, -- [47]
						true, -- [48]
						true, -- [49]
						true, -- [50]
					},
					["Messages"] = {
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -249 (Physical)", -- [1]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -199 (Physical)", -- [2]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -176 (Physical)", -- [3]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -212 (Physical)", -- [4]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -206 (Physical)", -- [5]
						"部落步兵 肉搏 水元素 <节省了空间是> Parry (1)", -- [6]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -239 (Physical)", -- [7]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -198 (Physical)", -- [8]
						"部落步兵 肉搏 水元素 <节省了空间是> Miss (1)", -- [9]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -211 (Physical)", -- [10]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -219 (Physical)", -- [11]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -230 (Physical)", -- [12]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -249 (Physical)", -- [13]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -210 (Physical)", -- [14]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -197 (Physical)", -- [15]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -187 (Physical)", -- [16]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -234 (Physical)", -- [17]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -199 (Physical)", -- [18]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -226 (Physical)", -- [19]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -238 (Physical)", -- [20]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -200 (Physical)", -- [21]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -208 (Physical)", -- [22]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -240 (Physical)", -- [23]
						"部落步兵 肉搏 水元素 <节省了空间是> Miss (1)", -- [24]
						"部落步兵 肉搏 水元素 <节省了空间是> Dodge (1)", -- [25]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -171 (Physical)", -- [26]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -218 (Physical)", -- [27]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -224 (Physical)", -- [28]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -228 (Physical)", -- [29]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -239 (Physical)", -- [30]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -222 (Physical)", -- [31]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -202 (Physical)", -- [32]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -186 (Physical)", -- [33]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -194 (Physical)", -- [34]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -187 (Physical)", -- [35]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -226 (Physical)", -- [36]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -225 (Physical)", -- [37]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -170 (Physical)", -- [38]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -170 (Physical)", -- [39]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -202 (Physical)", -- [40]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -176 (Physical)", -- [41]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -199 (Physical)", -- [42]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -248 (Physical)", -- [43]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -233 (Physical)", -- [44]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -248 (Physical)", -- [45]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -228 (Physical)", -- [46]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -230 (Physical)", -- [47]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -194 (Physical)", -- [48]
						"部落步兵 肉搏 水元素 <节省了空间是> Hit -174 (Physical)", -- [49]
						"水元素 <节省了空间是>死亡。", -- [50]
					},
					["DeathAt"] = 11220.552,
					["EventNum"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						0, -- [6]
						0, -- [7]
						0, -- [8]
						0, -- [9]
						0, -- [10]
						0, -- [11]
						0, -- [12]
						0, -- [13]
						0, -- [14]
						0, -- [15]
						0, -- [16]
						0, -- [17]
						0, -- [18]
						0, -- [19]
						0, -- [20]
						0, -- [21]
						0, -- [22]
						0, -- [23]
						0, -- [24]
						0, -- [25]
						0, -- [26]
						0, -- [27]
						0, -- [28]
						0, -- [29]
						0, -- [30]
						0, -- [31]
						0, -- [32]
						0, -- [33]
						0, -- [34]
						0, -- [35]
						0, -- [36]
						0, -- [37]
						0, -- [38]
						0, -- [39]
						0, -- [40]
						0, -- [41]
						0, -- [42]
						0, -- [43]
						0, -- [44]
						0, -- [45]
						0, -- [46]
						0, -- [47]
						0, -- [48]
						0, -- [49]
						0, -- [50]
					},
					["MessageTimes"] = {
						-9.33699999999953, -- [1]
						-8.41100000000006, -- [2]
						-8.11599999999999, -- [3]
						-8.04899999999907, -- [4]
						-8.03199999999924, -- [5]
						-7.91899999999987, -- [6]
						-7.69499999999971, -- [7]
						-7.61599999999999, -- [8]
						-7.61599999999999, -- [9]
						-7.55099999999948, -- [10]
						-7.32399999999871, -- [11]
						-7.32399999999871, -- [12]
						-6.41299999999865, -- [13]
						-6.10999999999876, -- [14]
						-6.04599999999846, -- [15]
						-6.02999999999884, -- [16]
						-5.91799999999967, -- [17]
						-5.69399999999951, -- [18]
						-5.61299999999937, -- [19]
						-5.61299999999937, -- [20]
						-5.54899999999907, -- [21]
						-5.31999999999971, -- [22]
						-5.31999999999971, -- [23]
						-4.40699999999924, -- [24]
						-4.11199999999917, -- [25]
						-4.04599999999846, -- [26]
						-4.02899999999863, -- [27]
						-3.91199999999844, -- [28]
						-3.69899999999871, -- [29]
						-3.61999999999898, -- [30]
						-3.61999999999898, -- [31]
						-3.53899999999885, -- [32]
						-3.30999999999949, -- [33]
						-3.30999999999949, -- [34]
						-2.40899999999965, -- [35]
						-2.10399999999936, -- [36]
						-2.03699999999844, -- [37]
						-2.03699999999844, -- [38]
						-1.90299999999843, -- [39]
						-1.68399999999929, -- [40]
						-1.61999999999898, -- [41]
						-1.60399999999936, -- [42]
						-1.53899999999885, -- [43]
						-1.31099999999969, -- [44]
						-1.31099999999969, -- [45]
						-0.415999999999258, -- [46]
						-0.0999999999985448, -- [47]
						-0.032999999999447, -- [48]
						-0.0159999999996217, -- [49]
						0, -- [50]
					},
					["HealthMax"] = {
						11928, -- [1]
						11928, -- [2]
						11928, -- [3]
						11928, -- [4]
						11928, -- [5]
						11928, -- [6]
						11928, -- [7]
						11928, -- [8]
						11928, -- [9]
						11928, -- [10]
						11928, -- [11]
						11928, -- [12]
						11928, -- [13]
						11928, -- [14]
						11928, -- [15]
						11928, -- [16]
						11928, -- [17]
						11928, -- [18]
						11928, -- [19]
						11928, -- [20]
						11928, -- [21]
						11928, -- [22]
						11928, -- [23]
						11928, -- [24]
						11928, -- [25]
						11928, -- [26]
						11928, -- [27]
						11928, -- [28]
						11928, -- [29]
						11928, -- [30]
						11928, -- [31]
						11928, -- [32]
						11928, -- [33]
						11928, -- [34]
						11928, -- [35]
						11928, -- [36]
						11928, -- [37]
						11928, -- [38]
						11928, -- [39]
						11928, -- [40]
						11928, -- [41]
						11928, -- [42]
						11928, -- [43]
						11928, -- [44]
						11928, -- [45]
						11928, -- [46]
						11928, -- [47]
						11928, -- [48]
						11928, -- [49]
						11928, -- [50]
					},
					["Health"] = {
						9860, -- [1]
						9216, -- [2]
						9216, -- [3]
						8841, -- [4]
						8841, -- [5]
						8841, -- [6]
						8841, -- [7]
						8423, -- [8]
						8423, -- [9]
						8423, -- [10]
						7775, -- [11]
						7775, -- [12]
						7326, -- [13]
						7326, -- [14]
						6867, -- [15]
						6867, -- [16]
						6867, -- [17]
						6867, -- [18]
						6050, -- [19]
						6050, -- [20]
						6050, -- [21]
						5386, -- [22]
						5386, -- [23]
						4938, -- [24]
						4938, -- [25]
						4938, -- [26]
						4938, -- [27]
						4767, -- [28]
						4767, -- [29]
						4097, -- [30]
						4097, -- [31]
						4097, -- [32]
						4097, -- [33]
						4097, -- [34]
						3054, -- [35]
						3054, -- [36]
						3054, -- [37]
						3054, -- [38]
						2246, -- [39]
						2246, -- [40]
						2246, -- [41]
						2246, -- [42]
						1499, -- [43]
						1499, -- [44]
						1499, -- [45]
						770, -- [46]
						542, -- [47]
						542, -- [48]
						542, -- [49]
						0, -- [50]
					},
					["KilledBy"] = "部落步兵",
					["MessageType"] = {
						"DAMAGE", -- [1]
						"DAMAGE", -- [2]
						"DAMAGE", -- [3]
						"DAMAGE", -- [4]
						"DAMAGE", -- [5]
						"DAMAGE", -- [6]
						"DAMAGE", -- [7]
						"DAMAGE", -- [8]
						"DAMAGE", -- [9]
						"DAMAGE", -- [10]
						"DAMAGE", -- [11]
						"DAMAGE", -- [12]
						"DAMAGE", -- [13]
						"DAMAGE", -- [14]
						"DAMAGE", -- [15]
						"DAMAGE", -- [16]
						"DAMAGE", -- [17]
						"DAMAGE", -- [18]
						"DAMAGE", -- [19]
						"DAMAGE", -- [20]
						"DAMAGE", -- [21]
						"DAMAGE", -- [22]
						"DAMAGE", -- [23]
						"DAMAGE", -- [24]
						"DAMAGE", -- [25]
						"DAMAGE", -- [26]
						"DAMAGE", -- [27]
						"DAMAGE", -- [28]
						"DAMAGE", -- [29]
						"DAMAGE", -- [30]
						"DAMAGE", -- [31]
						"DAMAGE", -- [32]
						"DAMAGE", -- [33]
						"DAMAGE", -- [34]
						"DAMAGE", -- [35]
						"DAMAGE", -- [36]
						"DAMAGE", -- [37]
						"DAMAGE", -- [38]
						"DAMAGE", -- [39]
						"DAMAGE", -- [40]
						"DAMAGE", -- [41]
						"DAMAGE", -- [42]
						"DAMAGE", -- [43]
						"DAMAGE", -- [44]
						"DAMAGE", -- [45]
						"DAMAGE", -- [46]
						"DAMAGE", -- [47]
						"DAMAGE", -- [48]
						"DAMAGE", -- [49]
						"MISC", -- [50]
					},
				}, -- [2]
			},
			["TimeLast"] = {
				["DeathCount"] = 11592.258,
				["HealingTaken"] = 11589.25,
				["ActiveTime"] = 11591.244,
				["TimeDamage"] = 11591.244,
				["OVERALL"] = 11592.258,
				["DamageTaken"] = 11592.258,
				["Damage"] = 11591.244,
			},
			["LastDamageTaken"] = 359,
			["LastEventHealthMax"] = {
				11928, -- [1]
				11928, -- [2]
				11928, -- [3]
				11928, -- [4]
				11928, -- [5]
				11928, -- [6]
				11928, -- [7]
				11928, -- [8]
				11928, -- [9]
				11928, -- [10]
				11928, -- [11]
				11928, -- [12]
				11928, -- [13]
				11928, -- [14]
				11928, -- [15]
				11928, -- [16]
				11928, -- [17]
				11928, -- [18]
				11928, -- [19]
				11928, -- [20]
				11928, -- [21]
				11928, -- [22]
				11928, -- [23]
				11928, -- [24]
				11928, -- [25]
				11928, -- [26]
				11928, -- [27]
				11928, -- [28]
				11928, -- [29]
				11928, -- [30]
				11928, -- [31]
				11928, -- [32]
				11928, -- [33]
				11928, -- [34]
				11928, -- [35]
				11928, -- [36]
				11928, -- [37]
				11928, -- [38]
				11928, -- [39]
				11928, -- [40]
				11928, -- [41]
				11928, -- [42]
				11928, -- [43]
				11928, -- [44]
				11928, -- [45]
				11928, -- [46]
				11928, -- [47]
				11928, -- [48]
				11928, -- [49]
				11928, -- [50]
			},
			["LastActive"] = 11592.258,
		},
		["节省了空间是"] = {
			["GUID"] = "Player-1948-06578F0D",
			["LastEventHealth"] = {
				8534, -- [1]
				8534, -- [2]
				8237, -- [3]
				8237, -- [4]
				8439, -- [5]
				8439, -- [6]
				8439, -- [7]
				8439, -- [8]
				8439, -- [9]
				8439, -- [10]
				8439, -- [11]
				8439, -- [12]
				8439, -- [13]
				8439, -- [14]
				8439, -- [15]
				8439, -- [16]
				8439, -- [17]
				8439, -- [18]
				8439, -- [19]
				19880, -- [20]
				9353, -- [21]
				9353, -- [22]
				9328, -- [23]
				9328, -- [24]
				9328, -- [25]
				9328, -- [26]
				9082, -- [27]
				9082, -- [28]
				9082, -- [29]
				9082, -- [30]
				9082, -- [31]
				9056, -- [32]
				9056, -- [33]
				9056, -- [34]
				9056, -- [35]
				9056, -- [36]
				8843, -- [37]
				8843, -- [38]
				8843, -- [39]
				8595, -- [40]
				8595, -- [41]
				8595, -- [42]
				8576, -- [43]
				8576, -- [44]
				8319, -- [45]
				8299, -- [46]
				8534, -- [47]
				8534, -- [48]
				8534, -- [49]
				8534, -- [50]
			},
			["LastAttackedBy"] = "部落步兵",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"HEAL", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"HEAL", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"HEAL", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"HEAL", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"HEAL", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"HEAL", -- [46]
				"HEAL", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["HealingTaken"] = {
					10879, -- [1]
				},
				["ActiveTime"] = {
					117.98, -- [1]
				},
				["TimeDamage"] = {
					117.98, -- [1]
				},
				["Healing"] = {
					0, -- [1]
				},
				["DamageTaken"] = {
					25592, -- [1]
				},
				["Damage"] = {
					85936, -- [1]
				},
			},
			["enClass"] = "MAGE",
			["unit"] = "节省了空间是",
			["LastAbility"] = 11477.809,
			["LastDamageTaken"] = 293,
			["level"] = 110,
			["LastDamageAbility"] = "肉搏",
			["LastFightIn"] = 5,
			["UnitLockout"] = 10794.547,
			["type"] = "Self",
			["FightsSaved"] = 5,
			["GuardianReverseGUIDs"] = {
				["水元素"] = {
					["LatestGuardian"] = 1,
					["GUIDs"] = {
						"Pet-0-3148-1949-18912-78116-01026DFD69", -- [1]
						[0] = "Creature-0-3148-1949-18912-78116-0000239E53",
					},
				},
			},
			["Fights"] = {
				["OverallData"] = {
					["TimeSpent"] = {
						["双足飞龙骑手"] = {
							["Details"] = {
								["暴风雪"] = {
									["count"] = 13.55,
								},
							},
							["amount"] = 13.55,
						},
						["目标假人"] = {
							["Details"] = {
								["冰枪术"] = {
									["count"] = 7.53,
								},
								["寒冰箭"] = {
									["count"] = 22.69,
								},
								["冰刺"] = {
									["count"] = 6.51,
								},
								["冰风暴"] = {
									["count"] = 6.17,
								},
							},
							["amount"] = 42.9,
						},
						["联盟步兵"] = {
							["Details"] = {
								["冰风暴"] = {
									["count"] = 3.74,
								},
								["冰霜新星"] = {
									["count"] = 3,
								},
								["冰枪术"] = {
									["count"] = 0.12,
								},
								["寒冰箭"] = {
									["count"] = 22.61,
								},
								["冰刺"] = {
									["count"] = 1.44,
								},
							},
							["amount"] = 30.91,
						},
						["奥术构造体"] = {
							["Details"] = {
								["暴风雪"] = {
									["count"] = 10.03,
								},
							},
							["amount"] = 10.03,
						},
						["部落步兵"] = {
							["Details"] = {
								["暴风雪"] = {
									["count"] = 20.59,
								},
							},
							["amount"] = 20.59,
						},
					},
					["DamageTaken"] = 25592,
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 96,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 96,
						},
					},
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 96,
									["amount"] = 0,
								},
							},
							["count"] = 96,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 117.98,
					["ElementTaken"] = {
						["Melee"] = 25592,
					},
					["Damage"] = 85936,
					["Healing"] = 0,
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 107,
								},
								["Hit"] = {
									["count"] = 151,
								},
							},
							["amount"] = 258,
						},
					},
					["ElementDone"] = {
						["Frost"] = 85936,
					},
					["HealingTaken"] = 10879,
					["DamagedWho"] = {
						["双足飞龙骑手"] = {
							["Details"] = {
								["暴风雪"] = {
									["count"] = 1981,
								},
							},
							["amount"] = 1981,
						},
						["目标假人"] = {
							["Details"] = {
								["冰枪术"] = {
									["count"] = 13745,
								},
								["寒冰箭"] = {
									["count"] = 10450,
								},
								["冰刺"] = {
									["count"] = 11991,
								},
								["冰风暴"] = {
									["count"] = 7885,
								},
							},
							["amount"] = 44071,
						},
						["联盟步兵"] = {
							["Details"] = {
								["冰风暴"] = {
									["count"] = 3874,
								},
								["冰霜新星"] = {
									["count"] = 110,
								},
								["冰枪术"] = {
									["count"] = 1718,
								},
								["寒冰箭"] = {
									["count"] = 8778,
								},
								["冰刺"] = {
									["count"] = 5184,
								},
							},
							["amount"] = 19664,
						},
						["奥术构造体"] = {
							["Details"] = {
								["暴风雪"] = {
									["count"] = 6361,
								},
							},
							["amount"] = 6361,
						},
						["部落步兵"] = {
							["Details"] = {
								["暴风雪"] = {
									["count"] = 13859,
								},
							},
							["amount"] = 13859,
						},
					},
					["TimeDamage"] = 117.98,
					["TimeDamaging"] = {
						["双足飞龙骑手"] = {
							["Details"] = {
								["暴风雪"] = {
									["count"] = 13.55,
								},
							},
							["amount"] = 13.55,
						},
						["目标假人"] = {
							["Details"] = {
								["冰枪术"] = {
									["count"] = 7.53,
								},
								["寒冰箭"] = {
									["count"] = 22.69,
								},
								["冰刺"] = {
									["count"] = 6.51,
								},
								["冰风暴"] = {
									["count"] = 6.17,
								},
							},
							["amount"] = 42.9,
						},
						["联盟步兵"] = {
							["Details"] = {
								["冰风暴"] = {
									["count"] = 3.74,
								},
								["冰霜新星"] = {
									["count"] = 3,
								},
								["冰枪术"] = {
									["count"] = 0.12,
								},
								["寒冰箭"] = {
									["count"] = 22.61,
								},
								["冰刺"] = {
									["count"] = 1.44,
								},
							},
							["amount"] = 30.91,
						},
						["奥术构造体"] = {
							["Details"] = {
								["暴风雪"] = {
									["count"] = 10.03,
								},
							},
							["amount"] = 10.03,
						},
						["部落步兵"] = {
							["Details"] = {
								["暴风雪"] = {
									["count"] = 20.59,
								},
							},
							["amount"] = 20.59,
						},
					},
					["WhoDamaged"] = {
						["部落步兵"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 14245,
								},
							},
							["amount"] = 14245,
						},
						["联盟步兵"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 11347,
								},
							},
							["amount"] = 11347,
						},
					},
					["Attacks"] = {
						["冰刺"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 649,
									["min"] = 648,
									["count"] = 21,
									["amount"] = 13611,
								},
								["Hit"] = {
									["max"] = 324,
									["min"] = 324,
									["count"] = 11,
									["amount"] = 3564,
								},
							},
							["count"] = 32,
							["amount"] = 17175,
						},
						["冰霜新星"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 73,
									["min"] = 73,
									["count"] = 1,
									["amount"] = 73,
								},
								["Hit"] = {
									["max"] = 37,
									["min"] = 37,
									["count"] = 1,
									["amount"] = 37,
								},
							},
							["count"] = 2,
							["amount"] = 110,
						},
						["冰枪术"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1719,
									["min"] = 1718,
									["count"] = 9,
									["amount"] = 15463,
								},
							},
							["count"] = 9,
							["amount"] = 15463,
						},
						["寒冰箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 836,
									["min"] = 836,
									["count"] = 13,
									["amount"] = 10868,
								},
								["Hit"] = {
									["max"] = 418,
									["min"] = 418,
									["count"] = 20,
									["amount"] = 8360,
								},
							},
							["count"] = 33,
							["amount"] = 19228,
						},
						["冰风暴"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 776,
									["min"] = 517,
									["count"] = 14,
									["amount"] = 10338,
								},
								["Hit"] = {
									["max"] = 388,
									["min"] = 259,
									["count"] = 4,
									["amount"] = 1421,
								},
							},
							["count"] = 18,
							["amount"] = 11759,
						},
						["暴风雪"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 209,
									["min"] = 209,
									["count"] = 49,
									["amount"] = 10241,
								},
								["Hit"] = {
									["max"] = 104,
									["min"] = 104,
									["count"] = 115,
									["amount"] = 11960,
								},
							},
							["count"] = 164,
							["amount"] = 22201,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 88,
								},
								["Crit"] = {
									["count"] = 5,
								},
								["Miss"] = {
									["count"] = 3,
								},
							},
							["amount"] = 96,
						},
					},
				},
				["Fight5"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 2778,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 9,
								},
							},
							["amount"] = 10,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
						["Melee"] = 2778,
					},
					["DOT_Time"] = 0,
					["Damage"] = 37,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 10,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Frost"] = 37,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
						["联盟步兵"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 2778,
								},
							},
							["amount"] = 2778,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 1.5,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 10,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 10,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["联盟步兵"] = {
							["Details"] = {
								["冰霜新星"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["冰霜新星"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 37,
									["min"] = 37,
									["count"] = 1,
									["amount"] = 37,
								},
							},
							["count"] = 1,
							["amount"] = 37,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["联盟步兵"] = {
							["Details"] = {
								["冰霜新星"] = {
									["count"] = 37,
								},
							},
							["amount"] = 37,
						},
					},
					["TimeDamage"] = 1.5,
					["TimeDamaging"] = {
						["联盟步兵"] = {
							["Details"] = {
								["冰霜新星"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["TimeSpent"] = {
						["目标假人"] = {
							["Details"] = {
								["冰枪术"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["冰刺"] = {
									["count"] = 0,
								},
								["冰风暴"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["ElementDone"] = {
						["Frost"] = 0,
					},
					["ActiveTime"] = 0,
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["目标假人"] = {
							["Details"] = {
								["冰枪术"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["冰刺"] = {
									["count"] = 0,
								},
								["冰风暴"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["冰枪术"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["寒冰箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["冰刺"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["冰风暴"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["目标假人"] = {
							["Details"] = {
								["冰枪术"] = {
									["count"] = 0,
								},
								["寒冰箭"] = {
									["count"] = 0,
								},
								["冰刺"] = {
									["count"] = 0,
								},
								["冰风暴"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Damage"] = 0,
				},
				["Fight1"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 14245,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 52,
								},
								["Crit"] = {
									["count"] = 2,
								},
								["Miss"] = {
									["count"] = 3,
								},
							},
							["amount"] = 57,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
						["Melee"] = 14245,
					},
					["DOT_Time"] = 0,
					["Damage"] = 15840,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 57,
									["amount"] = 0,
								},
							},
							["count"] = 57,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Frost"] = 15840,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 32,
								},
								["Hit"] = {
									["count"] = 88,
								},
							},
							["amount"] = 120,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
						["部落步兵"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 14245,
								},
							},
							["amount"] = 14245,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 34.14,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 57,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 57,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["双足飞龙骑手"] = {
							["Details"] = {
								["暴风雪"] = {
									["count"] = 13.55,
								},
							},
							["amount"] = 13.55,
						},
						["部落步兵"] = {
							["Details"] = {
								["暴风雪"] = {
									["count"] = 20.59,
								},
							},
							["amount"] = 20.59,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["暴风雪"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 209,
									["min"] = 209,
									["count"] = 32,
									["amount"] = 6688,
								},
								["Hit"] = {
									["max"] = 104,
									["min"] = 104,
									["count"] = 88,
									["amount"] = 9152,
								},
							},
							["count"] = 120,
							["amount"] = 15840,
						},
					},
					["HealingTaken"] = 2511,
					["DamagedWho"] = {
						["双足飞龙骑手"] = {
							["Details"] = {
								["暴风雪"] = {
									["count"] = 1981,
								},
							},
							["amount"] = 1981,
						},
						["部落步兵"] = {
							["Details"] = {
								["暴风雪"] = {
									["count"] = 13859,
								},
							},
							["amount"] = 13859,
						},
					},
					["TimeDamage"] = 34.14,
					["TimeDamaging"] = {
						["双足飞龙骑手"] = {
							["Details"] = {
								["暴风雪"] = {
									["count"] = 13.55,
								},
							},
							["amount"] = 13.55,
						},
						["部落步兵"] = {
							["Details"] = {
								["暴风雪"] = {
									["count"] = 20.59,
								},
							},
							["amount"] = 20.59,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight4"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 6361,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Frost"] = 6361,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 17,
								},
								["Hit"] = {
									["count"] = 27,
								},
							},
							["amount"] = 44,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 10.03,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["奥术构造体"] = {
							["Details"] = {
								["暴风雪"] = {
									["count"] = 10.03,
								},
							},
							["amount"] = 10.03,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["暴风雪"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 209,
									["min"] = 209,
									["count"] = 17,
									["amount"] = 3553,
								},
								["Hit"] = {
									["max"] = 104,
									["min"] = 104,
									["count"] = 27,
									["amount"] = 2808,
								},
							},
							["count"] = 44,
							["amount"] = 6361,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["奥术构造体"] = {
							["Details"] = {
								["暴风雪"] = {
									["count"] = 6361,
								},
							},
							["amount"] = 6361,
						},
					},
					["TimeDamage"] = 10.03,
					["TimeDamaging"] = {
						["奥术构造体"] = {
							["Details"] = {
								["暴风雪"] = {
									["count"] = 10.03,
								},
							},
							["amount"] = 10.03,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 14245,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 52,
								},
								["Crit"] = {
									["count"] = 2,
								},
								["Miss"] = {
									["count"] = 3,
								},
							},
							["amount"] = 57,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
						["Melee"] = 14245,
					},
					["DOT_Time"] = 0,
					["Damage"] = 15840,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 57,
									["amount"] = 0,
								},
							},
							["count"] = 57,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Frost"] = 15840,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 32,
								},
								["Hit"] = {
									["count"] = 88,
								},
							},
							["amount"] = 120,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
						["部落步兵"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 14245,
								},
							},
							["amount"] = 14245,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 34.14,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 57,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 57,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["双足飞龙骑手"] = {
							["Details"] = {
								["暴风雪"] = {
									["count"] = 13.55,
								},
							},
							["amount"] = 13.55,
						},
						["部落步兵"] = {
							["Details"] = {
								["暴风雪"] = {
									["count"] = 20.59,
								},
							},
							["amount"] = 20.59,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["暴风雪"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 209,
									["min"] = 209,
									["count"] = 32,
									["amount"] = 6688,
								},
								["Hit"] = {
									["max"] = 104,
									["min"] = 104,
									["count"] = 88,
									["amount"] = 9152,
								},
							},
							["count"] = 120,
							["amount"] = 15840,
						},
					},
					["HealingTaken"] = 2511,
					["DamagedWho"] = {
						["双足飞龙骑手"] = {
							["Details"] = {
								["暴风雪"] = {
									["count"] = 1981,
								},
							},
							["amount"] = 1981,
						},
						["部落步兵"] = {
							["Details"] = {
								["暴风雪"] = {
									["count"] = 13859,
								},
							},
							["amount"] = 13859,
						},
					},
					["TimeDamage"] = 34.14,
					["TimeDamaging"] = {
						["双足飞龙骑手"] = {
							["Details"] = {
								["暴风雪"] = {
									["count"] = 13.55,
								},
							},
							["amount"] = 13.55,
						},
						["部落步兵"] = {
							["Details"] = {
								["暴风雪"] = {
									["count"] = 20.59,
								},
							},
							["amount"] = 20.59,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight2"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 6312,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 20,
								},
							},
							["amount"] = 21,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
						["Melee"] = 6312,
					},
					["DOT_Time"] = 0,
					["Damage"] = 13362,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 21,
									["amount"] = 0,
								},
							},
							["count"] = 21,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Frost"] = 13362,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 9,
								},
								["Hit"] = {
									["count"] = 15,
								},
							},
							["amount"] = 24,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
						["联盟步兵"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 6312,
								},
							},
							["amount"] = 6312,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 18.2,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 21,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 21,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["联盟步兵"] = {
							["Details"] = {
								["冰枪术"] = {
									["count"] = 0.12,
								},
								["寒冰箭"] = {
									["count"] = 16.5,
								},
								["冰刺"] = {
									["count"] = 1.3,
								},
								["冰风暴"] = {
									["count"] = 0.28,
								},
							},
							["amount"] = 18.2,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["冰枪术"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1718,
									["min"] = 1718,
									["count"] = 1,
									["amount"] = 1718,
								},
							},
							["count"] = 1,
							["amount"] = 1718,
						},
						["寒冰箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 836,
									["min"] = 836,
									["count"] = 4,
									["amount"] = 3344,
								},
								["Hit"] = {
									["max"] = 418,
									["min"] = 418,
									["count"] = 7,
									["amount"] = 2926,
								},
							},
							["count"] = 11,
							["amount"] = 6270,
						},
						["冰刺"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 648,
									["min"] = 648,
									["count"] = 3,
									["amount"] = 1944,
								},
								["Hit"] = {
									["max"] = 324,
									["min"] = 324,
									["count"] = 7,
									["amount"] = 2268,
								},
							},
							["count"] = 10,
							["amount"] = 4212,
						},
						["冰风暴"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 775,
									["min"] = 775,
									["count"] = 1,
									["amount"] = 775,
								},
								["Hit"] = {
									["max"] = 387,
									["min"] = 387,
									["count"] = 1,
									["amount"] = 387,
								},
							},
							["count"] = 2,
							["amount"] = 1162,
						},
					},
					["HealingTaken"] = 6312,
					["DamagedWho"] = {
						["联盟步兵"] = {
							["Details"] = {
								["冰枪术"] = {
									["count"] = 1718,
								},
								["寒冰箭"] = {
									["count"] = 6270,
								},
								["冰刺"] = {
									["count"] = 4212,
								},
								["冰风暴"] = {
									["count"] = 1162,
								},
							},
							["amount"] = 13362,
						},
					},
					["TimeDamage"] = 18.2,
					["TimeDamaging"] = {
						["联盟步兵"] = {
							["Details"] = {
								["冰枪术"] = {
									["count"] = 0.12,
								},
								["寒冰箭"] = {
									["count"] = 16.5,
								},
								["冰刺"] = {
									["count"] = 1.3,
								},
								["冰风暴"] = {
									["count"] = 0.28,
								},
							},
							["amount"] = 18.2,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight3"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 2257,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 7,
								},
							},
							["amount"] = 8,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
						["Melee"] = 2257,
					},
					["DOT_Time"] = 0,
					["Damage"] = 6265,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Frost"] = 6265,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Frost"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 12,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
						["联盟步兵"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 2257,
								},
							},
							["amount"] = 2257,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 11.21,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 8,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["联盟步兵"] = {
							["Details"] = {
								["寒冰箭"] = {
									["count"] = 6.11,
								},
								["冰刺"] = {
									["count"] = 0.14,
								},
								["冰风暴"] = {
									["count"] = 3.46,
								},
								["冰霜新星"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 11.21,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["寒冰箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 836,
									["min"] = 836,
									["count"] = 1,
									["amount"] = 836,
								},
								["Hit"] = {
									["max"] = 418,
									["min"] = 418,
									["count"] = 4,
									["amount"] = 1672,
								},
							},
							["count"] = 5,
							["amount"] = 2508,
						},
						["冰刺"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 648,
									["min"] = 648,
									["count"] = 1,
									["amount"] = 648,
								},
								["Hit"] = {
									["max"] = 324,
									["min"] = 324,
									["count"] = 1,
									["amount"] = 324,
								},
							},
							["count"] = 2,
							["amount"] = 972,
						},
						["冰风暴"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 775,
									["min"] = 775,
									["count"] = 3,
									["amount"] = 2325,
								},
								["Hit"] = {
									["max"] = 387,
									["min"] = 387,
									["count"] = 1,
									["amount"] = 387,
								},
							},
							["count"] = 4,
							["amount"] = 2712,
						},
						["冰霜新星"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 73,
									["min"] = 73,
									["count"] = 1,
									["amount"] = 73,
								},
							},
							["count"] = 1,
							["amount"] = 73,
						},
					},
					["HealingTaken"] = 2056,
					["DamagedWho"] = {
						["联盟步兵"] = {
							["Details"] = {
								["寒冰箭"] = {
									["count"] = 2508,
								},
								["冰刺"] = {
									["count"] = 972,
								},
								["冰风暴"] = {
									["count"] = 2712,
								},
								["冰霜新星"] = {
									["count"] = 73,
								},
							},
							["amount"] = 6265,
						},
					},
					["TimeDamage"] = 11.21,
					["TimeDamaging"] = {
						["联盟步兵"] = {
							["Details"] = {
								["寒冰箭"] = {
									["count"] = 6.11,
								},
								["冰刺"] = {
									["count"] = 0.14,
								},
								["冰风暴"] = {
									["count"] = 3.46,
								},
								["冰霜新星"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 11.21,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
			},
			["Owner"] = false,
			["Pet"] = {
				"水元素 <节省了空间是>", -- [1]
			},
			["NextEventNum"] = 21,
			["LastDamageTime"] = 11629.14,
			["LastEvents"] = {
				"节省了空间是 暴风雪 部落步兵 Hit -104 (Frost)", -- [1]
				"部落步兵 肉搏 节省了空间是 Hit -297 (Physical)", -- [2]
				"节省了空间是 暴风雪 部落步兵 Hit -104 (Frost)", -- [3]
				"节省了空间是 暴风雪 部落步兵 Hit -104 (Frost)", -- [4]
				"学者塔里娅 恢复 节省了空间是 Tick +202", -- [5]
				"节省了空间是 暴风雪 部落步兵 Hit -104 (Frost)", -- [6]
				"节省了空间是 暴风雪 部落步兵 Crit -209 (Frost)", -- [7]
				"节省了空间是 暴风雪 部落步兵 Hit -104 (Frost)", -- [8]
				"节省了空间是 暴风雪 部落步兵 Hit -104 (Frost)", -- [9]
				"节省了空间是 暴风雪 部落步兵 Crit -209 (Frost)", -- [10]
				"节省了空间是 暴风雪 部落步兵 Hit -104 (Frost)", -- [11]
				"节省了空间是 暴风雪 部落步兵 Hit -104 (Frost)", -- [12]
				"节省了空间是 暴风雪 部落步兵 Hit -104 (Frost)", -- [13]
				"节省了空间是 暴风雪 部落步兵 Hit -104 (Frost)", -- [14]
				"节省了空间是 暴风雪 部落步兵 Hit -104 (Frost)", -- [15]
				"节省了空间是 暴风雪 部落步兵 Hit -104 (Frost)", -- [16]
				"节省了空间是 暴风雪 部落步兵 Hit -104 (Frost)", -- [17]
				"节省了空间是 暴风雪 部落步兵 Crit -209 (Frost)", -- [18]
				"部落步兵 肉搏 节省了空间是 Hit -293 (Physical)", -- [19]
				"学者塔里娅 强效治疗术 节省了空间是 Hit +19880 (8347 过量治疗)", -- [20]
				"节省了空间是 暴风雪 部落步兵 Hit -104 (Frost)", -- [21]
				"部落步兵 肉搏 节省了空间是 Hit -227 (Physical)", -- [22]
				"学者塔里娅 恢复 节省了空间是 Tick +202", -- [23]
				"节省了空间是 暴风雪 部落步兵 Crit -209 (Frost)", -- [24]
				"节省了空间是 暴风雪 部落步兵 Hit -104 (Frost)", -- [25]
				"部落步兵 肉搏 节省了空间是 Hit -246 (Physical)", -- [26]
				"节省了空间是 暴风雪 部落步兵 Hit -104 (Frost)", -- [27]
				"节省了空间是 暴风雪 部落步兵 Crit -209 (Frost)", -- [28]
				"节省了空间是 暴风雪 部落步兵 Hit -104 (Frost)", -- [29]
				"节省了空间是 暴风雪 部落步兵 Crit -209 (Frost)", -- [30]
				"部落步兵 肉搏 节省了空间是 Hit -228 (Physical)", -- [31]
				"学者塔里娅 恢复 节省了空间是 Tick +202", -- [32]
				"节省了空间是 暴风雪 部落步兵 Hit -104 (Frost)", -- [33]
				"节省了空间是 暴风雪 部落步兵 Hit -104 (Frost)", -- [34]
				"节省了空间是 暴风雪 部落步兵 Crit -209 (Frost)", -- [35]
				"部落步兵 肉搏 节省了空间是 Hit -213 (Physical)", -- [36]
				"节省了空间是 暴风雪 部落步兵 Hit -104 (Frost)", -- [37]
				"节省了空间是 暴风雪 部落步兵 Hit -104 (Frost)", -- [38]
				"部落步兵 肉搏 节省了空间是 Hit -248 (Physical)", -- [39]
				"节省了空间是 暴风雪 部落步兵 Crit -209 (Frost)", -- [40]
				"节省了空间是 暴风雪 部落步兵 Crit -209 (Frost)", -- [41]
				"部落步兵 肉搏 节省了空间是 Hit -221 (Physical)", -- [42]
				"学者塔里娅 恢复 节省了空间是 Tick +202", -- [43]
				"部落步兵 肉搏 节省了空间是 Hit -257 (Physical)", -- [44]
				"部落步兵 肉搏 节省了空间是 Hit -222 (Physical)", -- [45]
				"学者塔里娅 恢复 节省了空间是 Tick +202", -- [46]
				"学者塔里娅 神圣新星 节省了空间是 Hit +235", -- [47]
				"节省了空间是 暴风雪 部落步兵 Hit -104 (Frost)", -- [48]
				"节省了空间是 暴风雪 部落步兵 Hit -104 (Frost)", -- [49]
				"节省了空间是 暴风雪 部落步兵 Hit -104 (Frost)", -- [50]
			},
			["Name"] = "节省了空间是",
			["LastEventTimes"] = {
				11623.885, -- [1]
				11624.337, -- [2]
				11624.747, -- [3]
				11624.747, -- [4]
				11624.79, -- [5]
				11625.637, -- [6]
				11625.637, -- [7]
				11626.522, -- [8]
				11626.522, -- [9]
				11627.386, -- [10]
				11627.386, -- [11]
				11627.386, -- [12]
				11628.271, -- [13]
				11628.271, -- [14]
				11628.271, -- [15]
				11629.14, -- [16]
				11629.14, -- [17]
				11629.14, -- [18]
				11629.303, -- [19]
				11633.269, -- [20]
				11612.304, -- [21]
				11612.616, -- [22]
				11612.792, -- [23]
				11613.181, -- [24]
				11613.181, -- [25]
				11613.217, -- [26]
				11614.067, -- [27]
				11614.067, -- [28]
				11614.929, -- [29]
				11614.929, -- [30]
				11615.231, -- [31]
				11615.787, -- [32]
				11615.805, -- [33]
				11615.805, -- [34]
				11615.805, -- [35]
				11616.326, -- [36]
				11616.692, -- [37]
				11616.692, -- [38]
				11617.228, -- [39]
				11617.567, -- [40]
				11617.567, -- [41]
				11618.318, -- [42]
				11618.798, -- [43]
				11619.236, -- [44]
				11620.318, -- [45]
				11621.787, -- [46]
				11621.922, -- [47]
				11622.111, -- [48]
				11622.993, -- [49]
				11623.885, -- [50]
			},
			["LastEventIncoming"] = {
				false, -- [1]
				true, -- [2]
				false, -- [3]
				false, -- [4]
				true, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				true, -- [19]
				true, -- [20]
				false, -- [21]
				true, -- [22]
				true, -- [23]
				false, -- [24]
				false, -- [25]
				true, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				true, -- [31]
				true, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				true, -- [36]
				false, -- [37]
				false, -- [38]
				true, -- [39]
				false, -- [40]
				false, -- [41]
				true, -- [42]
				true, -- [43]
				true, -- [44]
				true, -- [45]
				true, -- [46]
				true, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["TimeLast"] = {
				["HealingTaken"] = 11624.248,
				["ActiveTime"] = 11628.253,
				["TimeDamage"] = 11628.253,
				["OVERALL"] = 11629.249,
				["Healing"] = 10798.551,
				["DamageTaken"] = 11629.249,
				["Damage"] = 11628.253,
			},
			["LastEventHealthMax"] = {
				19880, -- [1]
				19880, -- [2]
				19880, -- [3]
				19880, -- [4]
				19880, -- [5]
				19880, -- [6]
				19880, -- [7]
				19880, -- [8]
				19880, -- [9]
				19880, -- [10]
				19880, -- [11]
				19880, -- [12]
				19880, -- [13]
				19880, -- [14]
				19880, -- [15]
				19880, -- [16]
				19880, -- [17]
				19880, -- [18]
				19880, -- [19]
				19880, -- [20]
				19880, -- [21]
				19880, -- [22]
				19880, -- [23]
				19880, -- [24]
				19880, -- [25]
				19880, -- [26]
				19880, -- [27]
				19880, -- [28]
				19880, -- [29]
				19880, -- [30]
				19880, -- [31]
				19880, -- [32]
				19880, -- [33]
				19880, -- [34]
				19880, -- [35]
				19880, -- [36]
				19880, -- [37]
				19880, -- [38]
				19880, -- [39]
				19880, -- [40]
				19880, -- [41]
				19880, -- [42]
				19880, -- [43]
				19880, -- [44]
				19880, -- [45]
				19880, -- [46]
				19880, -- [47]
				19880, -- [48]
				19880, -- [49]
				19880, -- [50]
			},
			["LastActive"] = 11633.253,
		},
	},
	["FightNum"] = 6,
	["CombatTimes"] = {
		{
			10794.547, -- [1]
			10975.554, -- [2]
			"23:29:42", -- [3]
			"23:32:42", -- [4]
			"目标假人", -- [5]
		}, -- [1]
		{
			11024.545, -- [1]
			11044.55, -- [2]
			"23:33:31", -- [3]
			"23:33:51", -- [4]
			"联盟步兵", -- [5]
		}, -- [2]
		{
			11078.551, -- [1]
			11100.552, -- [2]
			"23:34:26", -- [3]
			"23:34:47", -- [4]
			"奥术构造体", -- [5]
		}, -- [3]
		{
			11112.547, -- [1]
			11145.549, -- [2]
			"23:35:00", -- [3]
			"23:35:32", -- [4]
			"联盟步兵", -- [5]
		}, -- [4]
		{
			11154.549, -- [1]
			11189.549, -- [2]
			"23:35:41", -- [3]
			"23:36:16", -- [4]
			"联盟步兵", -- [5]
		}, -- [5]
		{
			11495.244, -- [1]
			11631.248, -- [2]
			"23:41:23", -- [3]
			"23:43:38", -- [4]
			"双足飞龙骑手", -- [5]
		}, -- [6]
	},
	["FoughtWho"] = {
		"双足飞龙骑手 23:41:23-23:43:38", -- [1]
		"联盟步兵 23:35:41-23:36:16", -- [2]
		"联盟步兵 23:35:00-23:35:32", -- [3]
		"奥术构造体 23:34:26-23:34:47", -- [4]
		"联盟步兵 23:33:31-23:33:51", -- [5]
	},
}
