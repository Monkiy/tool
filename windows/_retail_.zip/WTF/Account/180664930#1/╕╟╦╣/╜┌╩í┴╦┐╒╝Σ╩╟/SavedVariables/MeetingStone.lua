
MEETINGSTONE_CHARACTER_DB = {
	["profileKeys"] = {
		["节省了空间是 - 盖斯"] = "节省了空间是 - 盖斯",
	},
	["profiles"] = {
		["节省了空间是 - 盖斯"] = {
			["version"] = "80100.01",
		},
	},
}
