
HHTD_SavedVariables = {
	["char"] = {
		["胖熊 - 远古海滩"] = {
			["settingsMigrated"] = false,
		},
		["灰衣人 - 远古海滩"] = {
			["settingsMigrated"] = false,
		},
		["跳跃的火苗 - 远古海滩"] = {
			["settingsMigrated"] = false,
		},
		["熊猫胖胖 - 远古海滩"] = {
			["settingsMigrated"] = false,
		},
		["咕噜胖 - 远古海滩"] = {
			["settingsMigrated"] = false,
		},
		["沉默的蜗牛 - 远古海滩"] = {
			["settingsMigrated"] = false,
		},
	},
	["namespaces"] = {
		["Announcer"] = {
		},
		["CM"] = {
		},
		["NPH"] = {
		},
	},
	["profileKeys"] = {
		["胖熊 - 远古海滩"] = "胖熊 - 远古海滩",
		["灰衣人 - 远古海滩"] = "灰衣人 - 远古海滩",
		["跳跃的火苗 - 远古海滩"] = "跳跃的火苗 - 远古海滩",
		["熊猫胖胖 - 远古海滩"] = "熊猫胖胖 - 远古海滩",
		["咕噜胖 - 远古海滩"] = "咕噜胖 - 远古海滩",
		["沉默的蜗牛 - 远古海滩"] = "沉默的蜗牛 - 远古海滩",
	},
	["global"] = {
		["settingsMigrated"] = false,
		["oldNameEnableState"] = 0,
	},
}
