﻿
RecountDB = {
	["profileKeys"] = {
		["跳跃的火苗 - 远古海滩"] = "跳跃的火苗 - 远古海滩",
	},
	["profiles"] = {
		["跳跃的火苗 - 远古海滩"] = {
			["MainWindow"] = {
				["Position"] = {
					["y"] = -440,
					["x"] = 745,
					["w"] = 275,
					["h"] = 200,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["Locked"] = true,
			["CurDataSet"] = "OverallData",
			["MainWindowWidth"] = 275,
			["MainWindowHeight"] = 200,
		},
	},
}
