
RecountDB = {
	["profileKeys"] = {
		["咕噜胖 - 远古海滩"] = "咕噜胖 - 远古海滩",
		["跳跃的火苗 - 远古海滩"] = "跳跃的火苗 - 远古海滩",
	},
	["profiles"] = {
		["咕噜胖 - 远古海滩"] = {
			["MainWindow"] = {
				["Position"] = {
					["h"] = 199.999984741211,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["CurDataSet"] = "OverallData",
		},
		["跳跃的火苗 - 远古海滩"] = {
			["MainWindow"] = {
				["Position"] = {
					["y"] = -439.999984741211,
					["x"] = 745.000122070313,
					["w"] = 274.999938964844,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["MainWindowHeight"] = 200,
			["CurDataSet"] = "OverallData",
			["MainWindowWidth"] = 275,
			["Locked"] = true,
		},
	},
}
