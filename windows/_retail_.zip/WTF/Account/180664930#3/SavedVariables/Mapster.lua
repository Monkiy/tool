
MapsterDB = {
	["namespaces"] = {
		["GroupIcons"] = {
		},
		["Coords"] = {
		},
		["FogClear"] = {
			["profiles"] = {
				["Default"] = {
					["version"] = 2,
				},
			},
		},
		["BattleMap"] = {
		},
	},
	["profileKeys"] = {
		["胖熊 - 远古海滩"] = "Default",
		["灰衣人 - 远古海滩"] = "Default",
		["跳跃的火苗 - 远古海滩"] = "Default",
		["熊猫胖胖 - 远古海滩"] = "Default",
		["咕噜胖 - 远古海滩"] = "Default",
		["沉默的蜗牛 - 远古海滩"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
