
RecountPerCharDB = {
	["version"] = "1.3",
	["combatants"] = {
		["跳跃的火苗"] = {
			["GUID"] = "Player-2135-02B3B0EF",
			["TimeLast"] = {
				["TimeHeal"] = 434290.276,
				["OVERALL"] = 434290.276,
				["DamageTaken"] = 434288.257,
				["RageGain"] = 434288.257,
				["Overhealing"] = 434290.276,
				["TimeDamage"] = 434290.276,
				["HealingTaken"] = 434290.276,
				["ActiveTime"] = 434290.276,
				["Healing"] = 434290.276,
				["Damage"] = 434290.276,
			},
			["LastAttackedBy"] = "癞皮狼",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"HEAL", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"HEAL", -- [33]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					3, -- [1]
				},
				["Healing"] = {
					70, -- [1]
				},
				["DamageTaken"] = {
					205, -- [1]
				},
				["HealingTaken"] = {
					70, -- [1]
				},
				["Overhealing"] = {
					17, -- [1]
				},
				["TimeDamage"] = {
					16.49, -- [1]
				},
				["RageGain"] = {
					135, -- [1]
				},
				["ActiveTime"] = {
					19.49, -- [1]
				},
				["Damage"] = {
					2723, -- [1]
				},
			},
			["enClass"] = "WARRIOR",
			["unit"] = "跳跃的火苗",
			["LastAbility"] = 434259.754,
			["level"] = 20,
			["LastDamageAbility"] = "肉搏",
			["LastFightIn"] = 10,
			["UnitLockout"] = 83033.123,
			["type"] = "Self",
			["FightsSaved"] = 2,
			["LastDamageTaken"] = 27,
			["Fights"] = {
				["Fight2"] = {
					["TimeHealing"] = {
						["跳跃的火苗"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["TimeSpent"] = {
						["鹿"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["跳跃的火苗"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["森林蜘蛛"] = {
							["Details"] = {
								["盾牌猛击"] = {
									["count"] = 1.42,
								},
								["冲锋"] = {
									["count"] = 1.5,
								},
								["肉搏"] = {
									["count"] = 1.74,
								},
								["毁灭打击"] = {
									["count"] = 4.11,
								},
							},
							["amount"] = 8.77,
						},
					},
					["DamageTaken"] = 162,
					["RageGainedFrom"] = {
						["跳跃的火苗"] = {
							["Details"] = {
								["盾牌猛击"] = {
									["count"] = 20,
								},
								["怒气"] = {
									["count"] = 0,
								},
								["雷霆一击"] = {
									["count"] = 10,
								},
								["冲锋"] = {
									["count"] = 20,
								},
							},
							["amount"] = 50,
						},
					},
					["PartialResist"] = {
						["中毒 (伤害/跳)"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 4,
						},
					},
					["PartialAbsorb"] = {
						["中毒 (伤害/跳)"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 10.27,
					["ElementTaken"] = {
						["Melee"] = 151,
						["Nature"] = 11,
					},
					["RageGained"] = {
						["盾牌猛击"] = {
							["Details"] = {
								["跳跃的火苗"] = {
									["count"] = 20,
								},
							},
							["amount"] = 20,
						},
						["怒气"] = {
							["Details"] = {
								["跳跃的火苗"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["雷霆一击"] = {
							["Details"] = {
								["跳跃的火苗"] = {
									["count"] = 10,
								},
							},
							["amount"] = 10,
						},
						["冲锋"] = {
							["Details"] = {
								["跳跃的火苗"] = {
									["count"] = 20,
								},
							},
							["amount"] = 20,
						},
					},
					["Damage"] = 1466,
					["TimeHeal"] = 1.5,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 7,
						},
					},
					["ElementDone"] = {
						["Melee"] = 177,
						["Physical"] = 1289,
					},
					["WhoDamaged"] = {
						["森林蜘蛛"] = {
							["Details"] = {
								["中毒 (伤害/跳)"] = {
									["count"] = 11,
								},
								["肉搏"] = {
									["count"] = 151,
								},
							},
							["amount"] = 162,
						},
					},
					["Healing"] = 43,
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["RageGain"] = 50,
					["Attacks"] = {
						["冲锋"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 43,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 43,
								},
							},
							["count"] = 1,
							["amount"] = 43,
						},
						["盾牌猛击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 301,
									["min"] = 301,
									["count"] = 1,
									["amount"] = 301,
								},
							},
							["count"] = 1,
							["amount"] = 301,
						},
						["肉搏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 61,
									["min"] = 55,
									["count"] = 3,
									["amount"] = 177,
								},
							},
							["count"] = 3,
							["amount"] = 177,
						},
						["雷霆一击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 184,
									["min"] = 184,
									["count"] = 1,
									["amount"] = 184,
								},
							},
							["count"] = 1,
							["amount"] = 184,
						},
						["毁灭打击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 320,
									["min"] = 320,
									["count"] = 1,
									["amount"] = 320,
								},
								["Hit"] = {
									["max"] = 153,
									["min"] = 141,
									["count"] = 3,
									["amount"] = 441,
								},
							},
							["count"] = 4,
							["amount"] = 761,
						},
					},
					["HealingTaken"] = 43,
					["DamagedWho"] = {
						["鹿"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["森林蜘蛛"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 43,
								},
								["盾牌猛击"] = {
									["count"] = 301,
								},
								["肉搏"] = {
									["count"] = 177,
								},
								["雷霆一击"] = {
									["count"] = 184,
								},
								["毁灭打击"] = {
									["count"] = 761,
								},
							},
							["amount"] = 1466,
						},
					},
					["TimeDamage"] = 8.77,
					["TimeDamaging"] = {
						["鹿"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["森林蜘蛛"] = {
							["Details"] = {
								["盾牌猛击"] = {
									["count"] = 1.42,
								},
								["冲锋"] = {
									["count"] = 1.5,
								},
								["肉搏"] = {
									["count"] = 1.74,
								},
								["毁灭打击"] = {
									["count"] = 4.11,
								},
							},
							["amount"] = 8.77,
						},
					},
					["Heals"] = {
						["迅捷的正义之手"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 43,
									["min"] = 43,
									["count"] = 1,
									["amount"] = 43,
								},
							},
							["count"] = 1,
							["amount"] = 43,
						},
					},
					["HealedWho"] = {
						["跳跃的火苗"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 43,
								},
							},
							["amount"] = 43,
						},
					},
					["WhoHealed"] = {
						["跳跃的火苗"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 43,
								},
							},
							["amount"] = 43,
						},
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 27,
					["RageGainedFrom"] = {
						["跳跃的火苗"] = {
							["Details"] = {
								["盾牌猛击"] = {
									["count"] = 20,
								},
								["怒气"] = {
									["count"] = 0,
								},
								["冲锋"] = {
									["count"] = 20,
								},
								["雷霆一击"] = {
									["count"] = 10,
								},
							},
							["amount"] = 50,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
								["Parry"] = {
									["count"] = 1,
								},
								["Dodge"] = {
									["count"] = 1,
								},
							},
							["amount"] = 3,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
						["Melee"] = 27,
						["Nature"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 1192,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 1.5,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
						["中毒 (伤害/跳)"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
					},
					["RageGain"] = 50,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Melee"] = 175,
						["Physical"] = 1017,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 5,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
						["癞皮狼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 27,
								},
							},
							["amount"] = 27,
						},
						["森林蜘蛛"] = {
							["Details"] = {
								["中毒 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["跳跃的火苗"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["OverHeals"] = {
						["迅捷的正义之手"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 17,
									["min"] = 17,
									["count"] = 1,
									["amount"] = 17,
								},
							},
							["count"] = 1,
							["amount"] = 17,
						},
					},
					["RageGained"] = {
						["盾牌猛击"] = {
							["Details"] = {
								["跳跃的火苗"] = {
									["count"] = 20,
								},
							},
							["amount"] = 20,
						},
						["怒气"] = {
							["Details"] = {
								["跳跃的火苗"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["冲锋"] = {
							["Details"] = {
								["跳跃的火苗"] = {
									["count"] = 20,
								},
							},
							["amount"] = 20,
						},
						["雷霆一击"] = {
							["Details"] = {
								["跳跃的火苗"] = {
									["count"] = 10,
								},
							},
							["amount"] = 10,
						},
					},
					["ActiveTime"] = 7.72,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
						["跳跃的火苗"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 27,
								},
							},
							["amount"] = 27,
						},
					},
					["PartialResist"] = {
						["中毒 (伤害/跳)"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 3,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 17,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["跳跃的火苗"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["癞皮狼"] = {
							["Details"] = {
								["雷霆一击"] = {
									["count"] = 0.69,
								},
								["毁灭打击"] = {
									["count"] = 2.98,
								},
								["肉搏"] = {
									["count"] = 1.05,
								},
								["冲锋"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 6.22,
						},
					},
					["Heals"] = {
						["迅捷的正义之手"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 27,
									["min"] = 27,
									["count"] = 1,
									["amount"] = 27,
								},
							},
							["count"] = 1,
							["amount"] = 27,
						},
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
						["跳跃的火苗"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 27,
								},
							},
							["amount"] = 27,
						},
					},
					["Healing"] = 27,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["冲锋"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 44,
									["min"] = 44,
									["count"] = 1,
									["amount"] = 44,
								},
							},
							["count"] = 1,
							["amount"] = 44,
						},
						["盾牌猛击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 297,
									["min"] = 297,
									["count"] = 1,
									["amount"] = 297,
								},
							},
							["count"] = 1,
							["amount"] = 297,
						},
						["雷霆一击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 368,
									["min"] = 368,
									["count"] = 1,
									["amount"] = 368,
								},
							},
							["count"] = 1,
							["amount"] = 368,
						},
						["毁灭打击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 154,
									["min"] = 154,
									["count"] = 2,
									["amount"] = 308,
								},
							},
							["count"] = 2,
							["amount"] = 308,
						},
						["肉搏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 60,
									["min"] = 55,
									["count"] = 3,
									["amount"] = 175,
								},
							},
							["count"] = 3,
							["amount"] = 175,
						},
					},
					["HealingTaken"] = 27,
					["DamagedWho"] = {
						["癞皮狼"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 44,
								},
								["盾牌猛击"] = {
									["count"] = 297,
								},
								["雷霆一击"] = {
									["count"] = 368,
								},
								["毁灭打击"] = {
									["count"] = 308,
								},
								["肉搏"] = {
									["count"] = 175,
								},
							},
							["amount"] = 1192,
						},
					},
					["TimeDamage"] = 6.22,
					["TimeDamaging"] = {
						["癞皮狼"] = {
							["Details"] = {
								["雷霆一击"] = {
									["count"] = 0.69,
								},
								["毁灭打击"] = {
									["count"] = 2.98,
								},
								["肉搏"] = {
									["count"] = 1.05,
								},
								["冲锋"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 6.22,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["TimeHealing"] = {
						["跳跃的火苗"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["OverHeals"] = {
						["迅捷的正义之手"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 17,
									["min"] = 17,
									["count"] = 1,
									["amount"] = 17,
								},
							},
							["count"] = 1,
							["amount"] = 17,
						},
					},
					["TimeSpent"] = {
						["鹿"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["癞皮狼"] = {
							["Details"] = {
								["雷霆一击"] = {
									["count"] = 0.69,
								},
								["毁灭打击"] = {
									["count"] = 2.98,
								},
								["肉搏"] = {
									["count"] = 1.05,
								},
								["冲锋"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 6.22,
						},
						["跳跃的火苗"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["森林蜘蛛"] = {
							["Details"] = {
								["盾牌猛击"] = {
									["count"] = 1.42,
								},
								["冲锋"] = {
									["count"] = 1.5,
								},
								["肉搏"] = {
									["count"] = 1.74,
								},
								["毁灭打击"] = {
									["count"] = 4.11,
								},
							},
							["amount"] = 8.77,
						},
					},
					["DamageTaken"] = 205,
					["RageGainedFrom"] = {
						["跳跃的火苗"] = {
							["Details"] = {
								["盾牌猛击"] = {
									["count"] = 40,
								},
								["怒气"] = {
									["count"] = 0,
								},
								["雷霆一击"] = {
									["count"] = 35,
								},
								["冲锋"] = {
									["count"] = 60,
								},
							},
							["amount"] = 135,
						},
					},
					["PartialResist"] = {
						["中毒 (伤害/跳)"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 5,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 7,
						},
					},
					["PartialAbsorb"] = {
						["中毒 (伤害/跳)"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 19.49,
					["ElementTaken"] = {
						["Melee"] = 178,
						["Nature"] = 27,
					},
					["RageGained"] = {
						["盾牌猛击"] = {
							["Details"] = {
								["跳跃的火苗"] = {
									["count"] = 40,
								},
							},
							["amount"] = 40,
						},
						["怒气"] = {
							["Details"] = {
								["跳跃的火苗"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["雷霆一击"] = {
							["Details"] = {
								["跳跃的火苗"] = {
									["count"] = 35,
								},
							},
							["amount"] = 35,
						},
						["冲锋"] = {
							["Details"] = {
								["跳跃的火苗"] = {
									["count"] = 60,
								},
							},
							["amount"] = 60,
						},
					},
					["Damage"] = 2723,
					["Overhealing"] = 17,
					["TimeHeal"] = 3,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 11,
								},
							},
							["amount"] = 13,
						},
					},
					["ElementDone"] = {
						["Melee"] = 352,
						["Physical"] = 2371,
					},
					["WhoDamaged"] = {
						["癞皮狼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 27,
								},
							},
							["amount"] = 27,
						},
						["森林蜘蛛"] = {
							["Details"] = {
								["中毒 (伤害/跳)"] = {
									["count"] = 27,
								},
								["肉搏"] = {
									["count"] = 151,
								},
							},
							["amount"] = 178,
						},
					},
					["Healing"] = 70,
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 1,
								},
								["Dodge"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 7,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 5,
								},
							},
							["amount"] = 5,
						},
					},
					["RageGain"] = 135,
					["Attacks"] = {
						["冲锋"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 65,
									["min"] = 43,
									["count"] = 3,
									["amount"] = 152,
								},
							},
							["count"] = 3,
							["amount"] = 152,
						},
						["盾牌猛击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 301,
									["min"] = 297,
									["count"] = 2,
									["amount"] = 598,
								},
							},
							["count"] = 2,
							["amount"] = 598,
						},
						["肉搏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 61,
									["min"] = 55,
									["count"] = 6,
									["amount"] = 352,
								},
							},
							["count"] = 6,
							["amount"] = 352,
						},
						["雷霆一击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 368,
									["min"] = 368,
									["count"] = 1,
									["amount"] = 368,
								},
								["Hit"] = {
									["max"] = 184,
									["min"] = 184,
									["count"] = 1,
									["amount"] = 184,
								},
							},
							["count"] = 2,
							["amount"] = 552,
						},
						["毁灭打击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 320,
									["min"] = 320,
									["count"] = 1,
									["amount"] = 320,
								},
								["Hit"] = {
									["max"] = 154,
									["min"] = 141,
									["count"] = 5,
									["amount"] = 749,
								},
							},
							["count"] = 6,
							["amount"] = 1069,
						},
					},
					["HealingTaken"] = 70,
					["DamagedWho"] = {
						["鹿"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 65,
								},
							},
							["amount"] = 65,
						},
						["癞皮狼"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 44,
								},
								["盾牌猛击"] = {
									["count"] = 297,
								},
								["雷霆一击"] = {
									["count"] = 368,
								},
								["毁灭打击"] = {
									["count"] = 308,
								},
								["肉搏"] = {
									["count"] = 175,
								},
							},
							["amount"] = 1192,
						},
						["森林蜘蛛"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 43,
								},
								["盾牌猛击"] = {
									["count"] = 301,
								},
								["肉搏"] = {
									["count"] = 177,
								},
								["雷霆一击"] = {
									["count"] = 184,
								},
								["毁灭打击"] = {
									["count"] = 761,
								},
							},
							["amount"] = 1466,
						},
					},
					["TimeDamage"] = 16.49,
					["TimeDamaging"] = {
						["鹿"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["癞皮狼"] = {
							["Details"] = {
								["雷霆一击"] = {
									["count"] = 0.69,
								},
								["毁灭打击"] = {
									["count"] = 2.98,
								},
								["肉搏"] = {
									["count"] = 1.05,
								},
								["冲锋"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 6.22,
						},
						["森林蜘蛛"] = {
							["Details"] = {
								["盾牌猛击"] = {
									["count"] = 1.42,
								},
								["冲锋"] = {
									["count"] = 1.5,
								},
								["肉搏"] = {
									["count"] = 1.74,
								},
								["毁灭打击"] = {
									["count"] = 4.11,
								},
							},
							["amount"] = 8.77,
						},
					},
					["Heals"] = {
						["迅捷的正义之手"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 43,
									["min"] = 27,
									["count"] = 2,
									["amount"] = 70,
								},
							},
							["count"] = 2,
							["amount"] = 70,
						},
					},
					["HealedWho"] = {
						["跳跃的火苗"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 70,
								},
							},
							["amount"] = 70,
						},
					},
					["WhoHealed"] = {
						["跳跃的火苗"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 70,
								},
							},
							["amount"] = 70,
						},
					},
				},
				["Fight1"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 27,
					["RageGainedFrom"] = {
						["跳跃的火苗"] = {
							["Details"] = {
								["盾牌猛击"] = {
									["count"] = 20,
								},
								["怒气"] = {
									["count"] = 0,
								},
								["冲锋"] = {
									["count"] = 20,
								},
								["雷霆一击"] = {
									["count"] = 10,
								},
							},
							["amount"] = 50,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
								["Parry"] = {
									["count"] = 1,
								},
								["Dodge"] = {
									["count"] = 1,
								},
							},
							["amount"] = 3,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
						["Melee"] = 27,
						["Nature"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 1192,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 1.5,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
						["中毒 (伤害/跳)"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
					},
					["RageGain"] = 50,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Melee"] = 175,
						["Physical"] = 1017,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 5,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
						["癞皮狼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 27,
								},
							},
							["amount"] = 27,
						},
						["森林蜘蛛"] = {
							["Details"] = {
								["中毒 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["跳跃的火苗"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["OverHeals"] = {
						["迅捷的正义之手"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 17,
									["min"] = 17,
									["count"] = 1,
									["amount"] = 17,
								},
							},
							["count"] = 1,
							["amount"] = 17,
						},
					},
					["RageGained"] = {
						["盾牌猛击"] = {
							["Details"] = {
								["跳跃的火苗"] = {
									["count"] = 20,
								},
							},
							["amount"] = 20,
						},
						["怒气"] = {
							["Details"] = {
								["跳跃的火苗"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["冲锋"] = {
							["Details"] = {
								["跳跃的火苗"] = {
									["count"] = 20,
								},
							},
							["amount"] = 20,
						},
						["雷霆一击"] = {
							["Details"] = {
								["跳跃的火苗"] = {
									["count"] = 10,
								},
							},
							["amount"] = 10,
						},
					},
					["ActiveTime"] = 7.72,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
						["跳跃的火苗"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 27,
								},
							},
							["amount"] = 27,
						},
					},
					["PartialResist"] = {
						["中毒 (伤害/跳)"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 3,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 17,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["跳跃的火苗"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["癞皮狼"] = {
							["Details"] = {
								["雷霆一击"] = {
									["count"] = 0.69,
								},
								["毁灭打击"] = {
									["count"] = 2.98,
								},
								["肉搏"] = {
									["count"] = 1.05,
								},
								["冲锋"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 6.22,
						},
					},
					["Heals"] = {
						["迅捷的正义之手"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 27,
									["min"] = 27,
									["count"] = 1,
									["amount"] = 27,
								},
							},
							["count"] = 1,
							["amount"] = 27,
						},
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
						["跳跃的火苗"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 27,
								},
							},
							["amount"] = 27,
						},
					},
					["Healing"] = 27,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["冲锋"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 44,
									["min"] = 44,
									["count"] = 1,
									["amount"] = 44,
								},
							},
							["count"] = 1,
							["amount"] = 44,
						},
						["盾牌猛击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 297,
									["min"] = 297,
									["count"] = 1,
									["amount"] = 297,
								},
							},
							["count"] = 1,
							["amount"] = 297,
						},
						["雷霆一击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 368,
									["min"] = 368,
									["count"] = 1,
									["amount"] = 368,
								},
							},
							["count"] = 1,
							["amount"] = 368,
						},
						["毁灭打击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 154,
									["min"] = 154,
									["count"] = 2,
									["amount"] = 308,
								},
							},
							["count"] = 2,
							["amount"] = 308,
						},
						["肉搏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 60,
									["min"] = 55,
									["count"] = 3,
									["amount"] = 175,
								},
							},
							["count"] = 3,
							["amount"] = 175,
						},
					},
					["HealingTaken"] = 27,
					["DamagedWho"] = {
						["癞皮狼"] = {
							["Details"] = {
								["冲锋"] = {
									["count"] = 44,
								},
								["盾牌猛击"] = {
									["count"] = 297,
								},
								["雷霆一击"] = {
									["count"] = 368,
								},
								["毁灭打击"] = {
									["count"] = 308,
								},
								["肉搏"] = {
									["count"] = 175,
								},
							},
							["amount"] = 1192,
						},
					},
					["TimeDamage"] = 6.22,
					["TimeDamaging"] = {
						["癞皮狼"] = {
							["Details"] = {
								["雷霆一击"] = {
									["count"] = 0.69,
								},
								["毁灭打击"] = {
									["count"] = 2.98,
								},
								["肉搏"] = {
									["count"] = 1.05,
								},
								["冲锋"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 6.22,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
			},
			["Owner"] = false,
			["LastEventTimes"] = {
				83033.603, -- [1]
				83043.938, -- [2]
				83043.938, -- [3]
				83044.071, -- [4]
				83044.071, -- [5]
				83045.494, -- [6]
				83045.943, -- [7]
				83046.495, -- [8]
				83046.928, -- [9]
				83047.938, -- [10]
				83048.321, -- [11]
				83048.928, -- [12]
				83048.928, -- [13]
				83049.779, -- [14]
				83049.951, -- [15]
				83051.222, -- [16]
				83051.222, -- [17]
				83051.983, -- [18]
				83054.98, -- [19]
				83058.002, -- [20]
				83060.985, -- [21]
				434285.745, -- [22]
				434285.872, -- [23]
				434285.872, -- [24]
				434285.872, -- [25]
				434287.357, -- [26]
				434287.533, -- [27]
				434288.062, -- [28]
				434288.756, -- [29]
				434289.178, -- [30]
				434290.299, -- [31]
				434290.507, -- [32]
				434290.507, -- [33]
			},
			["NextEventNum"] = 34,
			["LastDamageTime"] = 434290.507,
			["LastEvents"] = {
				"跳跃的火苗 冲锋 鹿 Hit -65 (Physical)", -- [1]
				"森林蜘蛛 肉搏 跳跃的火苗 Hit -36 (Physical)", -- [2]
				"跳跃的火苗 冲锋 森林蜘蛛 Hit -43 (Physical)", -- [3]
				"跳跃的火苗 肉搏 森林蜘蛛 Hit -61 (Physical)", -- [4]
				"跳跃的火苗 雷霆一击 森林蜘蛛 Hit -184 (Physical)", -- [5]
				"跳跃的火苗 盾牌猛击 森林蜘蛛 Hit -301 (Physical)", -- [6]
				"森林蜘蛛 肉搏 跳跃的火苗 Hit -37 (Physical)", -- [7]
				"跳跃的火苗 肉搏 森林蜘蛛 Hit -61 (Physical)", -- [8]
				"跳跃的火苗 毁灭打击 森林蜘蛛 Hit -147 (Physical)", -- [9]
				"森林蜘蛛 肉搏 跳跃的火苗 Hit -44 (Physical)", -- [10]
				"跳跃的火苗 毁灭打击 森林蜘蛛 Hit -141 (Physical)", -- [11]
				"跳跃的火苗 肉搏 森林蜘蛛 Hit -55 (Physical)", -- [12]
				"森林蜘蛛 中毒 (伤害/跳) 跳跃的火苗 Tick -6 (Nature)", -- [13]
				"跳跃的火苗 毁灭打击 森林蜘蛛 Hit -153 (Physical)", -- [14]
				"森林蜘蛛 肉搏 跳跃的火苗 Hit -34 (Physical)", -- [15]
				"跳跃的火苗 毁灭打击 森林蜘蛛 Crit -320 (Physical)", -- [16]
				"跳跃的火苗 迅捷的正义之手 跳跃的火苗 Hit +43", -- [17]
				"森林蜘蛛 中毒 (伤害/跳) 跳跃的火苗 Tick -5 (Nature)", -- [18]
				"森林蜘蛛 中毒 (伤害/跳) 跳跃的火苗 Tick -5 (Nature)", -- [19]
				"森林蜘蛛 中毒 (伤害/跳) 跳跃的火苗 Tick -6 (Nature)", -- [20]
				"森林蜘蛛 中毒 (伤害/跳) 跳跃的火苗 Tick -5 (Nature)", -- [21]
				"跳跃的火苗 冲锋 癞皮狼 Hit -44 (Physical)", -- [22]
				"跳跃的火苗 肉搏 癞皮狼 Hit -55 (Physical)", -- [23]
				"癞皮狼 肉搏 跳跃的火苗 Dodge (1)", -- [24]
				"跳跃的火苗 盾牌猛击 癞皮狼 Hit -297 (Physical)", -- [25]
				"跳跃的火苗 毁灭打击 癞皮狼 Hit -154 (Physical)", -- [26]
				"癞皮狼 肉搏 跳跃的火苗 Parry (1)", -- [27]
				"跳跃的火苗 肉搏 癞皮狼 Hit -60 (Physical)", -- [28]
				"跳跃的火苗 雷霆一击 癞皮狼 Crit -368 (Physical)", -- [29]
				"癞皮狼 肉搏 跳跃的火苗 Hit -27 (Physical)", -- [30]
				"跳跃的火苗 毁灭打击 癞皮狼 Hit -154 (Physical)", -- [31]
				"跳跃的火苗 肉搏 癞皮狼 Hit -60 (Physical)", -- [32]
				"跳跃的火苗 迅捷的正义之手 跳跃的火苗 Hit +44 (17 过量治疗)", -- [33]
			},
			["LastEventIncoming"] = {
				false, -- [1]
				true, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				true, -- [7]
				false, -- [8]
				false, -- [9]
				true, -- [10]
				false, -- [11]
				false, -- [12]
				true, -- [13]
				false, -- [14]
				true, -- [15]
				false, -- [16]
				true, -- [17]
				true, -- [18]
				true, -- [19]
				true, -- [20]
				true, -- [21]
				false, -- [22]
				false, -- [23]
				true, -- [24]
				false, -- [25]
				false, -- [26]
				true, -- [27]
				false, -- [28]
				false, -- [29]
				true, -- [30]
				false, -- [31]
				false, -- [32]
				true, -- [33]
			},
			["Name"] = "跳跃的火苗",
			["LastHealTime"] = 434290.507,
			["LastEventHealth"] = {
				2109, -- [1]
				2109, -- [2]
				2073, -- [3]
				2073, -- [4]
				2073, -- [5]
				2073, -- [6]
				2073, -- [7]
				2036, -- [8]
				2036, -- [9]
				2036, -- [10]
				1992, -- [11]
				1992, -- [12]
				1986, -- [13]
				1986, -- [14]
				1986, -- [15]
				1952, -- [16]
				1995, -- [17]
				1990, -- [18]
				2006, -- [19]
				2042, -- [20]
				2059, -- [21]
				2109, -- [22]
				2109, -- [23]
				2109, -- [24]
				2109, -- [25]
				2109, -- [26]
				2109, -- [27]
				2109, -- [28]
				2109, -- [29]
				2109, -- [30]
				2082, -- [31]
				2082, -- [32]
				2109, -- [33]
			},
			["LastEventHealthMax"] = {
				2109, -- [1]
				2109, -- [2]
				2109, -- [3]
				2109, -- [4]
				2109, -- [5]
				2109, -- [6]
				2109, -- [7]
				2109, -- [8]
				2109, -- [9]
				2109, -- [10]
				2109, -- [11]
				2109, -- [12]
				2109, -- [13]
				2109, -- [14]
				2109, -- [15]
				2109, -- [16]
				2109, -- [17]
				2109, -- [18]
				2109, -- [19]
				2109, -- [20]
				2109, -- [21]
				2109, -- [22]
				2109, -- [23]
				2109, -- [24]
				2109, -- [25]
				2109, -- [26]
				2109, -- [27]
				2109, -- [28]
				2109, -- [29]
				2109, -- [30]
				2109, -- [31]
				2109, -- [32]
				2109, -- [33]
			},
			["LastActive"] = 434290.276,
		},
		["守望者新兵 <灰衣人>"] = {
			["GUID"] = "Creature-0-3908-1220-5377-119138-0000137EA2",
			["TimeLast"] = {
				["Overhealing"] = 12638.301,
				["ActiveTime"] = 12638.301,
				["OVERALL"] = 12638.301,
				["TimeDamage"] = 12638.301,
				["Damage"] = 12638.301,
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"HEAL", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"HEAL", -- [8]
				"DAMAGE", -- [9]
				"HEAL", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"HEAL", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"HEAL", -- [18]
				"DAMAGE", -- [19]
				"HEAL", -- [20]
			},
			["TimeWindows"] = {
				["ActiveTime"] = {
					15.02, -- [1]
				},
				["Damage"] = {
					1234648, -- [1]
				},
				["Overhealing"] = {
					23552, -- [1]
				},
				["TimeDamage"] = {
					15.02, -- [1]
				},
			},
			["enClass"] = "PET",
			["level"] = 1,
			["LastFightIn"] = 2,
			["type"] = "Pet",
			["FightsSaved"] = 5,
			["ownerName"] = "灰衣人",
			["LastAbility"] = 434259.754,
			["NextEventNum"] = 21,
			["LastDamageTime"] = 12639.136,
			["LastEvents"] = {
				"守望者新兵 <灰衣人> 肉搏 黑石蜥蜴 Hit -131349 (Physical)", -- [1]
				"守望者新兵 <灰衣人> 肉搏 黑石蜥蜴 Hit -52565 (Physical)", -- [2]
				"守望者新兵 <灰衣人> 肉搏 黑石蜥蜴 Hit -123428 (Physical)", -- [3]
				"守望者新兵 <灰衣人> 肉搏 黑石蜥蜴 Hit -69534 (Physical)", -- [4]
				"守望者新兵 <灰衣人> 吸血 守望者新兵 <灰衣人> Hit +11984 (11984 过量治疗)", -- [5]
				"守望者新兵 <灰衣人> 肉搏 黑石蜥蜴 Hit -138381 (Physical)", -- [6]
				"守望者新兵 <灰衣人> 肉搏 黑石蜥蜴 Hit -55578 (Physical)", -- [7]
				"守望者新兵 <灰衣人> 吸血 守望者新兵 <灰衣人> Hit +6167 (6167 过量治疗)", -- [8]
				"守望者新兵 <灰衣人> 肉搏 黑石蜥蜴 Hit -100367 (Physical)", -- [9]
				"守望者新兵 <灰衣人> 吸血 守望者新兵 <灰衣人> Hit +3192 (3192 过量治疗)", -- [10]
				"守望者新兵 <灰衣人> 肉搏 黑石蜥蜴 Crit -125557 (Physical)", -- [11]
				"守望者新兵 <灰衣人> 肉搏 黑石蜥蜴 Hit -94678 (Physical)", -- [12]
				"守望者新兵 <灰衣人> 肉搏 黑石蜥蜴 Hit -35338 (Physical)", -- [13]
				"守望者新兵 <灰衣人> 吸血 守望者新兵 <灰衣人> Hit +8127 (8127 过量治疗)", -- [14]
				"守望者新兵 <灰衣人> 肉搏 黑石蜥蜴 Hit -97630 (Physical)", -- [15]
				"守望者新兵 <灰衣人> 肉搏 黑石蜥蜴 Hit -48438 (Physical)", -- [16]
				"守望者新兵 <灰衣人> 肉搏 黑石蜥蜴 Hit -117344 (Physical)", -- [17]
				"守望者新兵 <灰衣人> 吸血 守望者新兵 <灰衣人> Hit +8376 (8376 过量治疗)", -- [18]
				"守望者新兵 <灰衣人> 肉搏 黑石蜥蜴 Hit -44461 (Physical)", -- [19]
				"守望者新兵 <灰衣人> 吸血 守望者新兵 <灰衣人> Hit +1414 (1414 过量治疗)", -- [20]
			},
			["Name"] = "守望者新兵",
			["UnitLockout"] = 12643.321,
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				true, -- [5]
				false, -- [6]
				false, -- [7]
				true, -- [8]
				false, -- [9]
				true, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				true, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				true, -- [18]
				false, -- [19]
				true, -- [20]
			},
			["Fights"] = {
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["ElementDoneBlock"] = {
						["Melee"] = 15145,
					},
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 11984,
									["min"] = 3192,
									["count"] = 3,
									["amount"] = 23552,
								},
							},
							["count"] = 3,
							["amount"] = 23552,
						},
					},
					["TimeSpent"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 15.02,
								},
							},
							["amount"] = 15.02,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Block"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 13,
								},
							},
							["amount"] = 15,
						},
					},
					["ElementDone"] = {
						["Melee"] = 1234648,
					},
					["ActiveTime"] = 15.02,
					["Overhealing"] = 23552,
					["TimeDamage"] = 15.02,
					["TimeDamaging"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 15.02,
								},
							},
							["amount"] = 15.02,
						},
					},
					["Attacks"] = {
						["肉搏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 138381,
									["min"] = 44461,
									["count"] = 12,
									["amount"] = 1073753,
								},
								["Crit"] = {
									["max"] = 125557,
									["min"] = 125557,
									["count"] = 1,
									["amount"] = 125557,
								},
								["Hit (被格挡)"] = {
									["max"] = 35338,
									["min"] = 35338,
									["count"] = 1,
									["amount"] = 35338,
								},
							},
							["count"] = 14,
							["amount"] = 1234648,
						},
					},
					["DamagedWho"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 1234648,
								},
							},
							["amount"] = 1234648,
						},
					},
					["Damage"] = 1234648,
				},
			},
			["LastEventTimes"] = {
				12603.668, -- [1]
				12604.197, -- [2]
				12605.73, -- [3]
				12606.206, -- [4]
				12606.828, -- [5]
				12608.15, -- [6]
				12608.656, -- [7]
				12612.559, -- [8]
				12627.111, -- [9]
				12627.94, -- [10]
				12628.141, -- [11]
				12629.11, -- [12]
				12630.14, -- [13]
				12633.187, -- [14]
				12636.172, -- [15]
				12637.228, -- [16]
				12638.167, -- [17]
				12638.641, -- [18]
				12639.136, -- [19]
				12643.903, -- [20]
			},
			["LastActive"] = 12643.321,
		},
		["肉弹 <灰衣人>"] = {
			["GUID"] = "Creature-0-3905-1220-30100-116355-0000137E99",
			["TimeLast"] = {
				["TimeHeal"] = 12926.297,
				["OVERALL"] = 12952.298,
				["DamageTaken"] = 12922.308,
				["HealingTaken"] = 12926.297,
				["Overhealing"] = 12952.298,
				["TimeDamage"] = 12950.292,
				["Healing"] = 12926.297,
				["ActiveTime"] = 12950.292,
				["Damage"] = 12950.292,
			},
			["LastAttackedBy"] = "暮色骑士希莱林",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"HEAL", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"HEAL", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"HEAL", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"HEAL", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"HEAL", -- [25]
				"DAMAGE", -- [26]
				"HEAL", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"HEAL", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"HEAL", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"HEAL", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"HEAL", -- [42]
				"HEAL", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"HEAL", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					16.5, -- [1]
				},
				["HealingTaken"] = {
					71104, -- [1]
				},
				["Overhealing"] = {
					50349, -- [1]
				},
				["ActiveTime"] = {
					96.22, -- [1]
				},
				["TimeDamage"] = {
					79.72, -- [1]
				},
				["Healing"] = {
					71104, -- [1]
				},
				["DamageTaken"] = {
					837450, -- [1]
				},
				["Damage"] = {
					4367548, -- [1]
				},
			},
			["enClass"] = "PET",
			["LastDamageTaken"] = 60518,
			["level"] = 1,
			["LastDamageAbility"] = "肉搏",
			["LastFightIn"] = 8,
			["LastAbility"] = 434259.754,
			["type"] = "Pet",
			["FightsSaved"] = 5,
			["ownerName"] = "灰衣人",
			["UnitLockout"] = 12952.298,
			["LastEventHealth"] = {
				[24] = 4799297,
				[25] = 4801199,
				[26] = 622209,
			},
			["Fights"] = {
				["Fight5"] = {
					["TimeHealing"] = {
						["肉弹 <灰衣人>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["TimeSpent"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
								["肉弹横扫"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["肉弹 <灰衣人>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["HealedWho"] = {
						["肉弹 <灰衣人>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 1902,
								},
							},
							["amount"] = 1902,
						},
					},
					["Overhealing"] = 0,
					["ActiveTime"] = 4.5,
					["Damage"] = 119647,
					["Heals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1902,
									["min"] = 1902,
									["count"] = 1,
									["amount"] = 1902,
								},
							},
							["count"] = 1,
							["amount"] = 1902,
						},
					},
					["Healing"] = 1902,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 59824,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 119647,
								},
							},
							["count"] = 2,
							["amount"] = 119647,
						},
						["肉弹横扫"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 1902,
					["DamagedWho"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
								["肉弹横扫"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 119647,
								},
							},
							["amount"] = 119647,
						},
					},
					["TimeDamage"] = 3,
					["TimeDamaging"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
								["肉弹横扫"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["ElementDone"] = {
						["Melee"] = 119647,
						["Physical"] = 0,
					},
					["TimeHeal"] = 1.5,
					["WhoHealed"] = {
						["肉弹 <灰衣人>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 1902,
								},
							},
							["amount"] = 1902,
						},
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
						["Fire"] = 0,
						["Melee"] = 0,
						["Nature"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["FDamagedWho"] = {
					},
					["FAttacks"] = {
					},
					["RageGain"] = 0,
					["ElementDone"] = {
						["Melee"] = 0,
						["Physical"] = 0,
					},
					["ManaGainedFrom"] = {
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Dodge"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RageGained"] = {
					},
					["WhoDamaged"] = {
						["暮色卫队掠夺者"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["邪能打击"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["饥饿的魔犬"] = {
							["Details"] = {
								["污染"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["Dispelled"] = 0,
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["肉弹 <灰衣人>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
					},
					["WhoHealed"] = {
						["肉弹 <灰衣人>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGain"] = 0,
					["CCBreak"] = 0,
					["PartialAbsorb"] = {
						["邪能打击"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["污染"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 0,
					["PartialResist"] = {
						["邪能打击"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["污染"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["肉弹 <灰衣人>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队掠夺者"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
								["肉弹横扫"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
								["肉弹横扫"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Heals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
						["肉弹 <灰衣人>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["Attacks"] = {
						["肉搏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Dodge"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉弹横扫"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["暮色卫队掠夺者"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
								["肉弹横扫"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
								["肉弹横扫"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
								["肉弹横扫"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["暮色卫队掠夺者"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
								["肉弹横扫"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
								["肉弹横扫"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["TimeHealing"] = {
						["肉弹 <灰衣人>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 16.5,
								},
							},
							["amount"] = 16.5,
						},
					},
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 15519,
									["min"] = 2352,
									["count"] = 7,
									["amount"] = 50349,
								},
							},
							["count"] = 7,
							["amount"] = 50349,
						},
					},
					["TimeSpent"] = {
						["暮色骑士希莱林"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 13.5,
								},
							},
							["amount"] = 13.5,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 23.93,
								},
								["肉弹横扫"] = {
									["count"] = 0.11,
								},
							},
							["amount"] = 24.04,
						},
						["黑石蜥蜴"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 16.27,
								},
								["肉弹横扫"] = {
									["count"] = 0.25,
								},
							},
							["amount"] = 16.52,
						},
						["肉弹 <灰衣人>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 16.5,
								},
							},
							["amount"] = 16.5,
						},
						["梅瑞戴尔滑翔者"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
						["暮色卫队掠夺者"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 7.5,
								},
							},
							["amount"] = 7.5,
						},
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 11.61,
								},
								["肉弹横扫"] = {
									["count"] = 2.05,
								},
							},
							["amount"] = 13.66,
						},
					},
					["DamageTaken"] = 837450,
					["PartialResist"] = {
						["邪能打击"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 3,
						},
						["污染"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 3,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 4,
						},
					},
					["Overhealing"] = 50349,
					["ActiveTime"] = 96.22,
					["ElementTaken"] = {
						["Fire"] = 439867,
						["Melee"] = 245504,
						["Nature"] = 152079,
					},
					["Damage"] = 4367548,
					["TimeHeal"] = 16.5,
					["Heals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 13316,
									["min"] = 1902,
									["count"] = 11,
									["amount"] = 71104,
								},
							},
							["count"] = 11,
							["amount"] = 71104,
						},
					},
					["ElementHitsTaken"] = {
						["Fire"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["Attacks"] = {
						["肉搏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 81347,
									["min"] = 59823,
									["count"] = 44,
									["amount"] = 2994110,
								},
								["Crit"] = {
									["max"] = 162695,
									["min"] = 119646,
									["count"] = 8,
									["amount"] = 1166063,
								},
								["Dodge"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 53,
							["amount"] = 4160173,
						},
						["肉弹横扫"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 38538,
									["min"] = 36368,
									["count"] = 4,
									["amount"] = 149811,
								},
								["Hit"] = {
									["max"] = 21196,
									["min"] = 18184,
									["count"] = 3,
									["amount"] = 57564,
								},
							},
							["count"] = 7,
							["amount"] = 207375,
						},
					},
					["Healing"] = 71104,
					["WhoDamaged"] = {
						["暮色骑士希莱林"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 125369,
								},
							},
							["amount"] = 125369,
						},
						["暮色卫队掠夺者"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 51483,
								},
							},
							["amount"] = 51483,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["邪能打击"] = {
									["count"] = 439867,
								},
								["肉搏"] = {
									["count"] = 68652,
								},
							},
							["amount"] = 508519,
						},
						["饥饿的魔犬"] = {
							["Details"] = {
								["污染"] = {
									["count"] = 152079,
								},
							},
							["amount"] = 152079,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 44,
								},
								["Crit"] = {
									["count"] = 8,
								},
								["Dodge"] = {
									["count"] = 1,
								},
							},
							["amount"] = 53,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 4,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 7,
						},
					},
					["ElementDone"] = {
						["Melee"] = 4160173,
						["Physical"] = 207375,
					},
					["HealingTaken"] = 71104,
					["DamagedWho"] = {
						["暮色骑士希莱林"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 669008,
								},
							},
							["amount"] = 669008,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 1220361,
								},
								["肉弹横扫"] = {
									["count"] = 54552,
								},
							},
							["amount"] = 1274913,
						},
						["黑石蜥蜴"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 1065968,
								},
								["肉弹横扫"] = {
									["count"] = 21196,
								},
							},
							["amount"] = 1087164,
						},
						["梅瑞戴尔滑翔者"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 202845,
								},
							},
							["amount"] = 202845,
						},
						["暮色卫队掠夺者"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 488540,
								},
								["肉弹横扫"] = {
									["count"] = 54552,
								},
							},
							["amount"] = 543092,
						},
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 513451,
								},
								["肉弹横扫"] = {
									["count"] = 77075,
								},
							},
							["amount"] = 590526,
						},
					},
					["TimeDamage"] = 79.72,
					["TimeDamaging"] = {
						["暮色骑士希莱林"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 13.5,
								},
							},
							["amount"] = 13.5,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 23.93,
								},
								["肉弹横扫"] = {
									["count"] = 0.11,
								},
							},
							["amount"] = 24.04,
						},
						["黑石蜥蜴"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 16.27,
								},
								["肉弹横扫"] = {
									["count"] = 0.25,
								},
							},
							["amount"] = 16.52,
						},
						["梅瑞戴尔滑翔者"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
						["暮色卫队掠夺者"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 7.5,
								},
							},
							["amount"] = 7.5,
						},
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 11.61,
								},
								["肉弹横扫"] = {
									["count"] = 2.05,
								},
							},
							["amount"] = 13.66,
						},
					},
					["HealedWho"] = {
						["肉弹 <灰衣人>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 71104,
								},
							},
							["amount"] = 71104,
						},
					},
					["WhoHealed"] = {
						["肉弹 <灰衣人>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 71104,
								},
							},
							["amount"] = 71104,
						},
					},
					["PartialAbsorb"] = {
						["邪能打击"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["污染"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
					},
				},
				["Fight4"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 60518,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
						["Melee"] = 60518,
					},
					["DOT_Time"] = 0,
					["Damage"] = 378875,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 1.5,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["FDamagedWho"] = {
					},
					["FAttacks"] = {
					},
					["RageGain"] = 0,
					["ElementDone"] = {
						["Melee"] = 378875,
					},
					["ManaGainedFrom"] = {
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 5,
						},
					},
					["RageGained"] = {
					},
					["WhoDamaged"] = {
						["暮色骑士希莱林"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 60518,
								},
							},
							["amount"] = 60518,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["Dispelled"] = 0,
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["肉弹 <灰衣人>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["OverHeals"] = {
					},
					["WhoHealed"] = {
						["肉弹 <灰衣人>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 7609,
								},
							},
							["amount"] = 7609,
						},
					},
					["EnergyGain"] = 0,
					["CCBreak"] = 0,
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 9,
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色骑士希莱林"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 7.5,
								},
							},
							["amount"] = 7.5,
						},
						["肉弹 <灰衣人>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["Heals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 7609,
									["min"] = 7609,
									["count"] = 1,
									["amount"] = 7609,
								},
							},
							["count"] = 1,
							["amount"] = 7609,
						},
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
						["肉弹 <灰衣人>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 7609,
								},
							},
							["amount"] = 7609,
						},
					},
					["Healing"] = 7609,
					["RunicPowerGained"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["Attacks"] = {
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 119646,
									["min"] = 119646,
									["count"] = 1,
									["amount"] = 119646,
								},
								["Hit"] = {
									["max"] = 69792,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 259229,
								},
							},
							["count"] = 5,
							["amount"] = 378875,
						},
					},
					["HealingTaken"] = 7609,
					["DamagedWho"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色骑士希莱林"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 378875,
								},
							},
							["amount"] = 378875,
						},
					},
					["TimeDamage"] = 7.5,
					["TimeDamaging"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色骑士希莱林"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 7.5,
								},
							},
							["amount"] = 7.5,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["FDamagedWho"] = {
					},
					["FAttacks"] = {
					},
					["RageGain"] = 0,
					["ElementDone"] = {
						["Melee"] = 0,
					},
					["ManaGainedFrom"] = {
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RageGained"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["Dispelled"] = 0,
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
					},
					["EnergyGain"] = 0,
					["CCBreak"] = 0,
					["PartialAbsorb"] = {
					},
					["ActiveTime"] = 0,
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["梅瑞戴尔滑翔者"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["Attacks"] = {
						["肉搏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["梅瑞戴尔滑翔者"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["梅瑞戴尔滑翔者"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight3"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 488540,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["FDamagedWho"] = {
					},
					["FAttacks"] = {
					},
					["RageGain"] = 0,
					["ElementDone"] = {
						["Melee"] = 488540,
					},
					["ManaGainedFrom"] = {
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 5,
						},
					},
					["RageGained"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["Dispelled"] = 0,
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 8876,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 15535,
								},
							},
							["count"] = 2,
							["amount"] = 15535,
						},
					},
					["WhoHealed"] = {
					},
					["EnergyGain"] = 0,
					["CCBreak"] = 0,
					["PartialAbsorb"] = {
					},
					["ActiveTime"] = 7.5,
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 15535,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 7.5,
								},
							},
							["amount"] = 7.5,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["Attacks"] = {
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 139584,
									["min"] = 139582,
									["count"] = 2,
									["amount"] = 279166,
								},
								["Hit"] = {
									["max"] = 69792,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 209374,
								},
							},
							["count"] = 5,
							["amount"] = 488540,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 488540,
								},
							},
							["amount"] = 488540,
						},
					},
					["TimeDamage"] = 7.5,
					["TimeDamaging"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 7.5,
								},
							},
							["amount"] = 7.5,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
			},
			["NextEventNum"] = 43,
			["LastDamageTime"] = 12950.983,
			["LastEvents"] = {
				"暮色卫队掠夺者 肉搏 肉弹 <灰衣人> Hit -51483 (Physical)", -- [1]
				"肉弹 <灰衣人> 肉搏 暮色卫队掠夺者 Crit -139582 (Physical)", -- [2]
				"肉弹 <灰衣人> 肉搏 暮色卫队掠夺者 Hit -69791 (Physical)", -- [3]
				"肉弹 <灰衣人> 肉搏 暮色卫队掠夺者 Hit -69792 (Physical)", -- [4]
				"饥饿的魔犬 污染 肉弹 <灰衣人> Hit -53648 (Nature)", -- [5]
				"肉弹 <灰衣人> 肉搏 暮色卫队掠夺者 Crit -139584 (Physical)", -- [6]
				"肉弹 <灰衣人> 吸血 肉弹 <灰衣人> Hit +13316", -- [7]
				"饥饿的魔犬 污染 肉弹 <灰衣人> Hit -54354 (Nature)", -- [8]
				"肉弹 <灰衣人> 肉搏 狡猾的灌尾狐 Hit -63389 (Physical)", -- [9]
				"饥饿的魔犬 污染 肉弹 <灰衣人> Hit -44077 (Nature)", -- [10]
				"肉弹 <灰衣人> 肉弹横扫 狡猾的灌尾狐 Crit -38537 (Physical)", -- [11]
				"肉弹 <灰衣人> 肉搏 狡猾的灌尾狐 Hit -63389 (Physical)", -- [12]
				"肉弹 <灰衣人> 肉搏 狡猾的灌尾狐 Hit -63389 (Physical)", -- [13]
				"肉弹 <灰衣人> 吸血 肉弹 <灰衣人> Hit +7273", -- [14]
				"肉弹 <灰衣人> 肉搏 狡猾的灌尾狐 Hit -63389 (Physical)", -- [15]
				"肉弹 <灰衣人> 肉搏 狡猾的灌尾狐 Hit -63389 (Physical)", -- [16]
				"肉弹 <灰衣人> 吸血 肉弹 <灰衣人> Hit +4032", -- [17]
				"肉弹 <灰衣人> 肉搏 狡猾的灌尾狐 Hit -63389 (Physical)", -- [18]
				"肉弹 <灰衣人> 肉弹横扫 狡猾的灌尾狐 Crit -38538 (Physical)", -- [19]
				"肉弹 <灰衣人> 肉搏 狡猾的灌尾狐 Hit -63389 (Physical)", -- [20]
				"肉弹 <灰衣人> 肉搏 狡猾的灌尾狐 Hit -69728 (Physical)", -- [21]
				"肉弹 <灰衣人> 吸血 肉弹 <灰衣人> Hit +7474", -- [22]
				"肉弹 <灰衣人> 肉搏 狡猾的灌尾狐 Dodge (1)", -- [23]
				"肉弹 <灰衣人> 肉搏 暮色卫队邪剑士 Hit -59823 (Physical)", -- [24]
				"肉弹 <灰衣人> 吸血 肉弹 <灰衣人> Hit +1902", -- [25]
				"肉弹 <灰衣人> 肉搏 暮色卫队邪剑士 Hit -59824 (Physical)", -- [26]
				"肉弹 <灰衣人> 吸血 肉弹 <灰衣人> Hit +1902", -- [27]
				"肉弹 <灰衣人> 肉搏 暮色骑士希莱林 Crit -119646 (Physical)", -- [28]
				"暮色骑士希莱林 肉搏 肉弹 <灰衣人> Hit -60518 (Physical)", -- [29]
				"肉弹 <灰衣人> 肉搏 暮色骑士希莱林 Hit -59823 (Physical)", -- [30]
				"肉弹 <灰衣人> 肉搏 暮色骑士希莱林 Hit -59823 (Physical)", -- [31]
				"肉弹 <灰衣人> 吸血 肉弹 <灰衣人> Hit +7609", -- [32]
				"肉弹 <灰衣人> 肉搏 暮色骑士希莱林 Hit -69791 (Physical)", -- [33]
				"肉弹 <灰衣人> 肉搏 暮色骑士希莱林 Hit -69792 (Physical)", -- [34]
				"肉弹 <灰衣人> 吸血 肉弹 <灰衣人> Hit +4439", -- [35]
				"肉弹 <灰衣人> 肉搏 暮色卫队邪剑士 Hit -69792 (Physical)", -- [36]
				"肉弹 <灰衣人> 肉搏 暮色卫队邪剑士 Crit -139584 (Physical)", -- [37]
				"肉弹 <灰衣人> 肉搏 暮色卫队邪剑士 Hit -69791 (Physical)", -- [38]
				"肉弹 <灰衣人> 吸血 肉弹 <灰衣人> Hit +6659 (6659 过量治疗)", -- [39]
				"肉弹 <灰衣人> 肉搏 暮色卫队邪剑士 Hit -69791 (Physical)", -- [40]
				"肉弹 <灰衣人> 肉搏 暮色卫队邪剑士 Crit -139582 (Physical)", -- [41]
				"肉弹 <灰衣人> 吸血 肉弹 <灰衣人> Hit +8876 (8876 过量治疗)", -- [42]
				"肉弹 <灰衣人> 吸血 肉弹 <灰衣人> Hit +6657", -- [43]
				"肉弹 <灰衣人> 肉搏 暮色卫队邪剑士 Hit -69791 (Physical)", -- [44]
				"暮色卫队邪剑士 邪能打击 肉弹 <灰衣人> Hit -140521 (Fire)", -- [45]
				"暮色卫队邪剑士 邪能打击 肉弹 <灰衣人> Hit -181830 (Fire)", -- [46]
				"肉弹 <灰衣人> 肉搏 暮色卫队掠夺者 Hit -69791 (Physical)", -- [47]
				"肉弹 <灰衣人> 肉弹横扫 暮色卫队掠夺者 Crit -36368 (Physical)", -- [48]
				"肉弹 <灰衣人> 肉弹横扫 暮色卫队掠夺者 Hit -18184 (Physical)", -- [49]
				"肉弹 <灰衣人> 吸血 肉弹 <灰衣人> Hit +6174", -- [50]
			},
			["Name"] = "肉弹",
			["LastEventIncoming"] = {
				true, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				true, -- [5]
				false, -- [6]
				true, -- [7]
				true, -- [8]
				false, -- [9]
				true, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				true, -- [14]
				false, -- [15]
				false, -- [16]
				true, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				true, -- [22]
				false, -- [23]
				false, -- [24]
				true, -- [25]
				false, -- [26]
				true, -- [27]
				false, -- [28]
				true, -- [29]
				false, -- [30]
				false, -- [31]
				true, -- [32]
				false, -- [33]
				false, -- [34]
				true, -- [35]
				false, -- [36]
				false, -- [37]
				false, -- [38]
				true, -- [39]
				false, -- [40]
				false, -- [41]
				true, -- [42]
				true, -- [43]
				false, -- [44]
				true, -- [45]
				true, -- [46]
				false, -- [47]
				false, -- [48]
				false, -- [49]
				true, -- [50]
			},
			["LastEventTimes"] = {
				12868.316, -- [1]
				12868.937, -- [2]
				12870.453, -- [3]
				12872.072, -- [4]
				12873.298, -- [5]
				12873.677, -- [6]
				12873.965, -- [7]
				12874.311, -- [8]
				12875.184, -- [9]
				12875.301, -- [10]
				12876.429, -- [11]
				12876.805, -- [12]
				12878.363, -- [13]
				12878.875, -- [14]
				12879.986, -- [15]
				12881.544, -- [16]
				12884.17, -- [17]
				12886.282, -- [18]
				12887.091, -- [19]
				12887.817, -- [20]
				12889.387, -- [21]
				12889.897, -- [22]
				12890.95, -- [23]
				12910.278, -- [24]
				12910.636, -- [25]
				12911.859, -- [26]
				12916.349, -- [27]
				12922.515, -- [28]
				12922.515, -- [29]
				12924.092, -- [30]
				12925.679, -- [31]
				12926.592, -- [32]
				12927.207, -- [33]
				12928.782, -- [34]
				12932.29, -- [35]
				12944.52, -- [36]
				12946.122, -- [37]
				12947.835, -- [38]
				12947.835, -- [39]
				12949.431, -- [40]
				12950.983, -- [41]
				12953.183, -- [42]
				12862.824, -- [43]
				12863.682, -- [44]
				12864.12, -- [45]
				12864.12, -- [46]
				12867.367, -- [47]
				12867.367, -- [48]
				12867.367, -- [49]
				12868.316, -- [50]
			},
			["LastHealTime"] = 12926.592,
			["LastEventHealthMax"] = {
				[24] = 5185920,
				[25] = 5185920,
				[26] = 2115200,
			},
			["LastActive"] = 12952.298,
		},
		["扎克里拉 <灰衣人>"] = {
			["GUID"] = "Pet-0-3908-1220-5377-78158-01022524EF",
			["LastEventHealth"] = {
				2074368, -- [1]
				2074368, -- [2]
				2074368, -- [3]
				2074368, -- [4]
				2074368, -- [5]
				2074368, -- [6]
				2074368, -- [7]
				2074368, -- [8]
				2074368, -- [9]
				2074368, -- [10]
				2074368, -- [11]
				2074368, -- [12]
				2074368, -- [13]
				2074368, -- [14]
				2074368, -- [15]
				2074368, -- [16]
				2074368, -- [17]
				2074368, -- [18]
				2074368, -- [19]
				2074368, -- [20]
				2074368, -- [21]
				2074368, -- [22]
				2074368, -- [23]
				2074368, -- [24]
				2074368, -- [25]
				2074368, -- [26]
				2074368, -- [27]
				2074368, -- [28]
				2074368, -- [29]
				2074368, -- [30]
				2074368, -- [31]
				2074368, -- [32]
				2074368, -- [33]
				2074368, -- [34]
				2074368, -- [35]
				2074368, -- [36]
				2074368, -- [37]
				2074368, -- [38]
				2074368, -- [39]
				2074368, -- [40]
				2074368, -- [41]
				2074368, -- [42]
				2074368, -- [43]
				2074368, -- [44]
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"HEAL", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"HEAL", -- [7]
				"DAMAGE", -- [8]
				"HEAL", -- [9]
				"DAMAGE", -- [10]
				"HEAL", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"HEAL", -- [14]
				"DAMAGE", -- [15]
				"HEAL", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"HEAL", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"HEAL", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"HEAL", -- [25]
				"DAMAGE", -- [26]
				"HEAL", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"HEAL", -- [30]
				"DAMAGE", -- [31]
				"HEAL", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"HEAL", -- [35]
				"DAMAGE", -- [36]
				"HEAL", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"HEAL", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"HEAL", -- [43]
				"DAMAGE", -- [44]
			},
			["TimeWindows"] = {
				["ActiveTime"] = {
					42, -- [1]
				},
				["Damage"] = {
					7422574, -- [1]
				},
				["Overhealing"] = {
					153020, -- [1]
				},
				["TimeDamage"] = {
					42, -- [1]
				},
			},
			["enClass"] = "PET",
			["unit"] = "扎克里拉",
			["level"] = 1,
			["LastFightIn"] = 9,
			["type"] = "Pet",
			["FightsSaved"] = 5,
			["ownerName"] = "灰衣人",
			["LastAbility"] = 434259.754,
			["UnitLockout"] = 12602.316,
			["TimeLast"] = {
				["Overhealing"] = 12950.292,
				["ActiveTime"] = 12999.285,
				["OVERALL"] = 12999.285,
				["TimeDamage"] = 12999.285,
				["Damage"] = 12999.285,
			},
			["NextEventNum"] = 45,
			["LastDamageTime"] = 12999.921,
			["LastEvents"] = {
				"扎克里拉 <灰衣人> 厄运箭 黑石蜥蜴 Hit -225473 (Shadow)", -- [1]
				"扎克里拉 <灰衣人> 厄运箭 黑石蜥蜴 Hit -248019 (Shadow)", -- [2]
				"扎克里拉 <灰衣人> 厄运箭 黑石蜥蜴 Crit -496036 (Shadow)", -- [3]
				"扎克里拉 <灰衣人> 吸血 扎克里拉 <灰衣人> Hit +15773 (15773 过量治疗)", -- [4]
				"扎克里拉 <灰衣人> 厄运箭 黑石蜥蜴 Hit -225473 (Shadow)", -- [5]
				"扎克里拉 <灰衣人> 厄运箭 黑石蜥蜴 Hit -225471 (Shadow)", -- [6]
				"扎克里拉 <灰衣人> 吸血 扎克里拉 <灰衣人> Hit +14340 (14340 过量治疗)", -- [7]
				"扎克里拉 <灰衣人> 厄运箭 黑石蜥蜴 Hit -225471 (Shadow)", -- [8]
				"扎克里拉 <灰衣人> 吸血 扎克里拉 <灰衣人> Hit +7169 (7169 过量治疗)", -- [9]
				"扎克里拉 <灰衣人> 厄运箭 暮色骑士希莱林 Hit -248019 (Shadow)", -- [10]
				"扎克里拉 <灰衣人> 吸血 扎克里拉 <灰衣人> Hit +7887 (7887 过量治疗)", -- [11]
				"扎克里拉 <灰衣人> 厄运箭 暮色骑士希莱林 Hit -248019 (Shadow)", -- [12]
				"扎克里拉 <灰衣人> 厄运箭 暮色骑士希莱林 Hit -297623 (Shadow)", -- [13]
				"扎克里拉 <灰衣人> 吸血 扎克里拉 <灰衣人> Hit +17351 (17351 过量治疗)", -- [14]
				"扎克里拉 <灰衣人> 厄运箭 暮色卫队邪剑士 Hit -248019 (Shadow)", -- [15]
				"扎克里拉 <灰衣人> 吸血 扎克里拉 <灰衣人> Hit +7887 (7887 过量治疗)", -- [16]
				"扎克里拉 <灰衣人> 厄运箭 梅瑞戴尔滑翔者 Hit -212592 (Shadow)", -- [17]
				"扎克里拉 <灰衣人> 厄运箭 梅瑞戴尔滑翔者 Hit -193267 (Shadow)", -- [18]
				"扎克里拉 <灰衣人> 吸血 扎克里拉 <灰衣人> Hit +12906 (12906 过量治疗)", -- [19]
				"扎克里拉 <灰衣人> 厄运箭 暮色卫队邪剑士 Hit -193267 (Shadow)", -- [20]
				"扎克里拉 <灰衣人> 厄运箭 暮色卫队邪剑士 Crit -541132 (Shadow)", -- [21]
				"扎克里拉 <灰衣人> 吸血 扎克里拉 <灰衣人> Hit +23353 (23353 过量治疗)", -- [22]
				"扎克里拉 <灰衣人> 厄运箭 暮色卫队邪剑士 Hit -225471 (Shadow)", -- [23]
				"扎克里拉 <灰衣人> 厄运箭 暮色卫队邪剑士 Hit -225471 (Shadow)", -- [24]
				"扎克里拉 <灰衣人> 吸血 扎克里拉 <灰衣人> Hit +14339 (14339 过量治疗)", -- [25]
				"扎克里拉 <灰衣人> 厄运箭 暮色卫队邪剑士 Hit -225471 (Shadow)", -- [26]
				"扎克里拉 <灰衣人> 吸血 扎克里拉 <灰衣人> Hit +7169 (7169 过量治疗)", -- [27]
				"扎克里拉 <灰衣人> 厄运箭 暮色卫队掠夺者 Hit -225471 (Shadow)", -- [28]
				"扎克里拉 <灰衣人> 厄运箭 暮色卫队掠夺者 Hit -225473 (Shadow)", -- [29]
				"扎克里拉 <灰衣人> 吸血 扎克里拉 <灰衣人> Hit +14338 (14338 过量治疗)", -- [30]
				"扎克里拉 <灰衣人> 厄运箭 暮色卫队掠夺者 Hit -231921 (Shadow)", -- [31]
				"扎克里拉 <灰衣人> 吸血 扎克里拉 <灰衣人> Hit +7375 (7375 过量治疗)", -- [32]
				"扎克里拉 <灰衣人> 厄运箭 狡猾的灌尾狐 Hit -193267 (Shadow)", -- [33]
				"扎克里拉 <灰衣人> 厄运箭 狡猾的灌尾狐 Hit -212594 (Shadow)", -- [34]
				"扎克里拉 <灰衣人> 吸血 扎克里拉 <灰衣人> Hit +12905 (12905 过量治疗)", -- [35]
				"扎克里拉 <灰衣人> 厄运箭 暮色卫队邪剑士 Hit -193267 (Shadow)", -- [36]
				"扎克里拉 <灰衣人> 吸血 扎克里拉 <灰衣人> Hit +6146 (6146 过量治疗)", -- [37]
				"扎克里拉 <灰衣人> 厄运箭 暮色骑士希莱林 Hit -193267 (Shadow)", -- [38]
				"扎克里拉 <灰衣人> 厄运箭 暮色骑士希莱林 Hit -225473 (Shadow)", -- [39]
				"扎克里拉 <灰衣人> 吸血 扎克里拉 <灰衣人> Hit +13316 (13316 过量治疗)", -- [40]
				"扎克里拉 <灰衣人> 厄运箭 暮色卫队邪剑士 Crit -450944 (Shadow)", -- [41]
				"扎克里拉 <灰衣人> 厄运箭 暮色卫队邪剑士 Hit -225471 (Shadow)", -- [42]
				"扎克里拉 <灰衣人> 吸血 扎克里拉 <灰衣人> Hit +21509 (21509 过量治疗)", -- [43]
				"扎克里拉 <灰衣人> 厄运箭 狡猾的灌尾狐 Crit -541132 (Shadow)", -- [44]
			},
			["Name"] = "扎克里拉",
			["Fights"] = {
				["OverallData"] = {
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 23353,
									["min"] = 7169,
									["count"] = 12,
									["amount"] = 153020,
								},
							},
							["count"] = 12,
							["amount"] = 153020,
						},
					},
					["TimeSpent"] = {
						["暮色骑士希莱林"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 7.5,
								},
							},
							["amount"] = 7.5,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 13.5,
								},
							},
							["amount"] = 13.5,
						},
						["黑石蜥蜴"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
						["梅瑞戴尔滑翔者"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["暮色卫队掠夺者"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 4,
								},
								["Hit"] = {
									["count"] = 24,
								},
							},
							["amount"] = 28,
						},
					},
					["ElementDone"] = {
						["Shadow"] = 7422574,
					},
					["ActiveTime"] = 42,
					["Overhealing"] = 153020,
					["TimeDamage"] = 42,
					["TimeDamaging"] = {
						["暮色骑士希莱林"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 7.5,
								},
							},
							["amount"] = 7.5,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 13.5,
								},
							},
							["amount"] = 13.5,
						},
						["黑石蜥蜴"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
						["梅瑞戴尔滑翔者"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["暮色卫队掠夺者"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
					},
					["Attacks"] = {
						["厄运箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 541132,
									["min"] = 450944,
									["count"] = 4,
									["amount"] = 2029244,
								},
								["Hit"] = {
									["max"] = 297623,
									["min"] = 193267,
									["count"] = 24,
									["amount"] = 5393330,
								},
							},
							["count"] = 28,
							["amount"] = 7422574,
						},
					},
					["DamagedWho"] = {
						["暮色骑士希莱林"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 1212401,
								},
							},
							["amount"] = 1212401,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 2528513,
								},
							},
							["amount"] = 2528513,
						},
						["黑石蜥蜴"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 1645943,
								},
							},
							["amount"] = 1645943,
						},
						["梅瑞戴尔滑翔者"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 405859,
								},
							},
							["amount"] = 405859,
						},
						["暮色卫队掠夺者"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 682865,
								},
							},
							["amount"] = 682865,
						},
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 946993,
								},
							},
							["amount"] = 946993,
						},
					},
					["Damage"] = 7422574,
				},
				["Fight5"] = {
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["TimeSpent"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["ElementDone"] = {
						["Shadow"] = 193267,
					},
					["ActiveTime"] = 1.5,
					["Overhealing"] = 0,
					["TimeDamage"] = 1.5,
					["TimeDamaging"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["Attacks"] = {
						["厄运箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 193267,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 193267,
								},
							},
							["count"] = 1,
							["amount"] = 193267,
						},
					},
					["DamagedWho"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 193267,
								},
							},
							["amount"] = 193267,
						},
					},
					["Damage"] = 193267,
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["FDamagedWho"] = {
					},
					["FAttacks"] = {
					},
					["RageGain"] = 0,
					["ElementDone"] = {
						["Shadow"] = 0,
					},
					["ManaGainedFrom"] = {
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RageGained"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["Dispelled"] = 0,
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
					},
					["EnergyGain"] = 0,
					["CCBreak"] = 0,
					["PartialAbsorb"] = {
					},
					["ActiveTime"] = 0,
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["暮色卫队掠夺者"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["Attacks"] = {
						["厄运箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["暮色卫队掠夺者"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["暮色卫队掠夺者"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight4"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 418740,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["FDamagedWho"] = {
					},
					["FAttacks"] = {
					},
					["RageGain"] = 0,
					["ElementDone"] = {
						["Shadow"] = 418740,
					},
					["ManaGainedFrom"] = {
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["RageGained"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["Dispelled"] = 0,
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 13316,
									["min"] = 13316,
									["count"] = 1,
									["amount"] = 13316,
								},
							},
							["count"] = 1,
							["amount"] = 13316,
						},
					},
					["WhoHealed"] = {
					},
					["EnergyGain"] = 0,
					["CCBreak"] = 0,
					["PartialAbsorb"] = {
					},
					["ActiveTime"] = 3,
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 13316,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色骑士希莱林"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["Attacks"] = {
						["厄运箭"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 225473,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 418740,
								},
							},
							["count"] = 2,
							["amount"] = 418740,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色骑士希莱林"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 418740,
								},
							},
							["amount"] = 418740,
						},
					},
					["TimeDamage"] = 3,
					["TimeDamaging"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色骑士希莱林"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["FDamagedWho"] = {
					},
					["FAttacks"] = {
					},
					["RageGain"] = 0,
					["ElementDone"] = {
						["Shadow"] = 0,
					},
					["ManaGainedFrom"] = {
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RageGained"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["Dispelled"] = 0,
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
					},
					["EnergyGain"] = 0,
					["CCBreak"] = 0,
					["PartialAbsorb"] = {
					},
					["ActiveTime"] = 0,
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["梅瑞戴尔滑翔者"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["Attacks"] = {
						["厄运箭"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["梅瑞戴尔滑翔者"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["梅瑞戴尔滑翔者"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight2"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["FDamagedWho"] = {
					},
					["FAttacks"] = {
					},
					["RageGain"] = 0,
					["ElementDone"] = {
						["Shadow"] = 0,
					},
					["ManaGainedFrom"] = {
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RageGained"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["Dispelled"] = 0,
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
					},
					["EnergyGain"] = 0,
					["CCBreak"] = 0,
					["PartialAbsorb"] = {
					},
					["ActiveTime"] = 0,
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["暮色骑士希莱林"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["Attacks"] = {
						["厄运箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["暮色骑士希莱林"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["暮色骑士希莱林"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight3"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 676415,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["FDamagedWho"] = {
					},
					["FAttacks"] = {
					},
					["RageGain"] = 0,
					["ElementDone"] = {
						["Shadow"] = 676415,
					},
					["ManaGainedFrom"] = {
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
					},
					["RageGained"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["Dispelled"] = 0,
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 21509,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 21509,
								},
							},
							["count"] = 1,
							["amount"] = 21509,
						},
					},
					["WhoHealed"] = {
					},
					["EnergyGain"] = 0,
					["CCBreak"] = 0,
					["PartialAbsorb"] = {
					},
					["ActiveTime"] = 3,
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 21509,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["Attacks"] = {
						["厄运箭"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 450944,
									["min"] = 450944,
									["count"] = 1,
									["amount"] = 450944,
								},
								["Hit"] = {
									["max"] = 225471,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 225471,
								},
							},
							["count"] = 2,
							["amount"] = 676415,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 676415,
								},
							},
							["amount"] = 676415,
						},
					},
					["TimeDamage"] = 3,
					["TimeDamaging"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["厄运箭"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
			},
			["LastEventTimes"] = {
				12603.166, -- [1]
				12605.431, -- [2]
				12607.695, -- [3]
				12611.257, -- [4]
				12628.244, -- [5]
				12630.264, -- [6]
				12632.377, -- [7]
				12637.697, -- [8]
				12637.823, -- [9]
				12794.426, -- [10]
				12796.91, -- [11]
				12796.91, -- [12]
				12799.332, -- [13]
				12802.225, -- [14]
				12808.901, -- [15]
				12812.884, -- [16]
				12813.052, -- [17]
				12815.273, -- [18]
				12818.287, -- [19]
				12856.655, -- [20]
				12858.964, -- [21]
				12860.813, -- [22]
				12862.254, -- [23]
				12864.632, -- [24]
				12866.138, -- [25]
				12867.206, -- [26]
				12871.537, -- [27]
				12872.699, -- [28]
				12875.085, -- [29]
				12876.805, -- [30]
				12877.359, -- [31]
				12882.143, -- [32]
				12888.625, -- [33]
				12890.793, -- [34]
				12892.713, -- [35]
				12911.066, -- [36]
				12913.877, -- [37]
				12925.339, -- [38]
				12927.373, -- [39]
				12929.867, -- [40]
				12945.994, -- [41]
				12950.529, -- [42]
				12951.127, -- [43]
				12999.921, -- [44]
			},
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				true, -- [4]
				false, -- [5]
				false, -- [6]
				true, -- [7]
				false, -- [8]
				true, -- [9]
				false, -- [10]
				true, -- [11]
				false, -- [12]
				false, -- [13]
				true, -- [14]
				false, -- [15]
				true, -- [16]
				false, -- [17]
				false, -- [18]
				true, -- [19]
				false, -- [20]
				false, -- [21]
				true, -- [22]
				false, -- [23]
				false, -- [24]
				true, -- [25]
				false, -- [26]
				true, -- [27]
				false, -- [28]
				false, -- [29]
				true, -- [30]
				false, -- [31]
				true, -- [32]
				false, -- [33]
				false, -- [34]
				true, -- [35]
				false, -- [36]
				true, -- [37]
				false, -- [38]
				false, -- [39]
				true, -- [40]
				false, -- [41]
				false, -- [42]
				true, -- [43]
				false, -- [44]
			},
			["LastEventHealthMax"] = {
				2074368, -- [1]
				2074368, -- [2]
				2074368, -- [3]
				2074368, -- [4]
				2074368, -- [5]
				2074368, -- [6]
				2074368, -- [7]
				2074368, -- [8]
				2074368, -- [9]
				2074368, -- [10]
				2074368, -- [11]
				2074368, -- [12]
				2074368, -- [13]
				2074368, -- [14]
				2074368, -- [15]
				2074368, -- [16]
				2074368, -- [17]
				2074368, -- [18]
				2074368, -- [19]
				2074368, -- [20]
				2074368, -- [21]
				2074368, -- [22]
				2074368, -- [23]
				2074368, -- [24]
				2074368, -- [25]
				2074368, -- [26]
				2074368, -- [27]
				2074368, -- [28]
				2074368, -- [29]
				2074368, -- [30]
				2074368, -- [31]
				2074368, -- [32]
				2074368, -- [33]
				2074368, -- [34]
				2074368, -- [35]
				2074368, -- [36]
				2074368, -- [37]
				2074368, -- [38]
				2074368, -- [39]
				2074368, -- [40]
				2074368, -- [41]
				2074368, -- [42]
				2074368, -- [43]
				2074368, -- [44]
			},
			["LastActive"] = 12999.285,
		},
		["夜之子反叛者 <灰衣人>"] = {
			["GUID"] = "Creature-0-2139-1220-6762-119907-0000937FC6",
			["TimeLast"] = {
				["Overhealing"] = 12950.292,
				["ActiveTime"] = 12951.286,
				["OVERALL"] = 12951.286,
				["TimeDamage"] = 12951.286,
				["Damage"] = 12951.286,
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"HEAL", -- [5]
				"HEAL", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"HEAL", -- [9]
				"HEAL", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"HEAL", -- [18]
				"HEAL", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"HEAL", -- [22]
				"HEAL", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"HEAL", -- [28]
				"HEAL", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
			},
			["TimeWindows"] = {
				["ActiveTime"] = {
					16.89, -- [1]
				},
				["Damage"] = {
					2718908, -- [1]
				},
				["Overhealing"] = {
					66074, -- [1]
				},
				["TimeDamage"] = {
					16.89, -- [1]
				},
			},
			["enClass"] = "PET",
			["level"] = 1,
			["LastFightIn"] = 8,
			["type"] = "Pet",
			["FightsSaved"] = 5,
			["ownerName"] = "灰衣人",
			["LastAbility"] = 434259.754,
			["NextEventNum"] = 32,
			["LastDamageTime"] = 12951.846,
			["LastEvents"] = {
				"夜之子反叛者 <灰衣人> 肉搏 暮色卫队邪剑士 Hit -96223 (Physical)", -- [1]
				"夜之子反叛者 <灰衣人> 肉搏 暮色卫队邪剑士 Hit -128036 (Physical)", -- [2]
				"夜之子反叛者 <灰衣人> 肉搏 暮色卫队邪剑士 Hit -95402 (Physical)", -- [3]
				"夜之子反叛者 <灰衣人> 肉搏 暮色卫队邪剑士 Hit -99990 (Physical)", -- [4]
				"夜之子反叛者 <灰衣人> 吸血 夜之子反叛者 <灰衣人> Hit +4071 (4071 过量治疗)", -- [5]
				"夜之子反叛者 <灰衣人> 吸血 夜之子反叛者 <灰衣人> Hit +6094 (6094 过量治疗)", -- [6]
				"夜之子反叛者 <灰衣人> 肉搏 暮色骑士希莱林 Hit -126761 (Physical)", -- [7]
				"夜之子反叛者 <灰衣人> 肉搏 暮色骑士希莱林 Hit -94195 (Physical)", -- [8]
				"夜之子反叛者 <灰衣人> 吸血 夜之子反叛者 <灰衣人> Hit +4031 (4031 过量治疗)", -- [9]
				"夜之子反叛者 <灰衣人> 吸血 夜之子反叛者 <灰衣人> Hit +2995 (2995 过量治疗)", -- [10]
				"夜之子反叛者 <灰衣人> 肉搏 暮色骑士希莱林 Crit -252435 (Physical)", -- [11]
				"夜之子反叛者 <灰衣人> 肉搏 暮色骑士希莱林 Hit -124734 (Physical)", -- [12]
				"夜之子反叛者 <灰衣人> 肉搏 暮色骑士希莱林 Hit -131511 (Physical)", -- [13]
				"夜之子反叛者 <灰衣人> 挑衅重击 暮色骑士希莱林 Hit -163465 (Physical)", -- [14]
				"夜之子反叛者 <灰衣人> 挑衅重击 暮色骑士希莱林 Hit -86006 (Physical)", -- [15]
				"夜之子反叛者 <灰衣人> 肉搏 暮色骑士希莱林 Hit -123165 (Physical)", -- [16]
				"夜之子反叛者 <灰衣人> 肉搏 暮色骑士希莱林 Hit -117961 (Physical)", -- [17]
				"夜之子反叛者 <灰衣人> 吸血 夜之子反叛者 <灰衣人> Hit +18861 (18861 过量治疗)", -- [18]
				"夜之子反叛者 <灰衣人> 吸血 夜之子反叛者 <灰衣人> Hit +12914 (12914 过量治疗)", -- [19]
				"夜之子反叛者 <灰衣人> 肉搏 暮色卫队邪剑士 Hit -137171 (Physical)", -- [20]
				"夜之子反叛者 <灰衣人> 肉搏 暮色卫队邪剑士 Crit -230706 (Physical)", -- [21]
				"夜之子反叛者 <灰衣人> 吸血 夜之子反叛者 <灰衣人> Hit +7336 (7336 过量治疗)", -- [22]
				"夜之子反叛者 <灰衣人> 吸血 夜之子反叛者 <灰衣人> Hit +4362 (4362 过量治疗)", -- [23]
				"夜之子反叛者 <灰衣人> 肉搏 暮色卫队邪剑士 Hit -133349 (Physical)", -- [24]
				"夜之子反叛者 <灰衣人> 挑衅重击 暮色卫队邪剑士 Hit -141642 (Physical)", -- [25]
				"夜之子反叛者 <灰衣人> 肉搏 暮色卫队邪剑士 Hit -115927 (Physical)", -- [26]
				"夜之子反叛者 <灰衣人> 肉搏 暮色卫队邪剑士 Hit -98873 (Physical)", -- [27]
				"夜之子反叛者 <灰衣人> 吸血 夜之子反叛者 <灰衣人> Hit +12431 (12431 过量治疗)", -- [28]
				"夜之子反叛者 <灰衣人> 吸血 夜之子反叛者 <灰衣人> Hit +3144 (3144 过量治疗)", -- [29]
				"夜之子反叛者 <灰衣人> 肉搏 暮色卫队邪剑士 Hit -124067 (Physical)", -- [30]
				"夜之子反叛者 <灰衣人> 肉搏 暮色卫队邪剑士 Hit -97289 (Physical)", -- [31]
			},
			["Name"] = "夜之子反叛者",
			["UnitLockout"] = 12951.286,
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				true, -- [5]
				true, -- [6]
				false, -- [7]
				false, -- [8]
				true, -- [9]
				true, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				true, -- [18]
				true, -- [19]
				false, -- [20]
				false, -- [21]
				true, -- [22]
				true, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				true, -- [28]
				true, -- [29]
				false, -- [30]
				false, -- [31]
			},
			["Fights"] = {
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight5"] = {
					["TimeSpent"] = {
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["ElementDone"] = {
						["Melee"] = 419651,
					},
					["DamagedWho"] = {
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 419651,
								},
							},
							["amount"] = 419651,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
					},
					["TimeDamage"] = 3,
					["TimeDamaging"] = {
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["ActiveTime"] = 3,
					["Attacks"] = {
						["肉搏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 128036,
									["min"] = 95402,
									["count"] = 4,
									["amount"] = 419651,
								},
							},
							["count"] = 4,
							["amount"] = 419651,
						},
					},
					["Damage"] = 419651,
				},
				["Fight4"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 1220233,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["FDamagedWho"] = {
					},
					["FAttacks"] = {
					},
					["RageGain"] = 0,
					["ElementDone"] = {
						["Melee"] = 970762,
						["Physical"] = 249471,
					},
					["ManaGainedFrom"] = {
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 7,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
								["Block"] = {
									["count"] = 1,
								},
							},
							["amount"] = 3,
						},
					},
					["RageGained"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["Dispelled"] = 0,
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
						["Physical"] = 36860,
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 18861,
									["min"] = 2995,
									["count"] = 4,
									["amount"] = 38801,
								},
							},
							["count"] = 4,
							["amount"] = 38801,
						},
					},
					["WhoHealed"] = {
					},
					["EnergyGain"] = 0,
					["CCBreak"] = 0,
					["PartialAbsorb"] = {
					},
					["ActiveTime"] = 7.37,
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 38801,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["暮色骑士希莱林"] = {
							["Details"] = {
								["挑衅重击"] = {
									["count"] = 0.38,
								},
								["肉搏"] = {
									["count"] = 6.99,
								},
							},
							["amount"] = 7.37,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["Attacks"] = {
						["挑衅重击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 163465,
									["min"] = 163465,
									["count"] = 1,
									["amount"] = 163465,
								},
								["Hit (被格挡)"] = {
									["max"] = 86006,
									["min"] = 86006,
									["count"] = 1,
									["amount"] = 86006,
								},
							},
							["count"] = 2,
							["amount"] = 249471,
						},
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 252435,
									["min"] = 252435,
									["count"] = 1,
									["amount"] = 252435,
								},
								["Hit"] = {
									["max"] = 131511,
									["min"] = 94195,
									["count"] = 6,
									["amount"] = 718327,
								},
							},
							["count"] = 7,
							["amount"] = 970762,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["暮色骑士希莱林"] = {
							["Details"] = {
								["挑衅重击"] = {
									["count"] = 249471,
								},
								["肉搏"] = {
									["count"] = 970762,
								},
							},
							["amount"] = 1220233,
						},
					},
					["TimeDamage"] = 7.37,
					["TimeDamaging"] = {
						["暮色骑士希莱林"] = {
							["Details"] = {
								["挑衅重击"] = {
									["count"] = 0.38,
								},
								["肉搏"] = {
									["count"] = 6.99,
								},
							},
							["amount"] = 7.37,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["ElementDoneBlock"] = {
						["Physical"] = 36860,
					},
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 18861,
									["min"] = 2995,
									["count"] = 8,
									["amount"] = 66074,
								},
							},
							["count"] = 8,
							["amount"] = 66074,
						},
					},
					["TimeSpent"] = {
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 9.52,
								},
							},
							["amount"] = 9.52,
						},
						["暮色骑士希莱林"] = {
							["Details"] = {
								["挑衅重击"] = {
									["count"] = 0.38,
								},
								["肉搏"] = {
									["count"] = 6.99,
								},
							},
							["amount"] = 7.37,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 16,
								},
							},
							["amount"] = 18,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 3,
								},
								["Block"] = {
									["count"] = 1,
								},
							},
							["amount"] = 4,
						},
					},
					["ElementDone"] = {
						["Melee"] = 2327795,
						["Physical"] = 391113,
					},
					["ActiveTime"] = 16.89,
					["Overhealing"] = 66074,
					["TimeDamage"] = 16.89,
					["TimeDamaging"] = {
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 9.52,
								},
							},
							["amount"] = 9.52,
						},
						["暮色骑士希莱林"] = {
							["Details"] = {
								["挑衅重击"] = {
									["count"] = 0.38,
								},
								["肉搏"] = {
									["count"] = 6.99,
								},
							},
							["amount"] = 7.37,
						},
					},
					["Attacks"] = {
						["挑衅重击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 163465,
									["min"] = 141642,
									["count"] = 2,
									["amount"] = 305107,
								},
								["Hit (被格挡)"] = {
									["max"] = 86006,
									["min"] = 86006,
									["count"] = 1,
									["amount"] = 86006,
								},
							},
							["count"] = 3,
							["amount"] = 391113,
						},
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 252435,
									["min"] = 230706,
									["count"] = 2,
									["amount"] = 483141,
								},
								["Hit"] = {
									["max"] = 137171,
									["min"] = 94195,
									["count"] = 16,
									["amount"] = 1844654,
								},
							},
							["count"] = 18,
							["amount"] = 2327795,
						},
					},
					["DamagedWho"] = {
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["挑衅重击"] = {
									["count"] = 141642,
								},
								["肉搏"] = {
									["count"] = 1357033,
								},
							},
							["amount"] = 1498675,
						},
						["暮色骑士希莱林"] = {
							["Details"] = {
								["挑衅重击"] = {
									["count"] = 249471,
								},
								["肉搏"] = {
									["count"] = 970762,
								},
							},
							["amount"] = 1220233,
						},
					},
					["Damage"] = 2718908,
				},
				["Fight3"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 1079024,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["FDamagedWho"] = {
					},
					["FAttacks"] = {
					},
					["RageGain"] = 0,
					["ElementDone"] = {
						["Melee"] = 937382,
						["Physical"] = 141642,
					},
					["ManaGainedFrom"] = {
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 7,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["RageGained"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["Dispelled"] = 0,
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 12431,
									["min"] = 3144,
									["count"] = 4,
									["amount"] = 27273,
								},
							},
							["count"] = 4,
							["amount"] = 27273,
						},
					},
					["WhoHealed"] = {
					},
					["EnergyGain"] = 0,
					["CCBreak"] = 0,
					["PartialAbsorb"] = {
					},
					["ActiveTime"] = 6.52,
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 27273,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 6.52,
								},
							},
							["amount"] = 6.52,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["Attacks"] = {
						["挑衅重击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 141642,
									["min"] = 141642,
									["count"] = 1,
									["amount"] = 141642,
								},
							},
							["count"] = 1,
							["amount"] = 141642,
						},
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 230706,
									["min"] = 230706,
									["count"] = 1,
									["amount"] = 230706,
								},
								["Hit"] = {
									["max"] = 137171,
									["min"] = 97289,
									["count"] = 6,
									["amount"] = 706676,
								},
							},
							["count"] = 7,
							["amount"] = 937382,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["挑衅重击"] = {
									["count"] = 141642,
								},
								["肉搏"] = {
									["count"] = 937382,
								},
							},
							["amount"] = 1079024,
						},
					},
					["TimeDamage"] = 6.52,
					["TimeDamaging"] = {
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 6.52,
								},
							},
							["amount"] = 6.52,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
			},
			["LastEventTimes"] = {
				12910.278, -- [1]
				12910.278, -- [2]
				12912.329, -- [3]
				12912.329, -- [4]
				12913.877, -- [5]
				12913.877, -- [6]
				12923.005, -- [7]
				12923.512, -- [8]
				12924.574, -- [9]
				12924.574, -- [10]
				12925.023, -- [11]
				12925.55, -- [12]
				12926.997, -- [13]
				12927.373, -- [14]
				12927.373, -- [15]
				12929.431, -- [16]
				12929.431, -- [17]
				12929.867, -- [18]
				12929.867, -- [19]
				12944.52, -- [20]
				12945.042, -- [21]
				12945.779, -- [22]
				12945.779, -- [23]
				12947.835, -- [24]
				12947.835, -- [25]
				12949.861, -- [26]
				12949.861, -- [27]
				12951.127, -- [28]
				12951.127, -- [29]
				12951.846, -- [30]
				12951.846, -- [31]
			},
			["LastActive"] = 12951.286,
		},
		["灰衣人"] = {
			["GUID"] = "Player-2135-084C47E5",
			["TimeLast"] = {
				["TimeHeal"] = 12922.308,
				["OVERALL"] = 13001.287,
				["Healing"] = 12909.298,
				["DamageTaken"] = 12922.308,
				["FDamage"] = 12403.297,
				["Absorbs"] = 12922.308,
				["HealingTaken"] = 12922.308,
				["Overhealing"] = 13001.287,
				["TimeDamage"] = 13001.287,
				["ActiveTime"] = 13001.287,
				["ManaGain"] = 12403.297,
				["DOT_Time"] = 12998.279,
				["Damage"] = 13001.287,
			},
			["LastAttackedBy"] = "暮色骑士希莱林",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"HEAL", -- [2]
				"DAMAGE", -- [3]
				"HEAL", -- [4]
				"DAMAGE", -- [5]
				"HEAL", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"HEAL", -- [9]
				"DAMAGE", -- [10]
				"HEAL", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"HEAL", -- [14]
				"DAMAGE", -- [15]
				"HEAL", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"HEAL", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"HEAL", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"HEAL", -- [26]
				"DAMAGE", -- [27]
				"HEAL", -- [28]
				"DAMAGE", -- [29]
				"HEAL", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"HEAL", -- [33]
				"HEAL", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"HEAL", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"HEAL", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"HEAL", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"HEAL", -- [47]
				"DAMAGE", -- [48]
				"HEAL", -- [49]
				"HEAL", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					45.56, -- [1]
				},
				["Healing"] = {
					0, -- [1]
				},
				["DamageTaken"] = {
					3525537, -- [1]
				},
				["FDamage"] = {
					1037184, -- [1]
				},
				["Absorbs"] = {
					3525537, -- [1]
				},
				["HealingTaken"] = {
					3525537, -- [1]
				},
				["Overhealing"] = {
					12108331, -- [1]
				},
				["TimeDamage"] = {
					106.92, -- [1]
				},
				["ActiveTime"] = {
					152.48, -- [1]
				},
				["ManaGain"] = {
					660002, -- [1]
				},
				["DOT_Time"] = {
					550, -- [1]
				},
				["Damage"] = {
					44648177, -- [1]
				},
			},
			["enClass"] = "WARLOCK",
			["unit"] = "灰衣人",
			["LastAbility"] = 434259.754,
			["UnitLockout"] = 12399.295,
			["LastEventHealth"] = {
				5185920, -- [1]
				5185920, -- [2]
				5185920, -- [3]
				5185920, -- [4]
				5185920, -- [5]
				5185920, -- [6]
				5185920, -- [7]
				5185920, -- [8]
				5185920, -- [9]
				5185920, -- [10]
				5185920, -- [11]
				5185920, -- [12]
				5185920, -- [13]
				5185920, -- [14]
				5185920, -- [15]
				5185920, -- [16]
				5185920, -- [17]
				5185920, -- [18]
				5185920, -- [19]
				5185920, -- [20]
				5185920, -- [21]
				5185920, -- [22]
				5185920, -- [23]
				5185920, -- [24]
				5185920, -- [25]
				5185920, -- [26]
				5185920, -- [27]
				5185920, -- [28]
				5185920, -- [29]
				5185920, -- [30]
				5185920, -- [31]
				5185920, -- [32]
				5185920, -- [33]
				5185920, -- [34]
				5185920, -- [35]
				5185920, -- [36]
				5185920, -- [37]
				5185920, -- [38]
				5185920, -- [39]
				5185920, -- [40]
				5185920, -- [41]
				5185920, -- [42]
				5185920, -- [43]
				5185920, -- [44]
				5185920, -- [45]
				5185920, -- [46]
				5185920, -- [47]
				5185920, -- [48]
				5185920, -- [49]
				5185920, -- [50]
			},
			["level"] = 110,
			["LastDamageAbility"] = "邪能冲锋",
			["LastFightIn"] = 9,
			["Fights"] = {
				["OverallData"] = {
					["DOTs"] = {
						["痛楚 (伤害/跳)"] = {
							["Details"] = {
								["暮色骑士希莱林"] = {
									["count"] = 18,
								},
								["暮色卫队邪剑士"] = {
									["count"] = 108,
								},
								["饥饿的魔犬"] = {
									["count"] = 16,
								},
								["黑石蜥蜴"] = {
									["count"] = 28,
								},
								["梅瑞戴尔滑翔者"] = {
									["count"] = 4,
								},
								["暮色卫队掠夺者"] = {
									["count"] = 28,
								},
								["狡猾的灌尾狐"] = {
									["count"] = 18,
								},
							},
							["amount"] = 220,
						},
						["痛苦无常 (伤害/跳)"] = {
							["Details"] = {
								["黑石蜥蜴"] = {
									["count"] = 9,
								},
								["暮色骑士希莱林"] = {
									["count"] = 9,
								},
								["暮色卫队邪剑士"] = {
									["count"] = 3,
								},
							},
							["amount"] = 21,
						},
						["吸取灵魂 (伤害/跳)"] = {
							["Details"] = {
								["黑石蜥蜴"] = {
									["count"] = 6,
								},
								["梅瑞戴尔滑翔者"] = {
									["count"] = 3,
								},
								["暮色卫队邪剑士"] = {
									["count"] = 6,
								},
								["暮色骑士希莱林"] = {
									["count"] = 3,
								},
							},
							["amount"] = 18,
						},
						["腐蚀术 (伤害/跳)"] = {
							["Details"] = {
								["暮色骑士希莱林"] = {
									["count"] = 21,
								},
								["暮色卫队邪剑士"] = {
									["count"] = 141,
								},
								["饥饿的魔犬"] = {
									["count"] = 24,
								},
								["黑石蜥蜴"] = {
									["count"] = 39,
								},
								["暮色卫队掠夺者"] = {
									["count"] = 42,
								},
								["狡猾的灌尾狐"] = {
									["count"] = 24,
								},
							},
							["amount"] = 291,
						},
					},
					["ElementHitsTaken"] = {
						["Fire"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 5,
								},
							},
							["amount"] = 5,
						},
						["Physical"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 10,
								},
							},
							["amount"] = 10,
						},
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 27,
								},
								["Dodge"] = {
									["count"] = 1,
								},
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 29,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 11,
								},
							},
							["amount"] = 11,
						},
					},
					["HealedWho"] = {
						["灰衣人"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 3525537,
								},
							},
							["amount"] = 3525537,
						},
					},
					["Absorbs"] = 3525537,
					["FDamagedWho"] = {
						["灰衣人"] = {
							["Details"] = {
								["生命分流"] = {
									["count"] = 1037184,
								},
							},
							["amount"] = 1037184,
						},
					},
					["ElementTaken"] = {
						["Fire"] = 1008791,
						["Physical"] = 263166,
						["Melee"] = 1839480,
						["Nature"] = 414100,
					},
					["DOT_Time"] = 550,
					["Damage"] = 44648177,
					["TimeHeal"] = 45.56,
					["ShieldedWho"] = {
						["扎克里拉"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["未知目标"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 14,
								},
							},
							["amount"] = 14,
						},
						["灰衣人"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
					},
					["FAttacks"] = {
						["生命分流"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 518592,
									["min"] = 518592,
									["count"] = 2,
									["amount"] = 1037184,
								},
							},
							["count"] = 2,
							["amount"] = 1037184,
						},
					},
					["ElementDone"] = {
						["Shadow"] = 41766356,
					},
					["ManaGainedFrom"] = {
						["灰衣人"] = {
							["Details"] = {
								["生命分流"] = {
									["count"] = 660002,
								},
							},
							["amount"] = 660002,
						},
					},
					["WhoDamaged"] = {
						["暮色卫队掠夺者"] = {
							["Details"] = {
								["邪能冲锋"] = {
									["count"] = 102129,
								},
								["魔化切割"] = {
									["count"] = 680672,
								},
								["肉搏"] = {
									["count"] = 513763,
								},
							},
							["amount"] = 1296564,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 187292,
								},
							},
							["amount"] = 187292,
						},
						["饥饿的魔犬"] = {
							["Details"] = {
								["贪食之喉"] = {
									["count"] = 147583,
								},
								["污染"] = {
									["count"] = 141361,
								},
								["肉搏"] = {
									["count"] = 93232,
								},
							},
							["amount"] = 382176,
						},
						["黑石蜥蜴"] = {
							["Details"] = {
								["酸性撕咬"] = {
									["count"] = 179048,
								},
								["肉搏"] = {
									["count"] = 501436,
								},
								["酸性撕咬 (伤害/跳)"] = {
									["count"] = 93691,
								},
							},
							["amount"] = 774175,
						},
						["梅瑞戴尔滑翔者"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 98712,
								},
								["爪掠"] = {
									["count"] = 68434,
								},
							},
							["amount"] = 167146,
						},
						["暮色骑士希莱林"] = {
							["Details"] = {
								["邪能冲锋"] = {
									["count"] = 225990,
								},
								["肉搏"] = {
									["count"] = 186594,
								},
							},
							["amount"] = 412584,
						},
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 258451,
								},
								["咆哮"] = {
									["count"] = 47149,
								},
							},
							["amount"] = 305600,
						},
					},
					["Absorbed"] = {
						["灵魂榨取"] = {
							["Details"] = {
								["灰衣人"] = {
									["max"] = 341405,
									["min"] = 13300,
									["count"] = 53,
									["amount"] = 3525537,
								},
							},
							["count"] = 53,
							["amount"] = 3525537,
						},
					},
					["TimeHealing"] = {
						["灰衣人"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 45.56,
								},
							},
							["amount"] = 45.56,
						},
					},
					["OverHeals"] = {
						["混沌黑暗"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 891951,
									["min"] = 891951,
									["count"] = 1,
									["amount"] = 891951,
								},
								["Hit"] = {
									["max"] = 612422,
									["min"] = 199482,
									["count"] = 7,
									["amount"] = 3323851,
								},
							},
							["count"] = 8,
							["amount"] = 4215802,
						},
						["灵魂之镰"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 329230,
									["min"] = 16534,
									["count"] = 10,
									["amount"] = 1501821,
								},
							},
							["count"] = 10,
							["amount"] = 1501821,
						},
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 55904,
									["min"] = 520,
									["count"] = 83,
									["amount"] = 1422167,
								},
							},
							["count"] = 83,
							["amount"] = 1422167,
						},
						["奇怪的感觉"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 259296,
									["min"] = 103719,
									["count"] = 4,
									["amount"] = 674171,
								},
							},
							["count"] = 4,
							["amount"] = 674171,
						},
						["吸取灵魂"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1201071,
									["min"] = 308617,
									["count"] = 6,
									["amount"] = 4294370,
								},
							},
							["count"] = 6,
							["amount"] = 4294370,
						},
					},
					["PartialResist"] = {
						["邪能冲锋"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 3,
						},
						["酸性撕咬"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["爪掠"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 29,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 29,
						},
						["酸性撕咬 (伤害/跳)"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 6,
						},
						["魔化切割"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["贪食之喉"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 8,
						},
						["污染"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 3,
						},
						["咆哮"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
					},
					["ManaGained"] = {
						["生命分流"] = {
							["Details"] = {
								["灰衣人"] = {
									["count"] = 660002,
								},
							},
							["amount"] = 660002,
						},
					},
					["FDamage"] = 1037184,
					["ActiveTime"] = 152.48,
					["Heals"] = {
						["灵魂榨取"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 341405,
									["min"] = 13300,
									["count"] = 53,
									["amount"] = 3525537,
								},
							},
							["count"] = 53,
							["amount"] = 3525537,
						},
					},
					["WhoHealed"] = {
						["灰衣人"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 3525537,
								},
							},
							["amount"] = 3525537,
						},
					},
					["ElementTakenAbsorb"] = {
						["Fire"] = 1008791,
						["Physical"] = 263166,
						["Melee"] = 1839480,
						["Nature"] = 414100,
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 158,
								},
								["Hit"] = {
									["count"] = 43,
								},
								["Crit"] = {
									["count"] = 70,
								},
								["Evade"] = {
									["count"] = 1,
								},
							},
							["amount"] = 272,
						},
					},
					["Healing"] = 0,
					["PartialAbsorb"] = {
						["邪能冲锋"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 126084,
									["min"] = 99906,
									["count"] = 3,
									["amount"] = 328119,
								},
							},
							["count"] = 3,
							["amount"] = 328119,
						},
						["酸性撕咬"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 98307,
									["min"] = 80741,
									["count"] = 2,
									["amount"] = 179048,
								},
							},
							["count"] = 2,
							["amount"] = 179048,
						},
						["爪掠"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 68434,
									["min"] = 68434,
									["count"] = 1,
									["amount"] = 68434,
								},
							},
							["count"] = 1,
							["amount"] = 68434,
						},
						["肉搏"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 120058,
									["min"] = 42809,
									["count"] = 27,
									["amount"] = 1839480,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 29,
							["amount"] = 1839480,
						},
						["酸性撕咬 (伤害/跳)"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 16678,
									["min"] = 13300,
									["count"] = 6,
									["amount"] = 93691,
								},
							},
							["count"] = 6,
							["amount"] = 93691,
						},
						["魔化切割"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 341405,
									["min"] = 339267,
									["count"] = 2,
									["amount"] = 680672,
								},
							},
							["count"] = 2,
							["amount"] = 680672,
						},
						["贪食之喉"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 19432,
									["min"] = 17464,
									["count"] = 8,
									["amount"] = 147583,
								},
							},
							["count"] = 8,
							["amount"] = 147583,
						},
						["污染"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 55247,
									["min"] = 39653,
									["count"] = 3,
									["amount"] = 141361,
								},
							},
							["count"] = 3,
							["amount"] = 141361,
						},
						["咆哮"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 47149,
									["min"] = 47149,
									["count"] = 1,
									["amount"] = 47149,
								},
							},
							["count"] = 1,
							["amount"] = 47149,
						},
					},
					["TimeSpent"] = {
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 3.82,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 2.48,
								},
								["暗影之刃"] = {
									["count"] = 0.28,
								},
							},
							["amount"] = 6.58,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["暗影之刃"] = {
									["count"] = 0.8,
								},
								["吸取灵魂 (伤害/跳)"] = {
									["count"] = 0.12,
								},
								["痛苦无常 (伤害/跳)"] = {
									["count"] = 0.24,
								},
								["灵魂之镰"] = {
									["count"] = 1.32,
								},
								["痛楚 (伤害/跳)"] = {
									["count"] = 21.95,
								},
								["灵魂烈焰"] = {
									["count"] = 0.18,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 18.79,
								},
								["延绵恐惧"] = {
									["count"] = 1.08,
								},
							},
							["amount"] = 44.48,
						},
						["饥饿的魔犬"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 2.77,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 1.09,
								},
							},
							["amount"] = 3.86,
						},
						["暮色卫队掠夺者"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 3.09,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 2.32,
								},
							},
							["amount"] = 5.41,
						},
						["黑石蜥蜴"] = {
							["Details"] = {
								["暗影之刃"] = {
									["count"] = 3.47,
								},
								["混沌黑暗"] = {
									["count"] = 0.21,
								},
								["吸取灵魂 (伤害/跳)"] = {
									["count"] = 0.28,
								},
								["灵魂之镰"] = {
									["count"] = 0.27,
								},
								["痛苦无常 (伤害/跳)"] = {
									["count"] = 1.5,
								},
								["痛楚 (伤害/跳)"] = {
									["count"] = 7.43,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 7.87,
								},
								["延绵恐惧"] = {
									["count"] = 0.73,
								},
							},
							["amount"] = 21.76,
						},
						["焰光蛾"] = {
							["Details"] = {
								["暗影之刃"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["梅瑞戴尔滑翔者"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 2.97,
								},
								["吸取灵魂 (伤害/跳)"] = {
									["count"] = 0.84,
								},
								["暗影之刃"] = {
									["count"] = 1.21,
								},
							},
							["amount"] = 5.02,
						},
						["暮色骑士希莱林"] = {
							["Details"] = {
								["暗影之刃"] = {
									["count"] = 1.77,
								},
								["痛楚"] = {
									["count"] = 1.5,
								},
								["痛楚 (伤害/跳)"] = {
									["count"] = 4.57,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 6.47,
								},
								["痛苦无常 (伤害/跳)"] = {
									["count"] = 1,
								},
							},
							["amount"] = 15.31,
						},
						["灰衣人"] = {
							["Details"] = {
								["生命分流"] = {
									["count"] = 3,
								},
								["灵魂榨取"] = {
									["count"] = 45.56,
								},
							},
							["amount"] = 48.56,
						},
					},
					["Attacks"] = {
						["撕扯灵魂"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 279567,
									["min"] = 279567,
									["count"] = 1,
									["amount"] = 279567,
								},
							},
							["count"] = 1,
							["amount"] = 279567,
						},
						["混沌黑暗"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1457119,
									["min"] = 722643,
									["count"] = 2,
									["amount"] = 2179762,
								},
								["Hit"] = {
									["max"] = 751755,
									["min"] = 208512,
									["count"] = 6,
									["amount"] = 2629320,
								},
							},
							["count"] = 8,
							["amount"] = 4809082,
						},
						["灵魂之镰"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 329230,
									["min"] = 121147,
									["count"] = 10,
									["amount"] = 1834534,
								},
							},
							["count"] = 10,
							["amount"] = 1834534,
						},
						["延绵恐惧"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 328027,
									["min"] = 89143,
									["count"] = 2,
									["amount"] = 417170,
								},
								["Hit"] = {
									["max"] = 40519,
									["min"] = 34732,
									["count"] = 2,
									["amount"] = 75251,
								},
							},
							["count"] = 4,
							["amount"] = 492421,
						},
						["痛楚 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 278787,
									["min"] = 33945,
									["count"] = 27,
									["amount"] = 2918464,
								},
								["Tick"] = {
									["max"] = 129922,
									["min"] = 15020,
									["count"] = 83,
									["amount"] = 3723862,
								},
							},
							["count"] = 110,
							["amount"] = 6642326,
						},
						["痛苦无常 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 776273,
									["min"] = 506512,
									["count"] = 4,
									["amount"] = 2676714,
								},
								["Tick"] = {
									["max"] = 352472,
									["min"] = 239087,
									["count"] = 3,
									["amount"] = 867832,
								},
							},
							["count"] = 7,
							["amount"] = 3544546,
						},
						["吸取灵魂 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 461950,
									["min"] = 395256,
									["count"] = 3,
									["amount"] = 1304322,
								},
								["Tick"] = {
									["max"] = 242788,
									["min"] = 134181,
									["count"] = 3,
									["amount"] = 516719,
								},
							},
							["count"] = 6,
							["amount"] = 1821041,
						},
						["暗影之刃"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 435099,
									["min"] = 252489,
									["count"] = 4,
									["amount"] = 1255036,
								},
								["Hit"] = {
									["max"] = 205250,
									["min"] = 107725,
									["count"] = 24,
									["amount"] = 3451178,
								},
							},
							["count"] = 28,
							["amount"] = 4706214,
						},
						["灵魂烈焰"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 668592,
									["min"] = 223656,
									["count"] = 5,
									["amount"] = 1912657,
								},
								["Hit"] = {
									["max"] = 130463,
									["min"] = 111827,
									["count"] = 8,
									["amount"] = 969164,
								},
							},
							["count"] = 13,
							["amount"] = 2881821,
						},
						["腐蚀术 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 587259,
									["min"] = 223202,
									["count"] = 28,
									["amount"] = 8889446,
								},
								["Tick"] = {
									["max"] = 243806,
									["min"] = 98762,
									["count"] = 69,
									["amount"] = 8747179,
								},
							},
							["count"] = 97,
							["amount"] = 17636625,
						},
						["痛楚"] = {
							["Details"] = {
								["Evade"] = {
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 3525537,
					["DamageTaken"] = 3525537,
					["TimeDamage"] = 106.92,
					["TimeDamaging"] = {
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 3.82,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 2.48,
								},
								["暗影之刃"] = {
									["count"] = 0.28,
								},
							},
							["amount"] = 6.58,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["暗影之刃"] = {
									["count"] = 0.8,
								},
								["吸取灵魂 (伤害/跳)"] = {
									["count"] = 0.12,
								},
								["痛苦无常 (伤害/跳)"] = {
									["count"] = 0.24,
								},
								["灵魂之镰"] = {
									["count"] = 1.32,
								},
								["痛楚 (伤害/跳)"] = {
									["count"] = 21.95,
								},
								["灵魂烈焰"] = {
									["count"] = 0.18,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 18.79,
								},
								["延绵恐惧"] = {
									["count"] = 1.08,
								},
							},
							["amount"] = 44.48,
						},
						["饥饿的魔犬"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 2.77,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 1.09,
								},
							},
							["amount"] = 3.86,
						},
						["暮色卫队掠夺者"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 3.09,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 2.32,
								},
							},
							["amount"] = 5.41,
						},
						["黑石蜥蜴"] = {
							["Details"] = {
								["暗影之刃"] = {
									["count"] = 3.47,
								},
								["混沌黑暗"] = {
									["count"] = 0.21,
								},
								["吸取灵魂 (伤害/跳)"] = {
									["count"] = 0.28,
								},
								["灵魂之镰"] = {
									["count"] = 0.27,
								},
								["痛苦无常 (伤害/跳)"] = {
									["count"] = 1.5,
								},
								["痛楚 (伤害/跳)"] = {
									["count"] = 7.43,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 7.87,
								},
								["延绵恐惧"] = {
									["count"] = 0.73,
								},
							},
							["amount"] = 21.76,
						},
						["焰光蛾"] = {
							["Details"] = {
								["暗影之刃"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["梅瑞戴尔滑翔者"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 2.97,
								},
								["吸取灵魂 (伤害/跳)"] = {
									["count"] = 0.84,
								},
								["暗影之刃"] = {
									["count"] = 1.21,
								},
							},
							["amount"] = 5.02,
						},
						["暮色骑士希莱林"] = {
							["Details"] = {
								["暗影之刃"] = {
									["count"] = 1.77,
								},
								["痛楚"] = {
									["count"] = 1.5,
								},
								["痛楚 (伤害/跳)"] = {
									["count"] = 4.57,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 6.47,
								},
								["痛苦无常 (伤害/跳)"] = {
									["count"] = 1,
								},
							},
							["amount"] = 15.31,
						},
						["灰衣人"] = {
							["Details"] = {
								["生命分流"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["ManaGain"] = 660002,
					["Overhealing"] = 12108331,
					["DamagedWho"] = {
						["暮色卫队掠夺者"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 763633,
								},
								["灵魂烈焰"] = {
									["count"] = 577773,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 2425552,
								},
							},
							["amount"] = 3766958,
						},
						["暮色骑士希莱林"] = {
							["Details"] = {
								["暗影之刃"] = {
									["count"] = 1477362,
								},
								["混沌黑暗"] = {
									["count"] = 960267,
								},
								["痛楚 (伤害/跳)"] = {
									["count"] = 695593,
								},
								["痛苦无常 (伤害/跳)"] = {
									["count"] = 1299745,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 1962809,
								},
								["吸取灵魂 (伤害/跳)"] = {
									["count"] = 242788,
								},
							},
							["amount"] = 6638564,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["混沌黑暗"] = {
									["count"] = 1764328,
								},
								["灵魂之镰"] = {
									["count"] = 1410995,
								},
								["延绵恐惧"] = {
									["count"] = 368546,
								},
								["暗影之刃"] = {
									["count"] = 254810,
								},
								["吸取灵魂 (伤害/跳)"] = {
									["count"] = 529437,
								},
								["痛楚 (伤害/跳)"] = {
									["count"] = 3334761,
								},
								["灵魂烈焰"] = {
									["count"] = 964486,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 7984098,
								},
								["痛苦无常 (伤害/跳)"] = {
									["count"] = 776273,
								},
							},
							["amount"] = 17387734,
						},
						["饥饿的魔犬"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 668009,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 1195212,
								},
								["灵魂之镰"] = {
									["count"] = 141334,
								},
							},
							["amount"] = 2004555,
						},
						["焰光蛾"] = {
							["Details"] = {
								["暗影之刃"] = {
									["count"] = 135623,
								},
							},
							["amount"] = 135623,
						},
						["梅瑞戴尔滑翔者"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 38673,
								},
								["暗影之刃"] = {
									["count"] = 563326,
								},
								["吸取灵魂 (伤害/跳)"] = {
									["count"] = 139750,
								},
								["撕扯灵魂"] = {
									["count"] = 279567,
								},
							},
							["amount"] = 1021316,
						},
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["暗影之刃"] = {
									["count"] = 350210,
								},
								["混沌黑暗"] = {
									["count"] = 1457119,
								},
								["灵魂烈焰"] = {
									["count"] = 670970,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 1067503,
								},
								["痛楚 (伤害/跳)"] = {
									["count"] = 287321,
								},
							},
							["amount"] = 3833123,
						},
						["黑石蜥蜴"] = {
							["Details"] = {
								["混沌黑暗"] = {
									["count"] = 627368,
								},
								["灵魂之镰"] = {
									["count"] = 282205,
								},
								["延绵恐惧"] = {
									["count"] = 123875,
								},
								["痛楚 (伤害/跳)"] = {
									["count"] = 854336,
								},
								["痛苦无常 (伤害/跳)"] = {
									["count"] = 1468528,
								},
								["吸取灵魂 (伤害/跳)"] = {
									["count"] = 909066,
								},
								["灵魂烈焰"] = {
									["count"] = 668592,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 3001451,
								},
								["暗影之刃"] = {
									["count"] = 1924883,
								},
							},
							["amount"] = 9860304,
						},
					},
				},
				["Fight5"] = {
					["DOTs"] = {
						["痛楚 (伤害/跳)"] = {
							["Details"] = {
								["黑石蜥蜴"] = {
									["count"] = 0,
								},
								["暮色卫队邪剑士"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["腐蚀术 (伤害/跳)"] = {
							["Details"] = {
								["黑石蜥蜴"] = {
									["count"] = 0,
								},
								["暮色卫队邪剑士"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["痛苦无常 (伤害/跳)"] = {
							["Details"] = {
								["黑石蜥蜴"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["HealedWho"] = {
						["灰衣人"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Absorbs"] = 0,
					["FDamagedWho"] = {
						["灰衣人"] = {
							["Details"] = {
								["生命分流"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTaken"] = {
						["Melee"] = 0,
						["Nature"] = 0,
					},
					["DOT_Time"] = 12,
					["Damage"] = 1573282,
					["TimeHeal"] = 0,
					["ShieldedWho"] = {
						["扎克里拉"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["未知目标"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["灰衣人"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["FAttacks"] = {
						["生命分流"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Shadow"] = 1573282,
					},
					["ManaGainedFrom"] = {
						["灰衣人"] = {
							["Details"] = {
								["生命分流"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDamaged"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["酸性撕咬"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
								["酸性撕咬 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Absorbed"] = {
						["灵魂榨取"] = {
							["Details"] = {
								["灰衣人"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["TimeHealing"] = {
						["灰衣人"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 17732,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 50027,
								},
							},
							["count"] = 4,
							["amount"] = 50027,
						},
						["混沌黑暗"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 574305,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 574305,
								},
							},
							["count"] = 1,
							["amount"] = 574305,
						},
						["奇怪的感觉"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["灵魂之镰"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 282207,
									["min"] = 282207,
									["count"] = 1,
									["amount"] = 282207,
								},
							},
							["count"] = 1,
							["amount"] = 282207,
						},
					},
					["PartialResist"] = {
						["酸性撕咬"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["酸性撕咬 (伤害/跳)"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
						["生命分流"] = {
							["Details"] = {
								["灰衣人"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["FDamage"] = 0,
					["ActiveTime"] = 4.57,
					["Heals"] = {
						["灵魂榨取"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
						["灰衣人"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 0,
						["Nature"] = 0,
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 7,
						},
					},
					["Healing"] = 0,
					["PartialAbsorb"] = {
						["酸性撕咬"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["酸性撕咬 (伤害/跳)"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["TimeSpent"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["暗影之刃"] = {
									["count"] = 0,
								},
								["混沌黑暗"] = {
									["count"] = 0,
								},
								["痛苦无常 (伤害/跳)"] = {
									["count"] = 0,
								},
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
								["延绵恐惧"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 1.91,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 2.4,
								},
								["灵魂之镰"] = {
									["count"] = 0.26,
								},
							},
							["amount"] = 4.57,
						},
						["灰衣人"] = {
							["Details"] = {
								["生命分流"] = {
									["count"] = 0,
								},
								["灵魂榨取"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["暗影之刃"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["混沌黑暗"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 485926,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 485926,
								},
							},
							["count"] = 1,
							["amount"] = 485926,
						},
						["痛苦无常 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["灵魂之镰"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 282207,
									["min"] = 282207,
									["count"] = 1,
									["amount"] = 282207,
								},
							},
							["count"] = 1,
							["amount"] = 282207,
						},
						["痛楚 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 153071,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 235460,
								},
								["Tick"] = {
									["max"] = 21796,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 21796,
								},
							},
							["count"] = 3,
							["amount"] = 257256,
						},
						["灵魂烈焰"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["腐蚀术 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 404572,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 404572,
								},
								["Tick"] = {
									["max"] = 143321,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 143321,
								},
							},
							["count"] = 2,
							["amount"] = 547893,
						},
						["延绵恐惧"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["DamageTaken"] = 0,
					["TimeDamage"] = 4.57,
					["TimeDamaging"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["暗影之刃"] = {
									["count"] = 0,
								},
								["混沌黑暗"] = {
									["count"] = 0,
								},
								["痛苦无常 (伤害/跳)"] = {
									["count"] = 0,
								},
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
								["延绵恐惧"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 1.91,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 2.4,
								},
								["灵魂之镰"] = {
									["count"] = 0.26,
								},
							},
							["amount"] = 4.57,
						},
						["灰衣人"] = {
							["Details"] = {
								["生命分流"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["Overhealing"] = 906539,
					["DamagedWho"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["暗影之刃"] = {
									["count"] = 0,
								},
								["混沌黑暗"] = {
									["count"] = 0,
								},
								["痛苦无常 (伤害/跳)"] = {
									["count"] = 0,
								},
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["灵魂烈焰"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
								["延绵恐惧"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 257256,
								},
								["混沌黑暗"] = {
									["count"] = 485926,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 547893,
								},
								["灵魂之镰"] = {
									["count"] = 282207,
								},
							},
							["amount"] = 1573282,
						},
					},
				},
				["CurrentFightData"] = {
					["Ressed"] = 0,
					["DOTs"] = {
						["痛楚 (伤害/跳)"] = {
							["Details"] = {
								["暮色卫队掠夺者"] = {
									["count"] = 0,
								},
								["狡猾的灌尾狐"] = {
									["count"] = 0,
								},
								["暮色卫队邪剑士"] = {
									["count"] = 0,
								},
								["饥饿的魔犬"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["腐蚀术 (伤害/跳)"] = {
							["Details"] = {
								["暮色卫队掠夺者"] = {
									["count"] = 0,
								},
								["狡猾的灌尾狐"] = {
									["count"] = 0,
								},
								["暮色卫队邪剑士"] = {
									["count"] = 0,
								},
								["饥饿的魔犬"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["痛苦无常 (伤害/跳)"] = {
							["Details"] = {
								["暮色卫队邪剑士"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RageGainedFrom"] = {
					},
					["ElementDoneResist"] = {
					},
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Fire"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
								["Dodge"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamageTaken"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["Absorbs"] = 0,
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ManaGain"] = 0,
					["Damage"] = 0,
					["ElementTaken"] = {
						["Physical"] = 0,
						["Fire"] = 0,
						["Melee"] = 0,
						["Nature"] = 0,
					},
					["HOTs"] = {
					},
					["ElementTakenBlock"] = {
					},
					["PartialBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["RageGained"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["ManaGainedFrom"] = {
					},
					["ElementDone"] = {
						["Shadow"] = 0,
					},
					["DamagedWho"] = {
						["暮色卫队掠夺者"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["灵魂烈焰"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["灵魂烈焰"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗影之刃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["混沌黑暗"] = {
									["count"] = 0,
								},
								["灵魂之镰"] = {
									["count"] = 0,
								},
								["痛苦无常 (伤害/跳)"] = {
									["count"] = 0,
								},
								["灵魂烈焰"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
								["延绵恐惧"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["饥饿的魔犬"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
								["灵魂之镰"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Absorbed"] = {
						["灵魂榨取"] = {
							["Details"] = {
								["灰衣人"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoDamaged"] = {
						["暮色卫队掠夺者"] = {
							["Details"] = {
								["邪能冲锋"] = {
									["count"] = 0,
								},
								["魔化切割"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
								["咆哮"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["饥饿的魔犬"] = {
							["Details"] = {
								["贪食之喉"] = {
									["count"] = 0,
								},
								["污染"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["混沌黑暗"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["奇怪的感觉"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["灵魂之镰"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["灰衣人"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Dispelled"] = 0,
					["HealedWho"] = {
						["灰衣人"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialResist"] = {
						["邪能冲锋"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["魔化切割"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["贪食之喉"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["污染"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["咆哮"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["CCBreak"] = 0,
					["FDamage"] = 0,
					["ActiveTime"] = 0,
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
						["Physical"] = 0,
						["Fire"] = 0,
						["Melee"] = 0,
						["Nature"] = 0,
					},
					["Interrupts"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["TimeSpent"] = {
						["暮色卫队掠夺者"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["痛苦无常 (伤害/跳)"] = {
									["count"] = 0,
								},
								["灵魂之镰"] = {
									["count"] = 0,
								},
								["灵魂烈焰"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
								["延绵恐惧"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["饥饿的魔犬"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗影之刃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["灰衣人"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["Overhealing"] = 0,
					["Heals"] = {
						["灵魂榨取"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["邪能冲锋"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["魔化切割"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["贪食之喉"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["污染"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["咆哮"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["EnergyGained"] = {
					},
					["WhoHealed"] = {
						["灰衣人"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["CCBroken"] = {
					},
					["Attacks"] = {
						["痛楚 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["混沌黑暗"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["痛苦无常 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["灵魂之镰"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗影之刃"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["灵魂烈焰"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["腐蚀术 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["延绵恐惧"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["暮色卫队掠夺者"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗影之刃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["痛苦无常 (伤害/跳)"] = {
									["count"] = 0,
								},
								["灵魂之镰"] = {
									["count"] = 0,
								},
								["灵魂烈焰"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
								["延绵恐惧"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["饥饿的魔犬"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGain"] = 0,
					["DOT_Time"] = 0,
					["DispelledWho"] = {
					},
				},
				["Fight4"] = {
					["Ressed"] = 0,
					["DOTs"] = {
						["痛楚 (伤害/跳)"] = {
							["Details"] = {
								["黑石蜥蜴"] = {
									["count"] = 0,
								},
								["暮色骑士希莱林"] = {
									["count"] = 10,
								},
							},
							["amount"] = 10,
						},
						["吸取灵魂 (伤害/跳)"] = {
							["Details"] = {
								["黑石蜥蜴"] = {
									["count"] = 0,
								},
								["暮色骑士希莱林"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["痛苦无常 (伤害/跳)"] = {
							["Details"] = {
								["黑石蜥蜴"] = {
									["count"] = 0,
								},
								["暮色骑士希莱林"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["腐蚀术 (伤害/跳)"] = {
							["Details"] = {
								["黑石蜥蜴"] = {
									["count"] = 0,
								},
								["暮色骑士希莱林"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
					},
					["RageGainedFrom"] = {
					},
					["ElementDoneResist"] = {
					},
					["ElementHitsTaken"] = {
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Fire"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DamageTaken"] = 99906,
					["ElementDoneAbsorb"] = {
					},
					["Absorbs"] = 99906,
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ManaGain"] = 0,
					["Damage"] = 2967268,
					["ElementTaken"] = {
						["Nature"] = 0,
						["Fire"] = 99906,
					},
					["HOTs"] = {
					},
					["ElementTakenBlock"] = {
					},
					["PartialBlock"] = {
					},
					["TimeHeal"] = 1.5,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["RageGained"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["ManaGainedFrom"] = {
					},
					["ElementDone"] = {
						["Shadow"] = 2967268,
					},
					["DamagedWho"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["混沌黑暗"] = {
									["count"] = 0,
								},
								["吸取灵魂 (伤害/跳)"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
								["痛苦无常 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色骑士希莱林"] = {
							["Details"] = {
								["暗影之刃"] = {
									["count"] = 126772,
								},
								["混沌黑暗"] = {
									["count"] = 208512,
								},
								["痛楚 (伤害/跳)"] = {
									["count"] = 296786,
								},
								["痛苦无常 (伤害/跳)"] = {
									["count"] = 628745,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 1463665,
								},
								["吸取灵魂 (伤害/跳)"] = {
									["count"] = 242788,
								},
							},
							["amount"] = 2967268,
						},
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 3,
								},
								["Tick"] = {
									["count"] = 9,
								},
							},
							["amount"] = 14,
						},
					},
					["Absorbed"] = {
						["灵魂榨取"] = {
							["Details"] = {
								["灰衣人"] = {
									["max"] = 99906,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 99906,
								},
							},
							["count"] = 1,
							["amount"] = 99906,
						},
					},
					["WhoDamaged"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["酸性撕咬 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色骑士希莱林"] = {
							["Details"] = {
								["邪能冲锋"] = {
									["count"] = 99906,
								},
							},
							["amount"] = 99906,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 30981,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 94353,
								},
							},
							["count"] = 6,
							["amount"] = 94353,
						},
						["混沌黑暗"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 501881,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 501881,
								},
							},
							["count"] = 1,
							["amount"] = 501881,
						},
						["吸取灵魂"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 631250,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 631250,
								},
							},
							["count"] = 1,
							["amount"] = 631250,
						},
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["灰衣人"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["Dispelled"] = 0,
					["HealedWho"] = {
						["灰衣人"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 99906,
								},
							},
							["amount"] = 99906,
						},
					},
					["PartialResist"] = {
						["邪能冲锋"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["酸性撕咬 (伤害/跳)"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["CCBreak"] = 0,
					["FDamage"] = 0,
					["ActiveTime"] = 9.16,
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
						["Nature"] = 0,
						["Fire"] = 99906,
					},
					["Interrupts"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["TimeSpent"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["混沌黑暗"] = {
									["count"] = 0,
								},
								["吸取灵魂 (伤害/跳)"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
								["痛苦无常 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色骑士希莱林"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 2.19,
								},
								["暗影之刃"] = {
									["count"] = 0.32,
								},
								["痛苦无常 (伤害/跳)"] = {
									["count"] = 0.53,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 4.62,
								},
							},
							["amount"] = 7.66,
						},
						["灰衣人"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["WhoDispelled"] = {
					},
					["Overhealing"] = 1227484,
					["Heals"] = {
						["灵魂榨取"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 99906,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 99906,
								},
							},
							["count"] = 1,
							["amount"] = 99906,
						},
					},
					["PartialAbsorb"] = {
						["邪能冲锋"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 99906,
									["min"] = 99906,
									["count"] = 1,
									["amount"] = 99906,
								},
							},
							["count"] = 1,
							["amount"] = 99906,
						},
						["酸性撕咬 (伤害/跳)"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["EnergyGained"] = {
					},
					["WhoHealed"] = {
						["灰衣人"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 99906,
								},
							},
							["amount"] = 99906,
						},
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["CCBroken"] = {
					},
					["Attacks"] = {
						["痛楚 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 114190,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 296786,
								},
							},
							["count"] = 5,
							["amount"] = 296786,
						},
						["混沌黑暗"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 208512,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 208512,
								},
							},
							["count"] = 1,
							["amount"] = 208512,
						},
						["吸取灵魂 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 242788,
									["min"] = 242788,
									["count"] = 1,
									["amount"] = 242788,
								},
							},
							["count"] = 1,
							["amount"] = 242788,
						},
						["痛苦无常 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 352472,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 628745,
								},
							},
							["count"] = 2,
							["amount"] = 628745,
						},
						["腐蚀术 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 421353,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 1264059,
								},
								["Tick"] = {
									["max"] = 199606,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 199606,
								},
							},
							["count"] = 4,
							["amount"] = 1463665,
						},
						["暗影之刃"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 126772,
									["min"] = 126772,
									["count"] = 1,
									["amount"] = 126772,
								},
							},
							["count"] = 1,
							["amount"] = 126772,
						},
					},
					["HealingTaken"] = 99906,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 7.66,
					["TimeDamaging"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["混沌黑暗"] = {
									["count"] = 0,
								},
								["吸取灵魂 (伤害/跳)"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
								["痛苦无常 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色骑士希莱林"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 2.19,
								},
								["暗影之刃"] = {
									["count"] = 0.32,
								},
								["痛苦无常 (伤害/跳)"] = {
									["count"] = 0.53,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 4.62,
								},
							},
							["amount"] = 7.66,
						},
					},
					["RunicPowerGain"] = 0,
					["DOT_Time"] = 31,
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["Ressed"] = 0,
					["DOTs"] = {
						["痛楚 (伤害/跳)"] = {
							["Details"] = {
								["暮色卫队邪剑士"] = {
									["count"] = 0,
								},
								["梅瑞戴尔滑翔者"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["腐蚀术 (伤害/跳)"] = {
							["Details"] = {
								["暮色卫队邪剑士"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["吸取灵魂 (伤害/跳)"] = {
							["Details"] = {
								["暮色卫队邪剑士"] = {
									["count"] = 0,
								},
								["梅瑞戴尔滑翔者"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RageGainedFrom"] = {
					},
					["ElementDoneResist"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamageTaken"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["Absorbs"] = 0,
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ManaGain"] = 0,
					["Damage"] = 0,
					["ElementTaken"] = {
						["Melee"] = 0,
						["Physical"] = 0,
					},
					["HOTs"] = {
					},
					["ElementTakenBlock"] = {
					},
					["PartialBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["RageGained"] = {
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["ManaGainedFrom"] = {
					},
					["ElementDone"] = {
						["Shadow"] = 0,
					},
					["DamagedWho"] = {
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["混沌黑暗"] = {
									["count"] = 0,
								},
								["灵魂之镰"] = {
									["count"] = 0,
								},
								["吸取灵魂 (伤害/跳)"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗影之刃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["梅瑞戴尔滑翔者"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗影之刃"] = {
									["count"] = 0,
								},
								["吸取灵魂 (伤害/跳)"] = {
									["count"] = 0,
								},
								["撕扯灵魂"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Absorbed"] = {
						["灵魂榨取"] = {
							["Details"] = {
								["灰衣人"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoDamaged"] = {
						["梅瑞戴尔滑翔者"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
								["爪掠"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["混沌黑暗"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["吸取灵魂"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["灵魂之镰"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["灰衣人"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Dispelled"] = 0,
					["HealedWho"] = {
						["灰衣人"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["爪掠"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["CCBreak"] = 0,
					["FDamage"] = 0,
					["ActiveTime"] = 0,
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 0,
						["Physical"] = 0,
					},
					["Interrupts"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["TimeSpent"] = {
						["梅瑞戴尔滑翔者"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["吸取灵魂 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗影之刃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["吸取灵魂 (伤害/跳)"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗影之刃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["灰衣人"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["Overhealing"] = 0,
					["Heals"] = {
						["灵魂榨取"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["爪掠"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["EnergyGained"] = {
					},
					["WhoHealed"] = {
						["灰衣人"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["CCBroken"] = {
					},
					["Attacks"] = {
						["痛楚 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["混沌黑暗"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["灵魂之镰"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["吸取灵魂 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗影之刃"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["腐蚀术 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["撕扯灵魂"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["FDamagedWho"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["吸取灵魂 (伤害/跳)"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗影之刃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["梅瑞戴尔滑翔者"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["吸取灵魂 (伤害/跳)"] = {
									["count"] = 0,
								},
								["暗影之刃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGain"] = 0,
					["DOT_Time"] = 0,
					["DispelledWho"] = {
					},
				},
				["Fight2"] = {
					["Ressed"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["DOTs"] = {
						["痛楚 (伤害/跳)"] = {
							["Details"] = {
								["暮色骑士希莱林"] = {
									["count"] = 0,
								},
								["狡猾的灌尾狐"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["腐蚀术 (伤害/跳)"] = {
							["Details"] = {
								["暮色骑士希莱林"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["痛苦无常 (伤害/跳)"] = {
							["Details"] = {
								["暮色骑士希莱林"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["ElementDoneResist"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Fire"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamageTaken"] = 0,
					["ElementTakenResist"] = {
					},
					["Absorbs"] = 0,
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["Damage"] = 0,
					["ElementTaken"] = {
						["Melee"] = 0,
						["Fire"] = 0,
					},
					["DOT_Time"] = 0,
					["ElementTakenBlock"] = {
					},
					["FDamagedWho"] = {
					},
					["TimeHeal"] = 0,
					["ShieldedWho"] = {
						["扎克里拉"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["未知目标"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["灰衣人"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Dispels"] = 0,
					["RageGain"] = 0,
					["WhoHealed"] = {
						["灰衣人"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["FAttacks"] = {
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Evade"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Tick"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Shadow"] = 0,
					},
					["Absorbed"] = {
						["灵魂榨取"] = {
							["Details"] = {
								["灰衣人"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGainedFrom"] = {
					},
					["CCBroken"] = {
					},
					["WhoDamaged"] = {
						["暮色骑士希莱林"] = {
							["Details"] = {
								["邪能冲锋"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["Dispelled"] = 0,
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["灰衣人"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["混沌黑暗"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["奇怪的感觉"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["RessedWho"] = {
					},
					["EnergyGain"] = 0,
					["CCBreak"] = 0,
					["PartialAbsorb"] = {
						["邪能冲锋"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 0,
					["PartialResist"] = {
						["邪能冲锋"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 0,
						["Fire"] = 0,
					},
					["Interrupts"] = 0,
					["InterruptData"] = {
					},
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["焰光蛾"] = {
							["Details"] = {
								["暗影之刃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色骑士希莱林"] = {
							["Details"] = {
								["暗影之刃"] = {
									["count"] = 0,
								},
								["痛楚"] = {
									["count"] = 0,
								},
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
								["痛苦无常 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["灰衣人"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["FDamage"] = 0,
					["Heals"] = {
						["灵魂榨取"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealedWho"] = {
						["灰衣人"] = {
							["Details"] = {
								["灵魂榨取"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGained"] = {
					},
					["RunicPowerGained"] = {
					},
					["Healing"] = 0,
					["DamagedWho"] = {
						["焰光蛾"] = {
							["Details"] = {
								["暗影之刃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色骑士希莱林"] = {
							["Details"] = {
								["暗影之刃"] = {
									["count"] = 0,
								},
								["混沌黑暗"] = {
									["count"] = 0,
								},
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
								["痛苦无常 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["混沌黑暗"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RageGained"] = {
					},
					["Attacks"] = {
						["痛楚 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["混沌黑暗"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["痛楚"] = {
							["Details"] = {
								["Evade"] = {
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["暗影之刃"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["腐蚀术 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["痛苦无常 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["PartialBlock"] = {
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["焰光蛾"] = {
							["Details"] = {
								["暗影之刃"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色骑士希莱林"] = {
							["Details"] = {
								["暗影之刃"] = {
									["count"] = 0,
								},
								["痛楚"] = {
									["count"] = 0,
								},
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
								["痛苦无常 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["狡猾的灌尾狐"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGain"] = 0,
					["RageGainedFrom"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight3"] = {
					["DOTs"] = {
						["痛楚 (伤害/跳)"] = {
							["Details"] = {
								["黑石蜥蜴"] = {
									["count"] = 0,
								},
								["暮色卫队邪剑士"] = {
									["count"] = 14,
								},
							},
							["amount"] = 14,
						},
						["腐蚀术 (伤害/跳)"] = {
							["Details"] = {
								["黑石蜥蜴"] = {
									["count"] = 0,
								},
								["暮色卫队邪剑士"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
						["痛苦无常 (伤害/跳)"] = {
							["Details"] = {
								["黑石蜥蜴"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
					},
					["DOT_Time"] = 29,
					["Damage"] = 2135179,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialBlock"] = {
					},
					["FDamagedWho"] = {
					},
					["FAttacks"] = {
					},
					["RageGain"] = 0,
					["ElementDone"] = {
						["Shadow"] = 2135179,
					},
					["ManaGainedFrom"] = {
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 10,
								},
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 14,
						},
					},
					["RageGained"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["Dispelled"] = 0,
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 18513,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 67896,
								},
							},
							["count"] = 8,
							["amount"] = 67896,
						},
						["奇怪的感觉"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 207437,
									["min"] = 207437,
									["count"] = 1,
									["amount"] = 207437,
								},
							},
							["count"] = 1,
							["amount"] = 207437,
						},
						["灵魂之镰"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 329230,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 329230,
								},
							},
							["count"] = 1,
							["amount"] = 329230,
						},
					},
					["WhoHealed"] = {
					},
					["EnergyGain"] = 0,
					["CCBreak"] = 0,
					["PartialAbsorb"] = {
					},
					["ActiveTime"] = 9.78,
					["PartialResist"] = {
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 604563,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["暗影之刃"] = {
									["count"] = 0,
								},
								["灵魂之镰"] = {
									["count"] = 0,
								},
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
								["延绵恐惧"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 3.23,
								},
								["灵魂之镰"] = {
									["count"] = 0.45,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 5.24,
								},
								["延绵恐惧"] = {
									["count"] = 0.86,
								},
							},
							["amount"] = 9.78,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["Attacks"] = {
						["暗影之刃"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["痛苦无常 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["灵魂之镰"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 329230,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 329230,
								},
							},
							["count"] = 1,
							["amount"] = 329230,
						},
						["痛楚 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 94973,
									["min"] = 0,
									["count"] = 7,
									["amount"] = 360410,
								},
							},
							["count"] = 7,
							["amount"] = 360410,
						},
						["腐蚀术 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 482059,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 903412,
								},
								["Tick"] = {
									["max"] = 167204,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 501608,
								},
							},
							["count"] = 5,
							["amount"] = 1405020,
						},
						["延绵恐惧"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 40519,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 40519,
								},
							},
							["count"] = 1,
							["amount"] = 40519,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["暗影之刃"] = {
									["count"] = 0,
								},
								["痛苦无常 (伤害/跳)"] = {
									["count"] = 0,
								},
								["灵魂之镰"] = {
									["count"] = 0,
								},
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
								["延绵恐惧"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 360410,
								},
								["灵魂之镰"] = {
									["count"] = 329230,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 1405020,
								},
								["延绵恐惧"] = {
									["count"] = 40519,
								},
							},
							["amount"] = 2135179,
						},
					},
					["TimeDamage"] = 9.78,
					["TimeDamaging"] = {
						["黑石蜥蜴"] = {
							["Details"] = {
								["暗影之刃"] = {
									["count"] = 0,
								},
								["灵魂之镰"] = {
									["count"] = 0,
								},
								["痛楚 (伤害/跳)"] = {
									["count"] = 0,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 0,
								},
								["延绵恐惧"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["暮色卫队邪剑士"] = {
							["Details"] = {
								["痛楚 (伤害/跳)"] = {
									["count"] = 3.23,
								},
								["灵魂之镰"] = {
									["count"] = 0.45,
								},
								["腐蚀术 (伤害/跳)"] = {
									["count"] = 5.24,
								},
								["延绵恐惧"] = {
									["count"] = 0.86,
								},
							},
							["amount"] = 9.78,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
			},
			["type"] = "Self",
			["FightsSaved"] = 5,
			["GuardianReverseGUIDs"] = {
				["扎克里拉"] = {
					["LatestGuardian"] = 1,
					["GUIDs"] = {
						"Pet-0-3905-1220-30100-78158-04022524EF", -- [1]
						[0] = "Pet-0-3905-1220-30100-78158-01022524EF",
					},
				},
				["未知目标"] = {
					["LatestGuardian"] = 0,
					["GUIDs"] = {
						[0] = "Creature-0-3908-1220-5377-119138-0000137EA2",
					},
				},
			},
			["LastEventTimes"] = {
				12998.909, -- [1]
				12998.909, -- [2]
				12998.909, -- [3]
				12999.305, -- [4]
				13001.642, -- [5]
				13001.75, -- [6]
				12924.574, -- [7]
				12924.92, -- [8]
				12924.92, -- [9]
				12926.082, -- [10]
				12926.211, -- [11]
				12926.397, -- [12]
				12926.397, -- [13]
				12927.373, -- [14]
				12927.651, -- [15]
				12927.651, -- [16]
				12927.651, -- [17]
				12927.988, -- [18]
				12928.246, -- [19]
				12928.695, -- [20]
				12929.246, -- [21]
				12929.246, -- [22]
				12929.246, -- [23]
				12929.521, -- [24]
				12929.521, -- [25]
				12929.867, -- [26]
				12943.423, -- [27]
				12943.682, -- [28]
				12944.52, -- [29]
				12944.923, -- [30]
				12944.923, -- [31]
				12945.375, -- [32]
				12945.375, -- [33]
				12946.213, -- [34]
				12946.213, -- [35]
				12946.213, -- [36]
				12946.55, -- [37]
				12947.388, -- [38]
				12947.388, -- [39]
				12947.731, -- [40]
				12948.642, -- [41]
				12948.953, -- [42]
				12949.286, -- [43]
				12949.964, -- [44]
				12950.529, -- [45]
				12950.853, -- [46]
				12951.127, -- [47]
				12951.715, -- [48]
				12952.374, -- [49]
				12953.287, -- [50]
			},
			["Owner"] = false,
			["Pet"] = {
				"扎克里拉 <灰衣人>", -- [1]
				"未知目标 <灰衣人>", -- [2]
				"肉弹 <灰衣人>", -- [3]
				"守望者新兵 <灰衣人>", -- [4]
				"夜之子反叛者 <灰衣人>", -- [5]
			},
			["NextEventNum"] = 7,
			["LastDamageTime"] = 13001.642,
			["LastEvents"] = {
				"灰衣人 痛楚 (伤害/跳) 狡猾的灌尾狐 Tick -17010 (Shadow)", -- [1]
				"灰衣人 混沌黑暗 灰衣人 Hit +199482 (199482 过量治疗)", -- [2]
				"灰衣人 混沌黑暗 狡猾的灌尾狐 Crit -1457119 (Shadow)", -- [3]
				"灰衣人 吸血 灰衣人 Hit +46875 (46875 过量治疗)", -- [4]
				"灰衣人 暗影之刃 焰光蛾 Hit -135623 (Shadow)", -- [5]
				"灰衣人 吸血 灰衣人 Hit +6752 (6752 过量治疗)", -- [6]
				"灰衣人 腐蚀术 (伤害/跳) 暮色骑士希莱林 Crit -421353 (Shadow)", -- [7]
				"灰衣人 痛楚 (伤害/跳) 暮色骑士希莱林 Tick -38139 (Shadow)", -- [8]
				"灰衣人 吸血 灰衣人 Hit +14611 (14611 过量治疗)", -- [9]
				"灰衣人 腐蚀术 (伤害/跳) 暮色骑士希莱林 Crit -421353 (Shadow)", -- [10]
				"灰衣人 吸血 灰衣人 Hit +13398 (13398 过量治疗)", -- [11]
				"灰衣人 暗影之刃 暮色骑士希莱林 Hit -126772 (Shadow)", -- [12]
				"灰衣人 痛楚 (伤害/跳) 暮色骑士希莱林 Tick -50853 (Shadow)", -- [13]
				"灰衣人 吸血 灰衣人 Hit +5649 (5649 过量治疗)", -- [14]
				"灰衣人 腐蚀术 (伤害/跳) 暮色骑士希莱林 Crit -421353 (Shadow)", -- [15]
				"灰衣人 混沌黑暗 灰衣人 Hit +501881 (501881 过量治疗)", -- [16]
				"灰衣人 混沌黑暗 暮色骑士希莱林 Hit -208512 (Shadow)", -- [17]
				"灰衣人 痛楚 (伤害/跳) 暮色骑士希莱林 Tick -68178 (Shadow)", -- [18]
				"灰衣人 痛苦无常 (伤害/跳) 暮色骑士希莱林 Tick -276273 (Shadow)", -- [19]
				"灰衣人 吸血 灰衣人 Hit +30981 (30981 过量治疗)", -- [20]
				"灰衣人 腐蚀术 (伤害/跳) 暮色骑士希莱林 Tick -199606 (Shadow)", -- [21]
				"灰衣人 吸取灵魂 (伤害/跳) 暮色骑士希莱林 Tick -242788 (Shadow)", -- [22]
				"灰衣人 吸取灵魂 灰衣人 Hit +631250 (631250 过量治疗)", -- [23]
				"灰衣人 痛苦无常 (伤害/跳) 暮色骑士希莱林 Tick -352472 (Shadow)", -- [24]
				"灰衣人 痛楚 (伤害/跳) 暮色骑士希莱林 Tick -114190 (Shadow)", -- [25]
				"灰衣人 吸血 灰衣人 Hit +28906 (28906 过量治疗)", -- [26]
				"灰衣人 痛楚 (伤害/跳) 暮色卫队邪剑士 Tick -25426 (Shadow)", -- [27]
				"灰衣人 吸血 灰衣人 Hit +809 (809 过量治疗)", -- [28]
				"灰衣人 腐蚀术 (伤害/跳) 暮色卫队邪剑士 Tick -167202 (Shadow)", -- [29]
				"灰衣人 吸血 灰衣人 Hit +5317 (5317 过量治疗)", -- [30]
				"灰衣人 痛楚 (伤害/跳) 暮色卫队邪剑士 Tick -38141 (Shadow)", -- [31]
				"灰衣人 灵魂之镰 暮色卫队邪剑士 Hit -329230 (Shadow)", -- [32]
				"灰衣人 灵魂之镰 灰衣人 Hit +329230 (329230 过量治疗)", -- [33]
				"灰衣人 吸血 灰衣人 Hit +11682 (11682 过量治疗)", -- [34]
				"灰衣人 腐蚀术 (伤害/跳) 暮色卫队邪剑士 Crit -482059 (Shadow)", -- [35]
				"灰衣人 痛楚 (伤害/跳) 暮色卫队邪剑士 Tick -25426 (Shadow)", -- [36]
				"灰衣人 痛楚 (伤害/跳) 暮色卫队邪剑士 Tick -74737 (Shadow)", -- [37]
				"灰衣人 吸血 灰衣人 Hit +18513 (18513 过量治疗)", -- [38]
				"灰衣人 腐蚀术 (伤害/跳) 暮色卫队邪剑士 Crit -421353 (Shadow)", -- [39]
				"灰衣人 痛楚 (伤害/跳) 暮色卫队邪剑士 Tick -38141 (Shadow)", -- [40]
				"灰衣人 吸血 灰衣人 Hit +14611 (14611 过量治疗)", -- [41]
				"灰衣人 腐蚀术 (伤害/跳) 暮色卫队邪剑士 Tick -167202 (Shadow)", -- [42]
				"灰衣人 痛楚 (伤害/跳) 暮色卫队邪剑士 Tick -63566 (Shadow)", -- [43]
				"灰衣人 吸血 灰衣人 Hit +7338 (7338 过量治疗)", -- [44]
				"灰衣人 腐蚀术 (伤害/跳) 暮色卫队邪剑士 Tick -167204 (Shadow)", -- [45]
				"灰衣人 痛楚 (伤害/跳) 暮色卫队邪剑士 Tick -94973 (Shadow)", -- [46]
				"灰衣人 吸血 灰衣人 Hit +8337 (8337 过量治疗)", -- [47]
				"灰衣人 延绵恐惧 暮色卫队邪剑士 Hit -40519 (Shadow)", -- [48]
				"灰衣人 吸血 灰衣人 Hit +1289 (1289 过量治疗)", -- [49]
				"灰衣人 奇怪的感觉 灰衣人 Hit +207437 (207437 过量治疗)", -- [50]
			},
			["Name"] = "灰衣人",
			["LastEventIncoming"] = {
				false, -- [1]
				true, -- [2]
				false, -- [3]
				true, -- [4]
				false, -- [5]
				true, -- [6]
				false, -- [7]
				false, -- [8]
				true, -- [9]
				false, -- [10]
				true, -- [11]
				false, -- [12]
				false, -- [13]
				true, -- [14]
				false, -- [15]
				true, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				true, -- [20]
				false, -- [21]
				false, -- [22]
				true, -- [23]
				false, -- [24]
				false, -- [25]
				true, -- [26]
				false, -- [27]
				true, -- [28]
				false, -- [29]
				true, -- [30]
				false, -- [31]
				false, -- [32]
				true, -- [33]
				true, -- [34]
				false, -- [35]
				false, -- [36]
				false, -- [37]
				true, -- [38]
				false, -- [39]
				false, -- [40]
				true, -- [41]
				false, -- [42]
				false, -- [43]
				true, -- [44]
				false, -- [45]
				false, -- [46]
				true, -- [47]
				false, -- [48]
				true, -- [49]
				true, -- [50]
			},
			["LastHealTime"] = 12922.679,
			["LastDamageTaken"] = 99906,
			["LastEventHealthMax"] = {
				5185920, -- [1]
				5185920, -- [2]
				5185920, -- [3]
				5185920, -- [4]
				5185920, -- [5]
				5185920, -- [6]
				5185920, -- [7]
				5185920, -- [8]
				5185920, -- [9]
				5185920, -- [10]
				5185920, -- [11]
				5185920, -- [12]
				5185920, -- [13]
				5185920, -- [14]
				5185920, -- [15]
				5185920, -- [16]
				5185920, -- [17]
				5185920, -- [18]
				5185920, -- [19]
				5185920, -- [20]
				5185920, -- [21]
				5185920, -- [22]
				5185920, -- [23]
				5185920, -- [24]
				5185920, -- [25]
				5185920, -- [26]
				5185920, -- [27]
				5185920, -- [28]
				5185920, -- [29]
				5185920, -- [30]
				5185920, -- [31]
				5185920, -- [32]
				5185920, -- [33]
				5185920, -- [34]
				5185920, -- [35]
				5185920, -- [36]
				5185920, -- [37]
				5185920, -- [38]
				5185920, -- [39]
				5185920, -- [40]
				5185920, -- [41]
				5185920, -- [42]
				5185920, -- [43]
				5185920, -- [44]
				5185920, -- [45]
				5185920, -- [46]
				5185920, -- [47]
				5185920, -- [48]
				5185920, -- [49]
				5185920, -- [50]
			},
			["LastActive"] = 13001.287,
		},
	},
	["FightNum"] = 11,
	["CombatTimes"] = {
		{
			12600.3, -- [1]
			12611.317, -- [2]
			"13:37:37", -- [3]
			"13:37:47", -- [4]
			"黑石蜥蜴", -- [5]
		}, -- [1]
		{
			12625.31, -- [1]
			12631.297, -- [2]
			"13:38:01", -- [3]
			"13:38:07", -- [4]
			"黑石蜥蜴", -- [5]
		}, -- [2]
		{
			12634.32, -- [1]
			12641.31, -- [2]
			"13:38:10", -- [3]
			"13:38:17", -- [4]
			"黑石蜥蜴", -- [5]
		}, -- [3]
		{
			12791.298, -- [1]
			12800.314, -- [2]
			"13:40:47", -- [3]
			"13:40:56", -- [4]
			"暮色骑士希莱林", -- [5]
		}, -- [4]
		{
			12806.306, -- [1]
			12816.295, -- [2]
			"13:41:03", -- [3]
			"13:41:12", -- [4]
			"暮色卫队邪剑士", -- [5]
		}, -- [5]
		{
			12853.293, -- [1]
			12895.303, -- [2]
			"13:41:50", -- [3]
			"13:42:31", -- [4]
			"暮色卫队邪剑士", -- [5]
		}, -- [6]
		{
			12908.296, -- [1]
			12913.285, -- [2]
			"13:42:45", -- [3]
			"13:42:49", -- [4]
			"暮色卫队邪剑士", -- [5]
		}, -- [7]
		{
			12922.308, -- [1]
			12930.279, -- [2]
			"13:42:58", -- [3]
			"13:43:06", -- [4]
			"暮色骑士希莱林", -- [5]
		}, -- [8]
		{
			12943.282, -- [1]
			12953.287, -- [2]
			"13:43:19", -- [3]
			"13:43:29", -- [4]
			"暮色卫队邪剑士", -- [5]
		}, -- [9]
		{
			83043.102, -- [1]
			83053.101, -- [2]
			"20:55:24", -- [3]
			"20:55:33", -- [4]
			"森林蜘蛛", -- [5]
		}, -- [10]
		{
			434285.26, -- [1]
			434291.255, -- [2]
			"22:29:16", -- [3]
			"22:29:21", -- [4]
			"癞皮狼", -- [5]
		}, -- [11]
	},
	["FoughtWho"] = {
		"癞皮狼 22:29:16-22:29:21", -- [1]
		"森林蜘蛛 20:55:24-20:55:33", -- [2]
		"暮色卫队邪剑士 13:43:19-13:43:29", -- [3]
		"暮色骑士希莱林 13:42:58-13:43:06", -- [4]
		"暮色卫队邪剑士 13:42:45-13:42:49", -- [5]
	},
}
