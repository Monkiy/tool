
BattlefieldMinimapOptions = {
	["locked"] = true,
	["opacity"] = 0.699999988079071,
	["showPlayers"] = true,
	["position"] = {
		["y"] = 364.999908447266,
		["x"] = 87.4999694824219,
	},
}
