
RecountPerCharDB = {
	["version"] = "1.3",
	["combatants"] = {
		["咕噜胖"] = {
			["GUID"] = "Player-2135-0BAFC087",
			["LastEventHealth"] = {
				468, -- [1]
				468, -- [2]
				453, -- [3]
				453, -- [4]
				453, -- [5]
				463, -- [6]
				468, -- [7]
				468, -- [8]
				468, -- [9]
				468, -- [10]
				468, -- [11]
				468, -- [12]
				468, -- [13]
				468, -- [14]
				468, -- [15]
				468, -- [16]
				468, -- [17]
				468, -- [18]
				468, -- [19]
				468, -- [20]
				468, -- [21]
				468, -- [22]
				468, -- [23]
				468, -- [24]
				468, -- [25]
				468, -- [26]
				468, -- [27]
				468, -- [28]
				468, -- [29]
				453, -- [30]
				453, -- [31]
				453, -- [32]
				462, -- [33]
				468, -- [34]
				468, -- [35]
				468, -- [36]
				468, -- [37]
				456, -- [38]
				456, -- [39]
				465, -- [40]
				465, -- [41]
				465, -- [42]
				465, -- [43]
				465, -- [44]
				465, -- [45]
				468, -- [46]
				468, -- [47]
				468, -- [48]
				468, -- [49]
				468, -- [50]
			},
			["LastAttackedBy"] = "提瑞斯法雇农",
			["LastEventType"] = {
				"HEAL", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"HEAL", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"HEAL", -- [9]
				"DAMAGE", -- [10]
				"HEAL", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"HEAL", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"HEAL", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"HEAL", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"HEAL", -- [33]
				"HEAL", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"HEAL", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"HEAL", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					17.16, -- [1]
				},
				["HealingTaken"] = {
					82, -- [1]
				},
				["Overhealing"] = {
					685, -- [1]
				},
				["ActiveTime"] = {
					240.21, -- [1]
				},
				["TimeDamage"] = {
					223.05, -- [1]
				},
				["Healing"] = {
					82, -- [1]
				},
				["DamageTaken"] = {
					92, -- [1]
				},
				["Damage"] = {
					12183, -- [1]
				},
			},
			["enClass"] = "HUNTER",
			["unit"] = "咕噜胖",
			["LastAbility"] = 261721.151,
			["LastHealTime"] = 262508.327,
			["level"] = 2,
			["LastDamageAbility"] = "肉搏",
			["LastFightIn"] = 43,
			["UnitLockout"] = 435579.521,
			["type"] = "Self",
			["FightsSaved"] = 5,
			["Fights"] = {
				["OverallData"] = {
					["TimeHealing"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 17.16,
								},
							},
							["amount"] = 17.16,
						},
					},
					["OverHeals"] = {
						["迅捷的正义之手"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 10,
									["min"] = 1,
									["count"] = 63,
									["amount"] = 429,
								},
							},
							["count"] = 63,
							["amount"] = 429,
						},
						["哀伤之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 27,
									["min"] = 3,
									["count"] = 14,
									["amount"] = 256,
								},
							},
							["count"] = 14,
							["amount"] = 256,
						},
					},
					["TimeSpent"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 17.16,
								},
							},
							["amount"] = 17.16,
						},
						["断骨骷髅"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 8.63,
								},
								["眼镜蛇射击"] = {
									["count"] = 4.16,
								},
							},
							["amount"] = 12.79,
						},
						["治安官雷德帕斯"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 3.4,
								},
								["自动射击"] = {
									["count"] = 2.8,
								},
							},
							["amount"] = 6.2,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 8.19,
								},
								["自动射击"] = {
									["count"] = 11.08,
								},
							},
							["amount"] = 19.27,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 16.5,
								},
								["眼镜蛇射击"] = {
									["count"] = 3.95,
								},
							},
							["amount"] = 20.45,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 8.58,
								},
								["眼镜蛇射击"] = {
									["count"] = 5.07,
								},
							},
							["amount"] = 13.65,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 11.77,
								},
								["自动射击"] = {
									["count"] = 23.68,
								},
							},
							["amount"] = 35.45,
						},
						["夜行蝙蝠"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 3.68,
								},
								["哀伤之触"] = {
									["count"] = 0.1,
								},
								["自动射击"] = {
									["count"] = 2.47,
								},
							},
							["amount"] = 6.25,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 7.66,
								},
								["眼镜蛇射击"] = {
									["count"] = 3.33,
								},
							},
							["amount"] = 10.99,
						},
						["腐脑狂战士"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 11.83,
								},
								["眼镜蛇射击"] = {
									["count"] = 8.98,
								},
							},
							["amount"] = 20.81,
						},
						["蓬毛食腐狼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 7.82,
								},
								["眼镜蛇射击"] = {
									["count"] = 3.57,
								},
							},
							["amount"] = 11.39,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 13.28,
								},
								["自动射击"] = {
									["count"] = 13.15,
								},
							},
							["amount"] = 26.43,
						},
						["衰老的黑暗犬"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 4.87,
								},
								["自动射击"] = {
									["count"] = 8.15,
								},
							},
							["amount"] = 13.02,
						},
						["被诅咒的黑暗犬"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 2.06,
								},
								["自动射击"] = {
									["count"] = 3,
								},
							},
							["amount"] = 5.06,
						},
						["腐脑魔导师"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 7.5,
								},
								["哀伤之触"] = {
									["count"] = 0.11,
								},
								["眼镜蛇射击"] = {
									["count"] = 1.14,
								},
							},
							["amount"] = 8.75,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 6.94,
								},
								["眼镜蛇射击"] = {
									["count"] = 5.6,
								},
							},
							["amount"] = 12.54,
						},
					},
					["DamageTaken"] = 92,
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 14,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 14,
						},
					},
					["Overhealing"] = 685,
					["ActiveTime"] = 240.21,
					["ElementTaken"] = {
						["Melee"] = 92,
					},
					["Damage"] = 12183,
					["TimeHeal"] = 17.16,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 27,
								},
								["Hit"] = {
									["count"] = 178,
								},
							},
							["amount"] = 205,
						},
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 14,
								},
							},
							["amount"] = 14,
						},
					},
					["WhoDamaged"] = {
						["断骨骷髅"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 11,
								},
							},
							["amount"] = 11,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 8,
								},
							},
							["amount"] = 8,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 16,
								},
							},
							["amount"] = 16,
						},
						["夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["蓬毛食腐狼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 30,
								},
							},
							["amount"] = 30,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
					},
					["Attacks"] = {
						["自动射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 59,
									["min"] = 28,
									["count"] = 9,
									["amount"] = 442,
								},
								["Hit"] = {
									["max"] = 30,
									["min"] = 14,
									["count"] = 97,
									["amount"] = 2377,
								},
							},
							["count"] = 106,
							["amount"] = 2819,
						},
						["哀伤之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 27,
									["min"] = 10,
									["count"] = 14,
									["amount"] = 312,
								},
							},
							["count"] = 14,
							["amount"] = 312,
						},
						["眼镜蛇射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 176,
									["min"] = 142,
									["count"] = 18,
									["amount"] = 2857,
								},
								["Hit"] = {
									["max"] = 100,
									["min"] = 44,
									["count"] = 81,
									["amount"] = 6195,
								},
							},
							["count"] = 99,
							["amount"] = 9052,
						},
					},
					["Healing"] = 82,
					["Heals"] = {
						["迅捷的正义之手"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 10,
									["min"] = 3,
									["count"] = 13,
									["amount"] = 76,
								},
							},
							["count"] = 13,
							["amount"] = 76,
						},
						["哀伤之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 6,
									["min"] = 6,
									["count"] = 1,
									["amount"] = 6,
								},
							},
							["count"] = 1,
							["amount"] = 6,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 13,
								},
							},
							["amount"] = 14,
						},
					},
					["ElementDone"] = {
						["Physical"] = 11871,
						["Shadow"] = 312,
					},
					["HealingTaken"] = 82,
					["DamagedWho"] = {
						["断骨骷髅"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 524,
								},
								["哀伤之触"] = {
									["count"] = 23,
								},
								["自动射击"] = {
									["count"] = 168,
								},
							},
							["amount"] = 715,
						},
						["治安官雷德帕斯"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 299,
								},
								["自动射击"] = {
									["count"] = 76,
								},
							},
							["amount"] = 375,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 230,
								},
								["哀伤之触"] = {
									["count"] = 23,
								},
								["眼镜蛇射击"] = {
									["count"] = 1186,
								},
							},
							["amount"] = 1439,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 266,
								},
								["哀伤之触"] = {
									["count"] = 30,
								},
								["眼镜蛇射击"] = {
									["count"] = 658,
								},
							},
							["amount"] = 954,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 140,
								},
								["哀伤之触"] = {
									["count"] = 23,
								},
								["眼镜蛇射击"] = {
									["count"] = 521,
								},
							},
							["amount"] = 684,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 483,
								},
								["哀伤之触"] = {
									["count"] = 88,
								},
								["眼镜蛇射击"] = {
									["count"] = 1516,
								},
							},
							["amount"] = 2087,
						},
						["夜行蝙蝠"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 228,
								},
								["哀伤之触"] = {
									["count"] = 21,
								},
								["自动射击"] = {
									["count"] = 48,
								},
							},
							["amount"] = 297,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 147,
								},
								["眼镜蛇射击"] = {
									["count"] = 376,
								},
							},
							["amount"] = 523,
						},
						["腐脑狂战士"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 275,
								},
								["眼镜蛇射击"] = {
									["count"] = 940,
								},
							},
							["amount"] = 1215,
						},
						["蓬毛食腐狼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 167,
								},
								["眼镜蛇射击"] = {
									["count"] = 366,
								},
							},
							["amount"] = 533,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 279,
								},
								["哀伤之触"] = {
									["count"] = 27,
								},
								["眼镜蛇射击"] = {
									["count"] = 1009,
								},
							},
							["amount"] = 1315,
						},
						["衰老的黑暗犬"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 179,
								},
								["哀伤之触"] = {
									["count"] = 26,
								},
								["眼镜蛇射击"] = {
									["count"] = 479,
								},
							},
							["amount"] = 684,
						},
						["被诅咒的黑暗犬"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 158,
								},
								["自动射击"] = {
									["count"] = 52,
								},
							},
							["amount"] = 210,
						},
						["腐脑魔导师"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 151,
								},
								["哀伤之触"] = {
									["count"] = 24,
								},
								["眼镜蛇射击"] = {
									["count"] = 308,
								},
							},
							["amount"] = 483,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 484,
								},
								["哀伤之触"] = {
									["count"] = 27,
								},
								["自动射击"] = {
									["count"] = 158,
								},
							},
							["amount"] = 669,
						},
					},
					["TimeDamage"] = 223.05,
					["TimeDamaging"] = {
						["断骨骷髅"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 8.63,
								},
								["眼镜蛇射击"] = {
									["count"] = 4.16,
								},
							},
							["amount"] = 12.79,
						},
						["治安官雷德帕斯"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 3.4,
								},
								["自动射击"] = {
									["count"] = 2.8,
								},
							},
							["amount"] = 6.2,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 8.19,
								},
								["自动射击"] = {
									["count"] = 11.08,
								},
							},
							["amount"] = 19.27,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 16.5,
								},
								["眼镜蛇射击"] = {
									["count"] = 3.95,
								},
							},
							["amount"] = 20.45,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 8.58,
								},
								["眼镜蛇射击"] = {
									["count"] = 5.07,
								},
							},
							["amount"] = 13.65,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 11.77,
								},
								["自动射击"] = {
									["count"] = 23.68,
								},
							},
							["amount"] = 35.45,
						},
						["夜行蝙蝠"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 3.68,
								},
								["哀伤之触"] = {
									["count"] = 0.1,
								},
								["自动射击"] = {
									["count"] = 2.47,
								},
							},
							["amount"] = 6.25,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 7.66,
								},
								["眼镜蛇射击"] = {
									["count"] = 3.33,
								},
							},
							["amount"] = 10.99,
						},
						["腐脑狂战士"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 11.83,
								},
								["眼镜蛇射击"] = {
									["count"] = 8.98,
								},
							},
							["amount"] = 20.81,
						},
						["蓬毛食腐狼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 7.82,
								},
								["眼镜蛇射击"] = {
									["count"] = 3.57,
								},
							},
							["amount"] = 11.39,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 13.28,
								},
								["自动射击"] = {
									["count"] = 13.15,
								},
							},
							["amount"] = 26.43,
						},
						["衰老的黑暗犬"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 4.87,
								},
								["自动射击"] = {
									["count"] = 8.15,
								},
							},
							["amount"] = 13.02,
						},
						["被诅咒的黑暗犬"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 2.06,
								},
								["自动射击"] = {
									["count"] = 3,
								},
							},
							["amount"] = 5.06,
						},
						["腐脑魔导师"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 7.5,
								},
								["哀伤之触"] = {
									["count"] = 0.11,
								},
								["眼镜蛇射击"] = {
									["count"] = 1.14,
								},
							},
							["amount"] = 8.75,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 6.94,
								},
								["眼镜蛇射击"] = {
									["count"] = 5.6,
								},
							},
							["amount"] = 12.54,
						},
					},
					["HealedWho"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 76,
								},
								["哀伤之触"] = {
									["count"] = 6,
								},
							},
							["amount"] = 82,
						},
					},
					["WhoHealed"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 76,
								},
								["哀伤之触"] = {
									["count"] = 6,
								},
							},
							["amount"] = 82,
						},
					},
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 14,
									["amount"] = 0,
								},
							},
							["count"] = 14,
							["amount"] = 0,
						},
					},
				},
				["Fight5"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
						["Melee"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 272,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Physical"] = 272,
						["Shadow"] = 0,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 5,
						},
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
						["夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
						["迅捷的正义之手"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 9,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 9,
								},
							},
							["count"] = 1,
							["amount"] = 9,
						},
						["哀伤之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 5.9,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 9,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["断骨骷髅"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蝙蝠"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["哀伤之触"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["腐脑魔导师"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["哀伤之触"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 3.4,
								},
								["自动射击"] = {
									["count"] = 2.5,
								},
							},
							["amount"] = 5.9,
						},
					},
					["Heals"] = {
						["迅捷的正义之手"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["自动射击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 25,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 49,
								},
							},
							["count"] = 2,
							["amount"] = 49,
						},
						["哀伤之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["眼镜蛇射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 76,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 223,
								},
							},
							["count"] = 3,
							["amount"] = 223,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["提瑞斯法雇农"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 223,
								},
								["自动射击"] = {
									["count"] = 49,
								},
							},
							["amount"] = 272,
						},
						["断骨骷髅"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["腐脑魔导师"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["哀伤之触"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["哀伤之触"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蝙蝠"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["哀伤之触"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 5.9,
					["TimeDamaging"] = {
						["提瑞斯法雇农"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 3.4,
								},
								["自动射击"] = {
									["count"] = 2.5,
								},
							},
							["amount"] = 5.9,
						},
						["断骨骷髅"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["腐脑魔导师"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["哀伤之触"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蝙蝠"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["哀伤之触"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
						["Melee"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Shadow"] = 0,
						["Physical"] = 0,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
						["蓬毛食腐狼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
						["迅捷的正义之手"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["哀伤之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 0,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["断骨骷髅"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["蓬毛食腐狼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["衰老的黑暗犬"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["治安官雷德帕斯"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Heals"] = {
						["迅捷的正义之手"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["眼镜蛇射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["哀伤之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["自动射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["断骨骷髅"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["哀伤之触"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["蓬毛食腐狼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["衰老的黑暗犬"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["哀伤之触"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["治安官雷德帕斯"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["断骨骷髅"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["蓬毛食腐狼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["衰老的黑暗犬"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["治安官雷德帕斯"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["TimeHealing"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
						["迅捷的正义之手"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 10,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 10,
								},
							},
							["count"] = 1,
							["amount"] = 10,
						},
						["哀伤之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["TimeSpent"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["腐脑狂战士"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 2.95,
								},
								["自动射击"] = {
									["count"] = 1.98,
								},
							},
							["amount"] = 4.93,
						},
						["被诅咒的黑暗犬"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamageTaken"] = 0,
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["Overhealing"] = 10,
					["ActiveTime"] = 4.93,
					["ElementTaken"] = {
						["Melee"] = 0,
					},
					["Damage"] = 216,
					["TimeHeal"] = 0,
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["HealedWho"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["Heals"] = {
						["迅捷的正义之手"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["自动射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 27,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 53,
								},
							},
							["count"] = 2,
							["amount"] = 53,
						},
						["哀伤之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["眼镜蛇射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 83,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 163,
								},
							},
							["count"] = 2,
							["amount"] = 163,
						},
					},
					["HealingTaken"] = 0,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 4.93,
					["TimeDamaging"] = {
						["腐脑狂战士"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 2.95,
								},
								["自动射击"] = {
									["count"] = 1.98,
								},
							},
							["amount"] = 4.93,
						},
						["被诅咒的黑暗犬"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["腐脑狂战士"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 163,
								},
								["自动射击"] = {
									["count"] = 53,
								},
							},
							["amount"] = 216,
						},
						["被诅咒的黑暗犬"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["哀伤之触"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["哀伤之触"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDamaged"] = {
						["小夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Physical"] = 216,
						["Shadow"] = 0,
					},
				},
				["Fight4"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 27,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
						["Melee"] = 27,
					},
					["DOT_Time"] = 0,
					["Damage"] = 642,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 3,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Physical"] = 615,
						["Shadow"] = 27,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 10,
								},
							},
							["amount"] = 11,
						},
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
						["断骨骷髅"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["OverHeals"] = {
						["迅捷的正义之手"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 10,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 10,
								},
							},
							["count"] = 1,
							["amount"] = 10,
						},
						["哀伤之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 20,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 20,
								},
							},
							["count"] = 1,
							["amount"] = 20,
						},
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 14.77,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 18,
								},
								["哀伤之触"] = {
									["count"] = 6,
								},
							},
							["amount"] = 24,
						},
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 30,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["断骨骷髅"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["腐脑狂战士"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["腐脑魔导师"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 2.83,
								},
								["自动射击"] = {
									["count"] = 4.4,
								},
							},
							["amount"] = 7.23,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 2.44,
								},
								["眼镜蛇射击"] = {
									["count"] = 2.1,
								},
							},
							["amount"] = 4.54,
						},
					},
					["Heals"] = {
						["迅捷的正义之手"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 9,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 18,
								},
							},
							["count"] = 2,
							["amount"] = 18,
						},
						["哀伤之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 6,
									["min"] = 6,
									["count"] = 1,
									["amount"] = 6,
								},
							},
							["count"] = 1,
							["amount"] = 6,
						},
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 18,
								},
								["哀伤之触"] = {
									["count"] = 6,
								},
							},
							["amount"] = 24,
						},
					},
					["Healing"] = 24,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["自动射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 27,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 156,
								},
							},
							["count"] = 6,
							["amount"] = 156,
						},
						["哀伤之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 27,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 27,
								},
							},
							["count"] = 1,
							["amount"] = 27,
						},
						["眼镜蛇射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 155,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 155,
								},
								["Hit"] = {
									["max"] = 78,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 304,
								},
							},
							["count"] = 5,
							["amount"] = 459,
						},
					},
					["HealingTaken"] = 24,
					["DamagedWho"] = {
						["断骨骷髅"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["哀伤之触"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["腐脑狂战士"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["腐脑魔导师"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 102,
								},
								["哀伤之触"] = {
									["count"] = 27,
								},
								["眼镜蛇射击"] = {
									["count"] = 304,
								},
							},
							["amount"] = 433,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 54,
								},
								["眼镜蛇射击"] = {
									["count"] = 155,
								},
							},
							["amount"] = 209,
						},
					},
					["TimeDamage"] = 11.77,
					["TimeDamaging"] = {
						["断骨骷髅"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["腐脑狂战士"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["腐脑魔导师"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 2.83,
								},
								["自动射击"] = {
									["count"] = 4.4,
								},
							},
							["amount"] = 7.23,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 2.44,
								},
								["眼镜蛇射击"] = {
									["count"] = 2.1,
								},
							},
							["amount"] = 4.54,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["TimeHealing"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
						["迅捷的正义之手"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 10,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 10,
								},
							},
							["count"] = 1,
							["amount"] = 10,
						},
						["哀伤之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["TimeSpent"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["腐脑狂战士"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 2.95,
								},
								["自动射击"] = {
									["count"] = 1.98,
								},
							},
							["amount"] = 4.93,
						},
						["被诅咒的黑暗犬"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamageTaken"] = 0,
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["Overhealing"] = 10,
					["ActiveTime"] = 4.93,
					["ElementTaken"] = {
						["Melee"] = 0,
					},
					["Damage"] = 216,
					["TimeHeal"] = 0,
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["HealedWho"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["Heals"] = {
						["迅捷的正义之手"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["自动射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 27,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 53,
								},
							},
							["count"] = 2,
							["amount"] = 53,
						},
						["哀伤之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["眼镜蛇射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 83,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 163,
								},
							},
							["count"] = 2,
							["amount"] = 163,
						},
					},
					["HealingTaken"] = 0,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 4.93,
					["TimeDamaging"] = {
						["腐脑狂战士"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 2.95,
								},
								["自动射击"] = {
									["count"] = 1.98,
								},
							},
							["amount"] = 4.93,
						},
						["被诅咒的黑暗犬"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["腐脑狂战士"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 163,
								},
								["自动射击"] = {
									["count"] = 53,
								},
							},
							["amount"] = 216,
						},
						["被诅咒的黑暗犬"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["哀伤之触"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["哀伤之触"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDamaged"] = {
						["小夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Physical"] = 216,
						["Shadow"] = 0,
					},
				},
				["Fight2"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
						["Melee"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 216,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Physical"] = 189,
						["Shadow"] = 27,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
						["小夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
						["哀伤之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 27,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 27,
								},
							},
							["count"] = 1,
							["amount"] = 27,
						},
						["迅捷的正义之手"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 9,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 9,
								},
							},
							["count"] = 1,
							["amount"] = 9,
						},
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 3,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 36,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["腐脑狂战士"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["蓬毛食腐狼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["衰老的黑暗犬"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 1.5,
								},
								["自动射击"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 3,
						},
					},
					["Heals"] = {
						["迅捷的正义之手"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["自动射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 28,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 28,
								},
							},
							["count"] = 1,
							["amount"] = 28,
						},
						["哀伤之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 27,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 27,
								},
							},
							["count"] = 1,
							["amount"] = 27,
						},
						["眼镜蛇射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 161,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 161,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 161,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["腐脑狂战士"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["蓬毛食腐狼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["哀伤之触"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["衰老的黑暗犬"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["哀伤之触"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 28,
								},
								["哀伤之触"] = {
									["count"] = 27,
								},
								["眼镜蛇射击"] = {
									["count"] = 161,
								},
							},
							["amount"] = 216,
						},
					},
					["TimeDamage"] = 3,
					["TimeDamaging"] = {
						["腐脑狂战士"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["蓬毛食腐狼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["衰老的黑暗犬"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 1.5,
								},
								["自动射击"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 3,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight3"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 15,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
						["Melee"] = 15,
					},
					["DOT_Time"] = 0,
					["Damage"] = 638,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 3,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Shadow"] = 0,
						["Physical"] = 638,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Shadow"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 10,
								},
							},
							["amount"] = 11,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
						["无脑的食尸鬼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["OverHeals"] = {
						["迅捷的正义之手"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 9,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 15,
								},
							},
							["count"] = 2,
							["amount"] = 15,
						},
						["哀伤之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 16.37,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 13,
								},
							},
							["amount"] = 13,
						},
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 15,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["腐脑狂战士"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 4.1,
								},
								["自动射击"] = {
									["count"] = 4.27,
								},
							},
							["amount"] = 8.37,
						},
						["衰老的黑暗犬"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["蓬毛食腐狼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 2,
								},
								["自动射击"] = {
									["count"] = 3,
								},
							},
							["amount"] = 5,
						},
					},
					["Heals"] = {
						["迅捷的正义之手"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 10,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 13,
								},
							},
							["count"] = 2,
							["amount"] = 13,
						},
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
						["咕噜胖"] = {
							["Details"] = {
								["迅捷的正义之手"] = {
									["count"] = 13,
								},
							},
							["amount"] = 13,
						},
					},
					["Healing"] = 13,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["眼镜蛇射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 87,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 487,
								},
							},
							["count"] = 6,
							["amount"] = 487,
						},
						["哀伤之触"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["自动射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 51,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 51,
								},
								["Hit"] = {
									["max"] = 26,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 100,
								},
							},
							["count"] = 5,
							["amount"] = 151,
						},
					},
					["HealingTaken"] = 13,
					["DamagedWho"] = {
						["衰老的黑暗犬"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["腐脑狂战士"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["蓬毛食腐狼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 319,
								},
								["自动射击"] = {
									["count"] = 75,
								},
							},
							["amount"] = 394,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["哀伤之触"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 168,
								},
								["自动射击"] = {
									["count"] = 76,
								},
							},
							["amount"] = 244,
						},
					},
					["TimeDamage"] = 13.37,
					["TimeDamaging"] = {
						["衰老的黑暗犬"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["腐脑狂战士"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["蓬毛食腐狼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["自动射击"] = {
									["count"] = 0,
								},
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 4.1,
								},
								["自动射击"] = {
									["count"] = 4.27,
								},
							},
							["amount"] = 8.37,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["眼镜蛇射击"] = {
									["count"] = 2,
								},
								["自动射击"] = {
									["count"] = 3,
								},
							},
							["amount"] = 5,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
			},
			["LastEventTimes"] = {
				262501.58, -- [1]
				262503.884, -- [2]
				262505.419, -- [3]
				262506.692, -- [4]
				262508.327, -- [5]
				262508.327, -- [6]
				262523.948, -- [7]
				262523.948, -- [8]
				262523.948, -- [9]
				262525.687, -- [10]
				262525.687, -- [11]
				262543.324, -- [12]
				262545.599, -- [13]
				262546.075, -- [14]
				262547.529, -- [15]
				262547.529, -- [16]
				262461.83, -- [17]
				262463.285, -- [18]
				262464.284, -- [19]
				262464.721, -- [20]
				262467.007, -- [21]
				262467.007, -- [22]
				262471.67, -- [23]
				262473.004, -- [24]
				262474.308, -- [25]
				262474.308, -- [26]
				262477.413, -- [27]
				262477.413, -- [28]
				262478.59, -- [29]
				262480.347, -- [30]
				262480.443, -- [31]
				262480.443, -- [32]
				262480.443, -- [33]
				262480.443, -- [34]
				262482.539, -- [35]
				262483.304, -- [36]
				262483.475, -- [37]
				262486.4, -- [38]
				262486.999, -- [39]
				262486.999, -- [40]
				262489.742, -- [41]
				262490.603, -- [42]
				262492.471, -- [43]
				262492.711, -- [44]
				262495.933, -- [45]
				262496.286, -- [46]
				262498.006, -- [47]
				262498.81, -- [48]
				262499.312, -- [49]
				262501.58, -- [50]
			},
			["Owner"] = false,
			["Pet"] = {
				"蜘蛛 <咕噜胖>", -- [1]
			},
			["NextEventNum"] = 17,
			["LastDamageTime"] = 262547.529,
			["LastEvents"] = {
				"咕噜胖 迅捷的正义之手 咕噜胖 Hit +9 (9 过量治疗)", -- [1]
				"提瑞斯法雇农 肉搏 咕噜胖 Hit -15 (Physical)", -- [2]
				"咕噜胖 眼镜蛇射击 提瑞斯法雇农 Hit -84 (Physical)", -- [3]
				"咕噜胖 自动射击 提瑞斯法雇农 Hit -26 (Physical)", -- [4]
				"咕噜胖 眼镜蛇射击 提瑞斯法雇农 Hit -78 (Physical)", -- [5]
				"咕噜胖 迅捷的正义之手 咕噜胖 Hit +10", -- [6]
				"咕噜胖 自动射击 提瑞斯法农夫 Hit -28 (Physical)", -- [7]
				"咕噜胖 哀伤之触 提瑞斯法农夫 Hit -27 (Shadow)", -- [8]
				"咕噜胖 哀伤之触 咕噜胖 Hit +27 (27 过量治疗)", -- [9]
				"咕噜胖 眼镜蛇射击 提瑞斯法农夫 Crit -161 (Physical)", -- [10]
				"咕噜胖 迅捷的正义之手 咕噜胖 Hit +9 (9 过量治疗)", -- [11]
				"咕噜胖 自动射击 提瑞斯法雇农 Hit -27 (Physical)", -- [12]
				"咕噜胖 眼镜蛇射击 提瑞斯法雇农 Hit -83 (Physical)", -- [13]
				"咕噜胖 自动射击 提瑞斯法雇农 Hit -26 (Physical)", -- [14]
				"咕噜胖 眼镜蛇射击 提瑞斯法雇农 Hit -80 (Physical)", -- [15]
				"咕噜胖 迅捷的正义之手 咕噜胖 Hit +10 (10 过量治疗)", -- [16]
				"咕噜胖 自动射击 提瑞斯法雇农 Hit -25 (Physical)", -- [17]
				"咕噜胖 眼镜蛇射击 提瑞斯法雇农 Hit -76 (Physical)", -- [18]
				"咕噜胖 自动射击 提瑞斯法雇农 Hit -24 (Physical)", -- [19]
				"咕噜胖 眼镜蛇射击 提瑞斯法雇农 Hit -73 (Physical)", -- [20]
				"咕噜胖 眼镜蛇射击 提瑞斯法雇农 Hit -74 (Physical)", -- [21]
				"咕噜胖 迅捷的正义之手 咕噜胖 Hit +9 (9 过量治疗)", -- [22]
				"咕噜胖 自动射击 提瑞斯法雇农 Hit -26 (Physical)", -- [23]
				"咕噜胖 眼镜蛇射击 提瑞斯法雇农 Hit -76 (Physical)", -- [24]
				"咕噜胖 自动射击 提瑞斯法雇农 Hit -24 (Physical)", -- [25]
				"咕噜胖 眼镜蛇射击 提瑞斯法雇农 Hit -73 (Physical)", -- [26]
				"咕噜胖 自动射击 提瑞斯法雇农 Hit -26 (Physical)", -- [27]
				"咕噜胖 迅捷的正义之手 咕噜胖 Hit +10 (10 过量治疗)", -- [28]
				"提瑞斯法雇农 肉搏 咕噜胖 Hit -15 (Physical)", -- [29]
				"咕噜胖 眼镜蛇射击 提瑞斯法雇农 Crit -155 (Physical)", -- [30]
				"咕噜胖 自动射击 提瑞斯法雇农 Hit -26 (Physical)", -- [31]
				"咕噜胖 哀伤之触 提瑞斯法雇农 Hit -27 (Shadow)", -- [32]
				"咕噜胖 迅捷的正义之手 咕噜胖 Hit +9", -- [33]
				"咕噜胖 哀伤之触 咕噜胖 Hit +26 (20 过量治疗)", -- [34]
				"咕噜胖 眼镜蛇射击 提瑞斯法农夫 Hit -78 (Physical)", -- [35]
				"提瑞斯法农夫 肉搏 咕噜胖 Hit -12 (Physical)", -- [36]
				"咕噜胖 自动射击 提瑞斯法农夫 Hit -27 (Physical)", -- [37]
				"咕噜胖 自动射击 提瑞斯法农夫 Hit -27 (Physical)", -- [38]
				"咕噜胖 眼镜蛇射击 提瑞斯法农夫 Hit -77 (Physical)", -- [39]
				"咕噜胖 迅捷的正义之手 咕噜胖 Hit +9", -- [40]
				"咕噜胖 自动射击 提瑞斯法雇农 Hit -24 (Physical)", -- [41]
				"咕噜胖 眼镜蛇射击 提瑞斯法雇农 Hit -81 (Physical)", -- [42]
				"咕噜胖 自动射击 提瑞斯法雇农 Hit -25 (Physical)", -- [43]
				"咕噜胖 眼镜蛇射击 提瑞斯法雇农 Hit -76 (Physical)", -- [44]
				"咕噜胖 自动射击 提瑞斯法农夫 Crit -51 (Physical)", -- [45]
				"咕噜胖 迅捷的正义之手 咕噜胖 Hit +9 (6 过量治疗)", -- [46]
				"提瑞斯法农夫 肉搏 咕噜胖 Dodge (1)", -- [47]
				"咕噜胖 自动射击 提瑞斯法农夫 Hit -25 (Physical)", -- [48]
				"咕噜胖 眼镜蛇射击 提瑞斯法农夫 Hit -87 (Physical)", -- [49]
				"咕噜胖 眼镜蛇射击 提瑞斯法农夫 Hit -81 (Physical)", -- [50]
			},
			["Name"] = "咕噜胖",
			["LastEventIncoming"] = {
				true, -- [1]
				true, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				true, -- [6]
				false, -- [7]
				false, -- [8]
				true, -- [9]
				false, -- [10]
				true, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				true, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				true, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				true, -- [28]
				true, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				true, -- [33]
				true, -- [34]
				false, -- [35]
				true, -- [36]
				false, -- [37]
				false, -- [38]
				false, -- [39]
				true, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				true, -- [46]
				true, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["TimeLast"] = {
				["TimeHeal"] = 262507.338,
				["OVERALL"] = 262547.343,
				["DamageTaken"] = 262503.338,
				["HealingTaken"] = 262507.338,
				["Overhealing"] = 262547.343,
				["ActiveTime"] = 262547.343,
				["TimeDamage"] = 262547.343,
				["Healing"] = 262507.338,
				["Damage"] = 262547.343,
			},
			["LastDamageTaken"] = 15,
			["LastEventHealthMax"] = {
				468, -- [1]
				468, -- [2]
				468, -- [3]
				468, -- [4]
				468, -- [5]
				468, -- [6]
				468, -- [7]
				468, -- [8]
				468, -- [9]
				468, -- [10]
				468, -- [11]
				468, -- [12]
				468, -- [13]
				468, -- [14]
				468, -- [15]
				468, -- [16]
				468, -- [17]
				468, -- [18]
				468, -- [19]
				468, -- [20]
				468, -- [21]
				468, -- [22]
				468, -- [23]
				468, -- [24]
				468, -- [25]
				468, -- [26]
				468, -- [27]
				468, -- [28]
				468, -- [29]
				468, -- [30]
				468, -- [31]
				468, -- [32]
				468, -- [33]
				468, -- [34]
				468, -- [35]
				468, -- [36]
				468, -- [37]
				468, -- [38]
				468, -- [39]
				468, -- [40]
				468, -- [41]
				468, -- [42]
				468, -- [43]
				468, -- [44]
				468, -- [45]
				468, -- [46]
				468, -- [47]
				468, -- [48]
				468, -- [49]
				468, -- [50]
			},
			["LastActive"] = 262547.343,
		},
		["蜘蛛 <咕噜胖>"] = {
			["GUID"] = "Pet-0-3048-0-17404-51107-020282C100",
			["LastEventHealth"] = {
				322, -- [1]
				328, -- [2]
				328, -- [3]
				328, -- [4]
				328, -- [5]
				314, -- [6]
				314, -- [7]
				314, -- [8]
				301, -- [9]
				301, -- [10]
				301, -- [11]
				301, -- [12]
				301, -- [13]
				288, -- [14]
				288, -- [15]
				288, -- [16]
				288, -- [17]
				288, -- [18]
				277, -- [19]
				328, -- [20]
				328, -- [21]
				328, -- [22]
				317, -- [23]
				243, -- [24]
				243, -- [25]
				243, -- [26]
				243, -- [27]
				239, -- [28]
				250, -- [29]
				250, -- [30]
				250, -- [31]
				250, -- [32]
				250, -- [33]
				245, -- [34]
				242, -- [35]
				242, -- [36]
				236, -- [37]
				233, -- [38]
				233, -- [39]
				233, -- [40]
				233, -- [41]
				233, -- [42]
				227, -- [43]
				328, -- [44]
				328, -- [45]
				322, -- [46]
				322, -- [47]
				328, -- [48]
				328, -- [49]
				322, -- [50]
			},
			["LastAttackedBy"] = "提瑞斯法雇农",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["ActiveTime"] = {
					105, -- [1]
				},
				["Damage"] = {
					796, -- [1]
				},
				["DamageTaken"] = {
					249, -- [1]
				},
				["TimeDamage"] = {
					105, -- [1]
				},
			},
			["enClass"] = "PET",
			["unit"] = "蜘蛛",
			["level"] = 1,
			["LastDamageAbility"] = "肉搏",
			["LastFightIn"] = 43,
			["LastAbility"] = 261721.151,
			["type"] = "Pet",
			["FightsSaved"] = 5,
			["ownerName"] = "咕噜胖",
			["LastDamageTaken"] = 11,
			["UnitLockout"] = 435581.523,
			["Fights"] = {
				["OverallData"] = {
					["PartialBlock"] = {
						["肉搏"] = {
							["Details"] = {
								["被格挡"] = {
									["max"] = 1,
									["min"] = 1,
									["count"] = 1,
									["amount"] = 1,
								},
							},
							["count"] = 1,
							["amount"] = 1,
						},
					},
					["TimeSpent"] = {
						["断骨骷髅"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
						["治安官雷德帕斯"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 7.5,
								},
							},
							["amount"] = 7.5,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 7.5,
								},
							},
							["amount"] = 7.5,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
						["夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["腐脑狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
						["蓬毛食腐狼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
						["衰老的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
						["被诅咒的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["腐脑魔导师"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
					},
					["DamageTaken"] = 249,
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 52,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 52,
						},
					},
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 52,
									["amount"] = 0,
								},
							},
							["count"] = 52,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 105,
					["ElementTaken"] = {
						["Melee"] = 249,
					},
					["Damage"] = 796,
					["ElementTakenBlock"] = {
						["Melee"] = 1,
					},
					["ElementDone"] = {
						["Melee"] = 796,
					},
					["Attacks"] = {
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 23,
									["min"] = 19,
									["count"] = 6,
									["amount"] = 124,
								},
								["Hit"] = {
									["max"] = 12,
									["min"] = 5,
									["count"] = 65,
									["amount"] = 672,
								},
							},
							["count"] = 71,
							["amount"] = 796,
						},
					},
					["DamagedWho"] = {
						["断骨骷髅"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 48,
								},
							},
							["amount"] = 48,
						},
						["治安官雷德帕斯"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 42,
								},
							},
							["amount"] = 42,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 57,
								},
							},
							["amount"] = 57,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 32,
								},
							},
							["amount"] = 32,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 72,
								},
							},
							["amount"] = 72,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 103,
								},
							},
							["amount"] = 103,
						},
						["夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 20,
								},
							},
							["amount"] = 20,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 52,
								},
							},
							["amount"] = 52,
						},
						["腐脑狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 103,
								},
							},
							["amount"] = 103,
						},
						["蓬毛食腐狼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 30,
								},
							},
							["amount"] = 30,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 124,
								},
							},
							["amount"] = 124,
						},
						["衰老的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 34,
								},
							},
							["amount"] = 34,
						},
						["被诅咒的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 22,
								},
							},
							["amount"] = 22,
						},
						["腐脑魔导师"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 11,
								},
							},
							["amount"] = 11,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 46,
								},
							},
							["amount"] = 46,
						},
					},
					["TimeDamage"] = 105,
					["WhoDamaged"] = {
						["断骨骷髅"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
						["治安官雷德帕斯"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 17,
								},
							},
							["amount"] = 17,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 20,
								},
							},
							["amount"] = 20,
						},
						["腐脑狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 28,
								},
							},
							["amount"] = 28,
						},
						["蓬毛食腐狼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 28,
								},
							},
							["amount"] = 28,
						},
						["衰老的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 22,
								},
							},
							["amount"] = 22,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 62,
								},
							},
							["amount"] = 62,
						},
						["被诅咒的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 13,
								},
							},
							["amount"] = 13,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 10,
								},
							},
							["amount"] = 10,
						},
					},
					["TimeDamaging"] = {
						["断骨骷髅"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
						["治安官雷德帕斯"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 7.5,
								},
							},
							["amount"] = 7.5,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 7.5,
								},
							},
							["amount"] = 7.5,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
						["夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["腐脑狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
						["蓬毛食腐狼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
						["衰老的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
						["被诅咒的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["腐脑魔导师"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 2,
								},
								["Miss"] = {
									["count"] = 4,
								},
								["Block"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 44,
								},
								["Parry"] = {
									["count"] = 2,
								},
							},
							["amount"] = 53,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 65,
								},
							},
							["amount"] = 71,
						},
					},
				},
				["Fight5"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 14,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 1,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
						["Melee"] = 14,
					},
					["DOT_Time"] = 0,
					["Damage"] = 22,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Melee"] = 22,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 14,
								},
							},
							["amount"] = 14,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["断骨骷髅"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 3,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["断骨骷髅"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["腐脑魔导师"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 11,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 22,
								},
							},
							["count"] = 2,
							["amount"] = 22,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["断骨骷髅"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["腐脑魔导师"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 22,
								},
							},
							["amount"] = 22,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 3,
					["TimeDamaging"] = {
						["断骨骷髅"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["腐脑魔导师"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
						["Melee"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 0,
					},
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["治安官雷德帕斯"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["衰老的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["治安官雷德帕斯"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["衰老的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["治安官雷德帕斯"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["衰老的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["肉搏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["治安官雷德帕斯"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["衰老的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["Attacks"] = {
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 12,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 12,
								},
							},
							["count"] = 1,
							["amount"] = 12,
						},
					},
					["ActiveTime"] = 1.5,
					["ElementDone"] = {
						["Melee"] = 12,
					},
					["TimeDamaging"] = {
						["腐脑狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["被诅咒的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 1,
								},
								["Dodge"] = {
									["count"] = 0,
								},
							},
							["amount"] = 1,
						},
					},
					["DamageTaken"] = 11,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
					},
					["DamagedWho"] = {
						["腐脑狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
						["被诅咒的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 1.5,
					["WhoDamaged"] = {
						["腐脑狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 11,
								},
							},
							["amount"] = 11,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被诅咒的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTaken"] = {
						["Melee"] = 11,
					},
					["TimeSpent"] = {
						["腐脑狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["被诅咒的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Damage"] = 12,
				},
				["Fight4"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 13,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
						["Melee"] = 13,
					},
					["DOT_Time"] = 0,
					["Damage"] = 45,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 45,
					},
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["腐脑狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 22,
								},
							},
							["amount"] = 22,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 23,
								},
							},
							["amount"] = 23,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 13,
								},
							},
							["amount"] = 13,
						},
						["腐脑狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["腐脑狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 6,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["肉搏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 12,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 45,
								},
							},
							["count"] = 4,
							["amount"] = 45,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 6,
					["TimeDamaging"] = {
						["腐脑狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["Attacks"] = {
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 12,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 12,
								},
							},
							["count"] = 1,
							["amount"] = 12,
						},
					},
					["ActiveTime"] = 1.5,
					["ElementDone"] = {
						["Melee"] = 12,
					},
					["TimeDamaging"] = {
						["腐脑狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["被诅咒的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 1,
								},
								["Dodge"] = {
									["count"] = 0,
								},
							},
							["amount"] = 1,
						},
					},
					["DamageTaken"] = 11,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
					},
					["DamagedWho"] = {
						["腐脑狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
						["被诅咒的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 1.5,
					["WhoDamaged"] = {
						["腐脑狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 11,
								},
							},
							["amount"] = 11,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["被诅咒的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTaken"] = {
						["Melee"] = 11,
					},
					["TimeSpent"] = {
						["腐脑狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["被诅咒的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["食腐狼幼崽"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Damage"] = 12,
				},
				["Fight2"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 10,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
						["Melee"] = 10,
					},
					["DOT_Time"] = 0,
					["Damage"] = 12,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Melee"] = 12,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
						["腐脑狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["蓬毛食腐狼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["衰老的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 10,
								},
							},
							["amount"] = 10,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 1.5,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["腐脑狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["蓬毛食腐狼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["衰老的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 12,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 12,
								},
							},
							["count"] = 1,
							["amount"] = 12,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["腐脑狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["蓬毛食腐狼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["衰老的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
					},
					["TimeDamage"] = 1.5,
					["TimeDamaging"] = {
						["腐脑狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["蓬毛食腐狼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["衰老的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["癞皮夜行蝙蝠"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight3"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 24,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
								["Dodge"] = {
									["count"] = 0,
								},
							},
							["amount"] = 2,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["HOTs"] = {
					},
					["ManaGain"] = 0,
					["ElementTaken"] = {
						["Melee"] = 24,
					},
					["DOT_Time"] = 0,
					["Damage"] = 79,
					["ElementDoneAbsorb"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["RageGain"] = 0,
					["FAttacks"] = {
					},
					["PartialBlock"] = {
					},
					["ElementDone"] = {
						["Melee"] = 79,
					},
					["CCBroken"] = {
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 6,
						},
					},
					["Dispelled"] = 0,
					["WhoDamaged"] = {
						["腐脑狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 24,
								},
							},
							["amount"] = 24,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["衰老的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["FDamagedWho"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["RageGained"] = {
					},
					["ActiveTime"] = 9,
					["CCBreak"] = 0,
					["EnergyGain"] = 0,
					["WhoHealed"] = {
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
					},
					["ManaGained"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["ElementTakenResist"] = {
					},
					["InterruptData"] = {
					},
					["WhoDispelled"] = {
					},
					["TimeSpent"] = {
						["衰老的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["腐脑狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["蓬毛食腐狼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 7.5,
								},
							},
							["amount"] = 7.5,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["Heals"] = {
					},
					["FDamage"] = 0,
					["EnergyGained"] = {
					},
					["HealedWho"] = {
					},
					["Healing"] = 0,
					["RunicPowerGained"] = {
					},
					["ManaGainedFrom"] = {
					},
					["Attacks"] = {
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 23,
									["min"] = 23,
									["count"] = 1,
									["amount"] = 23,
								},
								["Hit"] = {
									["max"] = 12,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 56,
								},
							},
							["count"] = 6,
							["amount"] = 79,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["衰老的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["腐脑狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["蓬毛食腐狼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 68,
								},
							},
							["amount"] = 68,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 11,
								},
							},
							["amount"] = 11,
						},
					},
					["TimeDamage"] = 9,
					["TimeDamaging"] = {
						["衰老的黑暗犬"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["腐脑狂战士"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["蓬毛食腐狼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["无脑的食尸鬼"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法雇农"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 7.5,
								},
							},
							["amount"] = 7.5,
						},
						["小夜行蜘蛛"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["提瑞斯法农夫"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["RunicPowerGain"] = 0,
					["ElementTakenBlock"] = {
					},
					["DispelledWho"] = {
					},
				},
			},
			["NextEventNum"] = 24,
			["LastDamageTime"] = 262545.878,
			["LastEvents"] = {
				"蜘蛛 <咕噜胖> 肉搏 被诅咒的黑暗犬 Hit -11 (Physical)", -- [1]
				"蜘蛛 <咕噜胖> 肉搏 衰老的黑暗犬 Hit -11 (Physical)", -- [2]
				"衰老的黑暗犬 肉搏 蜘蛛 <咕噜胖> Hit -8 (Physical)", -- [3]
				"提瑞斯法雇农 肉搏 蜘蛛 <咕噜胖> Hit -14 (Physical)", -- [4]
				"蜘蛛 <咕噜胖> 肉搏 提瑞斯法雇农 Hit -11 (Physical)", -- [5]
				"蜘蛛 <咕噜胖> 肉搏 提瑞斯法雇农 Hit -11 (Physical)", -- [6]
				"提瑞斯法雇农 肉搏 蜘蛛 <咕噜胖> Hit -13 (Physical)", -- [7]
				"蜘蛛 <咕噜胖> 肉搏 提瑞斯法雇农 Hit -11 (Physical)", -- [8]
				"蜘蛛 <咕噜胖> 肉搏 提瑞斯法雇农 Hit -11 (Physical)", -- [9]
				"蜘蛛 <咕噜胖> 肉搏 提瑞斯法农夫 Hit -11 (Physical)", -- [10]
				"蜘蛛 <咕噜胖> 肉搏 提瑞斯法农夫 Hit -12 (Physical)", -- [11]
				"蜘蛛 <咕噜胖> 肉搏 提瑞斯法雇农 Hit -11 (Physical)", -- [12]
				"提瑞斯法雇农 肉搏 蜘蛛 <咕噜胖> Hit -13 (Physical)", -- [13]
				"蜘蛛 <咕噜胖> 肉搏 提瑞斯法雇农 Hit -11 (Physical)", -- [14]
				"蜘蛛 <咕噜胖> 肉搏 提瑞斯法雇农 Hit -11 (Physical)", -- [15]
				"蜘蛛 <咕噜胖> 肉搏 提瑞斯法农夫 Hit -11 (Physical)", -- [16]
				"蜘蛛 <咕噜胖> 肉搏 提瑞斯法雇农 Crit -23 (Physical)", -- [17]
				"提瑞斯法雇农 肉搏 蜘蛛 <咕噜胖> Hit -11 (Physical)", -- [18]
				"蜘蛛 <咕噜胖> 肉搏 提瑞斯法雇农 Hit -12 (Physical)", -- [19]
				"提瑞斯法农夫 肉搏 蜘蛛 <咕噜胖> Hit -10 (Physical)", -- [20]
				"蜘蛛 <咕噜胖> 肉搏 提瑞斯法农夫 Hit -12 (Physical)", -- [21]
				"提瑞斯法雇农 肉搏 蜘蛛 <咕噜胖> Hit -11 (Physical)", -- [22]
				"蜘蛛 <咕噜胖> 肉搏 提瑞斯法雇农 Hit -12 (Physical)", -- [23]
				"蜘蛛 <咕噜胖> 肉搏 腐脑狂战士 Hit -10 (Physical)", -- [24]
				"腐脑狂战士 肉搏 蜘蛛 <咕噜胖> Miss (1)", -- [25]
				"蜘蛛 <咕噜胖> 肉搏 腐脑狂战士 Crit -20 (Physical)", -- [26]
				"腐脑狂战士 肉搏 蜘蛛 <咕噜胖> Hit -4 (Physical)", -- [27]
				"蜘蛛 <咕噜胖> 肉搏 腐脑狂战士 Hit -10 (Physical)", -- [28]
				"治安官雷德帕斯 肉搏 蜘蛛 <咕噜胖> Miss (1)", -- [29]
				"蜘蛛 <咕噜胖> 肉搏 治安官雷德帕斯 Hit -10 (Physical)", -- [30]
				"治安官雷德帕斯 肉搏 蜘蛛 <咕噜胖> Parry (1)", -- [31]
				"治安官雷德帕斯 肉搏 蜘蛛 <咕噜胖> Hit -5 (Physical)", -- [32]
				"蜘蛛 <咕噜胖> 肉搏 治安官雷德帕斯 Hit -11 (Physical)", -- [33]
				"治安官雷德帕斯 肉搏 蜘蛛 <咕噜胖> Hit -3 (Physical)", -- [34]
				"治安官雷德帕斯 肉搏 蜘蛛 <咕噜胖> Hit -6 (Physical)", -- [35]
				"蜘蛛 <咕噜胖> 肉搏 治安官雷德帕斯 Hit -11 (Physical)", -- [36]
				"治安官雷德帕斯 肉搏 蜘蛛 <咕噜胖> Hit -3 (Physical)", -- [37]
				"治安官雷德帕斯 肉搏 蜘蛛 <咕噜胖> Miss (1)", -- [38]
				"蜘蛛 <咕噜胖> 肉搏 治安官雷德帕斯 Hit -10 (Physical)", -- [39]
				"蜘蛛 <咕噜胖> 肉搏 腐脑魔导师 Hit -11 (Physical)", -- [40]
				"蜘蛛 <咕噜胖> 肉搏 腐脑狂战士 Hit -10 (Physical)", -- [41]
				"腐脑狂战士 肉搏 蜘蛛 <咕噜胖> Hit -6 (Physical)", -- [42]
				"腐脑狂战士 肉搏 蜘蛛 <咕噜胖> Hit -6 (Physical)", -- [43]
				"衰老的黑暗犬 肉搏 蜘蛛 <咕噜胖> Hit -6 (Physical)", -- [44]
				"蜘蛛 <咕噜胖> 肉搏 衰老的黑暗犬 Hit -12 (Physical)", -- [45]
				"衰老的黑暗犬 肉搏 蜘蛛 <咕噜胖> Hit -8 (Physical)", -- [46]
				"蜘蛛 <咕噜胖> 肉搏 衰老的黑暗犬 Hit -11 (Physical)", -- [47]
				"被诅咒的黑暗犬 肉搏 蜘蛛 <咕噜胖> Hit -6 (Physical)", -- [48]
				"蜘蛛 <咕噜胖> 肉搏 被诅咒的黑暗犬 Hit -11 (Physical)", -- [49]
				"被诅咒的黑暗犬 肉搏 蜘蛛 <咕噜胖> Hit -7 (Physical)", -- [50]
			},
			["Name"] = "蜘蛛",
			["LastEventTimes"] = {
				262435.537, -- [1]
				262445.92, -- [2]
				262446.133, -- [3]
				262464.284, -- [4]
				262464.392, -- [5]
				262466.279, -- [6]
				262473.179, -- [7]
				262473.609, -- [8]
				262475.598, -- [9]
				262483.304, -- [10]
				262485.309, -- [11]
				262492.343, -- [12]
				262493.702, -- [13]
				262494.313, -- [14]
				262496.286, -- [15]
				262500.152, -- [16]
				262506.121, -- [17]
				262507.099, -- [18]
				262508.097, -- [19]
				262525.579, -- [20]
				262525.579, -- [21]
				262545.45, -- [22]
				262545.878, -- [23]
				262005.962, -- [24]
				262006.279, -- [25]
				262007.916, -- [26]
				262008.228, -- [27]
				262009.913, -- [28]
				262014.823, -- [29]
				262015.225, -- [30]
				262015.84, -- [31]
				262016.847, -- [32]
				262017.216, -- [33]
				262017.858, -- [34]
				262018.826, -- [35]
				262019.183, -- [36]
				262019.851, -- [37]
				262020.844, -- [38]
				262021.064, -- [39]
				262024.692, -- [40]
				262033.643, -- [41]
				262033.643, -- [42]
				262034.609, -- [43]
				262359.214, -- [44]
				262359.214, -- [45]
				262368.97, -- [46]
				262368.97, -- [47]
				262433.428, -- [48]
				262433.571, -- [49]
				262435.423, -- [50]
			},
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				true, -- [3]
				true, -- [4]
				false, -- [5]
				false, -- [6]
				true, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				true, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				true, -- [18]
				false, -- [19]
				true, -- [20]
				false, -- [21]
				true, -- [22]
				false, -- [23]
				false, -- [24]
				true, -- [25]
				false, -- [26]
				true, -- [27]
				false, -- [28]
				true, -- [29]
				false, -- [30]
				true, -- [31]
				true, -- [32]
				false, -- [33]
				true, -- [34]
				true, -- [35]
				false, -- [36]
				true, -- [37]
				true, -- [38]
				false, -- [39]
				false, -- [40]
				false, -- [41]
				true, -- [42]
				true, -- [43]
				true, -- [44]
				false, -- [45]
				true, -- [46]
				false, -- [47]
				true, -- [48]
				false, -- [49]
				true, -- [50]
			},
			["TimeLast"] = {
				["ActiveTime"] = 262545.332,
				["TimeDamage"] = 262545.332,
				["OVERALL"] = 262545.332,
				["DamageTaken"] = 262545.332,
				["Damage"] = 262545.332,
			},
			["LastEventHealthMax"] = {
				328, -- [1]
				328, -- [2]
				328, -- [3]
				328, -- [4]
				328, -- [5]
				328, -- [6]
				328, -- [7]
				328, -- [8]
				328, -- [9]
				328, -- [10]
				328, -- [11]
				328, -- [12]
				328, -- [13]
				328, -- [14]
				328, -- [15]
				328, -- [16]
				328, -- [17]
				328, -- [18]
				328, -- [19]
				328, -- [20]
				328, -- [21]
				328, -- [22]
				328, -- [23]
				250, -- [24]
				250, -- [25]
				250, -- [26]
				250, -- [27]
				250, -- [28]
				250, -- [29]
				250, -- [30]
				250, -- [31]
				250, -- [32]
				250, -- [33]
				250, -- [34]
				250, -- [35]
				250, -- [36]
				250, -- [37]
				250, -- [38]
				250, -- [39]
				250, -- [40]
				250, -- [41]
				250, -- [42]
				250, -- [43]
				328, -- [44]
				328, -- [45]
				328, -- [46]
				328, -- [47]
				328, -- [48]
				328, -- [49]
				328, -- [50]
			},
			["LastActive"] = 262545.332,
		},
	},
	["FightNum"] = 44,
	["CombatTimes"] = {
		{
			435570.514, -- [1]
			435579.521, -- [2]
			"22:50:41", -- [3]
			"22:50:50", -- [4]
			"断骨骷髅", -- [5]
		}, -- [1]
		{
			435579.521, -- [1]
			435584.506, -- [2]
			"22:50:50", -- [3]
			"22:50:55", -- [4]
			"无脑的食尸鬼", -- [5]
		}, -- [2]
		{
			435587.513, -- [1]
			435594.519, -- [2]
			"22:50:58", -- [3]
			"22:51:05", -- [4]
			"无脑的食尸鬼", -- [5]
		}, -- [3]
		{
			435597.514, -- [1]
			435602.513, -- [2]
			"22:51:08", -- [3]
			"22:51:13", -- [4]
			"断骨骷髅", -- [5]
		}, -- [4]
		{
			435611.522, -- [1]
			435615.52, -- [2]
			"22:51:22", -- [3]
			"22:51:26", -- [4]
			"断骨骷髅", -- [5]
		}, -- [5]
		{
			435621.506, -- [1]
			435625.519, -- [2]
			"22:51:32", -- [3]
			"22:51:36", -- [4]
			"无脑的食尸鬼", -- [5]
		}, -- [6]
		{
			435820.515, -- [1]
			435825.509, -- [2]
			"22:54:51", -- [3]
			"22:54:56", -- [4]
			"癞皮夜行蝙蝠", -- [5]
		}, -- [7]
		{
			435826.521, -- [1]
			435832.514, -- [2]
			"22:54:57", -- [3]
			"22:55:03", -- [4]
			"癞皮夜行蝙蝠", -- [5]
		}, -- [8]
		{
			435834.507, -- [1]
			435839.508, -- [2]
			"22:55:05", -- [3]
			"22:55:10", -- [4]
			"蓬毛食腐狼", -- [5]
		}, -- [9]
		{
			435846.511, -- [1]
			435855.509, -- [2]
			"22:55:17", -- [3]
			"22:55:26", -- [4]
			"癞皮夜行蝙蝠", -- [5]
		}, -- [10]
		{
			435860.515, -- [1]
			435866.523, -- [2]
			"22:55:31", -- [3]
			"22:55:37", -- [4]
			"食腐狼幼崽", -- [5]
		}, -- [11]
		{
			435866.523, -- [1]
			435871.508, -- [2]
			"22:55:37", -- [3]
			"22:55:42", -- [4]
			"蓬毛食腐狼", -- [5]
		}, -- [12]
		{
			435875.512, -- [1]
			435880.521, -- [2]
			"22:55:46", -- [3]
			"22:55:51", -- [4]
			"蓬毛食腐狼", -- [5]
		}, -- [13]
		{
			435884.506, -- [1]
			435889.506, -- [2]
			"22:55:55", -- [3]
			"22:56:00", -- [4]
			"食腐狼幼崽", -- [5]
		}, -- [14]
		{
			261750.332, -- [1]
			261755.33, -- [2]
			"22:59:43", -- [3]
			"22:59:47", -- [4]
			"断骨骷髅", -- [5]
		}, -- [15]
		{
			261779.347, -- [1]
			261784.333, -- [2]
			"23:00:12", -- [3]
			"23:00:16", -- [4]
			"小夜行蜘蛛", -- [5]
		}, -- [16]
		{
			261789.338, -- [1]
			261794.345, -- [2]
			"23:00:22", -- [3]
			"23:00:26", -- [4]
			"小夜行蜘蛛", -- [5]
		}, -- [17]
		{
			261798.336, -- [1]
			261802.33, -- [2]
			"23:00:31", -- [3]
			"23:00:34", -- [4]
			"小夜行蜘蛛", -- [5]
		}, -- [18]
		{
			261802.33, -- [1]
			261807.339, -- [2]
			"23:00:35", -- [3]
			"23:00:39", -- [4]
			"小夜行蜘蛛", -- [5]
		}, -- [19]
		{
			261808.344, -- [1]
			261812.347, -- [2]
			"23:00:41", -- [3]
			"23:00:44", -- [4]
			"小夜行蜘蛛", -- [5]
		}, -- [20]
		{
			261815.334, -- [1]
			261820.352, -- [2]
			"23:00:48", -- [3]
			"23:00:52", -- [4]
			"小夜行蜘蛛", -- [5]
		}, -- [21]
		{
			261837.346, -- [1]
			261841.343, -- [2]
			"23:01:10", -- [3]
			"23:01:13", -- [4]
			"夜行蜘蛛", -- [5]
		}, -- [22]
		{
			261842.339, -- [1]
			261847.339, -- [2]
			"23:01:15", -- [3]
			"23:01:19", -- [4]
			"夜行蜘蛛", -- [5]
		}, -- [23]
		{
			261851.344, -- [1]
			261856.339, -- [2]
			"23:01:24", -- [3]
			"23:01:28", -- [4]
			"夜行蜘蛛", -- [5]
		}, -- [24]
		{
			261873.337, -- [1]
			261876.339, -- [2]
			"23:01:46", -- [3]
			"23:01:48", -- [4]
			"夜行蜘蛛", -- [5]
		}, -- [25]
		{
			261889.333, -- [1]
			261895.336, -- [2]
			"23:02:02", -- [3]
			"23:02:07", -- [4]
			"小夜行蜘蛛", -- [5]
		}, -- [26]
		{
			261902.337, -- [1]
			261907.345, -- [2]
			"23:02:15", -- [3]
			"23:02:19", -- [4]
			"食腐狼幼崽", -- [5]
		}, -- [27]
		{
			261953.349, -- [1]
			261957.35, -- [2]
			"23:03:06", -- [3]
			"23:03:09", -- [4]
			"癞皮夜行蝙蝠", -- [5]
		}, -- [28]
		{
			261980.346, -- [1]
			261984.341, -- [2]
			"23:03:33", -- [3]
			"23:03:36", -- [4]
			"腐脑魔导师", -- [5]
		}, -- [29]
		{
			261988.33, -- [1]
			261991.337, -- [2]
			"23:03:41", -- [3]
			"23:03:43", -- [4]
			"腐脑狂战士", -- [5]
		}, -- [30]
		{
			261992.343, -- [1]
			262003.337, -- [2]
			"23:03:45", -- [3]
			"23:03:55", -- [4]
			"腐脑狂战士", -- [5]
		}, -- [31]
		{
			262003.337, -- [1]
			262010.354, -- [2]
			"23:03:56", -- [3]
			"23:04:02", -- [4]
			"腐脑狂战士", -- [5]
		}, -- [32]
		{
			262013.342, -- [1]
			262022.342, -- [2]
			"23:04:06", -- [3]
			"23:04:14", -- [4]
			"治安官雷德帕斯", -- [5]
		}, -- [33]
		{
			262022.342, -- [1]
			262027.345, -- [2]
			"23:04:15", -- [3]
			"23:04:19", -- [4]
			"腐脑魔导师", -- [5]
		}, -- [34]
		{
			262031.341, -- [1]
			262036.336, -- [2]
			"23:04:24", -- [3]
			"23:04:28", -- [4]
			"腐脑狂战士", -- [5]
		}, -- [35]
		{
			262357.341, -- [1]
			262362.347, -- [2]
			"23:09:50", -- [3]
			"23:09:54", -- [4]
			"衰老的黑暗犬", -- [5]
		}, -- [36]
		{
			262366.344, -- [1]
			262370.351, -- [2]
			"23:09:59", -- [3]
			"23:10:02", -- [4]
			"衰老的黑暗犬", -- [5]
		}, -- [37]
		{
			262430.331, -- [1]
			262437.332, -- [2]
			"23:11:03", -- [3]
			"23:11:09", -- [4]
			"被诅咒的黑暗犬", -- [5]
		}, -- [38]
		{
			262443.337, -- [1]
			262447.334, -- [2]
			"23:11:16", -- [3]
			"23:11:19", -- [4]
			"衰老的黑暗犬", -- [5]
		}, -- [39]
		{
			262461.34, -- [1]
			262468.336, -- [2]
			"23:11:34", -- [3]
			"23:11:40", -- [4]
			"提瑞斯法雇农", -- [5]
		}, -- [40]
		{
			262471.342, -- [1]
			262488.344, -- [2]
			"23:11:44", -- [3]
			"23:12:00", -- [4]
			"提瑞斯法雇农", -- [5]
		}, -- [41]
		{
			262489.345, -- [1]
			262509.344, -- [2]
			"23:12:02", -- [3]
			"23:12:21", -- [4]
			"提瑞斯法雇农", -- [5]
		}, -- [42]
		{
			262523.342, -- [1]
			262527.34, -- [2]
			"23:12:36", -- [3]
			"23:12:39", -- [4]
			"提瑞斯法农夫", -- [5]
		}, -- [43]
		{
			262542.332, -- [1]
			262548.333, -- [2]
			"23:12:55", -- [3]
			"23:13:00", -- [4]
			"提瑞斯法雇农", -- [5]
		}, -- [44]
	},
	["FoughtWho"] = {
		"提瑞斯法雇农 23:12:55-23:13:00", -- [1]
		"提瑞斯法农夫 23:12:36-23:12:39", -- [2]
		"提瑞斯法雇农 23:12:02-23:12:21", -- [3]
		"提瑞斯法雇农 23:11:44-23:12:00", -- [4]
		"提瑞斯法雇农 23:11:34-23:11:40", -- [5]
	},
}
