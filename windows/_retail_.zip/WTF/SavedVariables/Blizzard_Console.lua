
Blizzard_Console_SavedVars = {
	["version"] = 3,
	["messageHistory"] = {
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [1]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [2]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [3]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [4]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"3\"", -- [1]
			0, -- [2]
		}, -- [5]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [6]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-1-8\"", -- [1]
			0, -- [2]
		}, -- [7]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [8]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [9]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [10]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [11]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [12]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [13]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [14]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [15]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [16]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [17]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [18]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [19]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [20]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [21]
		{
			"Proficiency in item class 2 set to 0x0000000091", -- [1]
			0, -- [2]
		}, -- [22]
		{
			"Proficiency in item class 2 set to 0x0000000191", -- [1]
			0, -- [2]
		}, -- [23]
		{
			"Proficiency in item class 2 set to 0x00000001b1", -- [1]
			0, -- [2]
		}, -- [24]
		{
			"Proficiency in item class 2 set to 0x00000001b3", -- [1]
			0, -- [2]
		}, -- [25]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [26]
		{
			"Proficiency in item class 2 set to 0x00000041b3", -- [1]
			0, -- [2]
		}, -- [27]
		{
			"Proficiency in item class 2 set to 0x00000041f3", -- [1]
			0, -- [2]
		}, -- [28]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [29]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [30]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [31]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [32]
		{
			"Proficiency in item class 2 set to 0x00000041f3", -- [1]
			0, -- [2]
		}, -- [33]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [34]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [35]
		{
			"Time set to 9/6/2019 (Fri) 23:20", -- [1]
			0, -- [2]
		}, -- [36]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [37]
		{
			"Skill 186 increased from 22 to 23", -- [1]
			0, -- [2]
		}, -- [38]
		{
			"Skill 2565 increased from 22 to 23", -- [1]
			0, -- [2]
		}, -- [39]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [40]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [41]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [42]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [43]
		{
			"Skill 186 increased from 23 to 24", -- [1]
			0, -- [2]
		}, -- [44]
		{
			"Skill 2565 increased from 23 to 24", -- [1]
			0, -- [2]
		}, -- [45]
		{
			"Skill 118 increased from 565 to 570", -- [1]
			0, -- [2]
		}, -- [46]
		{
			"Skill 183 increased from 565 to 570", -- [1]
			0, -- [2]
		}, -- [47]
		{
			"Skill 753 increased from 565 to 570", -- [1]
			0, -- [2]
		}, -- [48]
		{
			"Skill 796 increased from 565 to 570", -- [1]
			0, -- [2]
		}, -- [49]
		{
			"Skill 186 increased from 24 to 25", -- [1]
			0, -- [2]
		}, -- [50]
		{
			"Skill 2565 increased from 24 to 25", -- [1]
			0, -- [2]
		}, -- [51]
		{
			"Skill 186 increased from 25 to 26", -- [1]
			0, -- [2]
		}, -- [52]
		{
			"Skill 2565 increased from 25 to 26", -- [1]
			0, -- [2]
		}, -- [53]
		{
			"Skill 186 increased from 26 to 27", -- [1]
			0, -- [2]
		}, -- [54]
		{
			"Skill 2565 increased from 26 to 27", -- [1]
			0, -- [2]
		}, -- [55]
		{
			"Skill 186 increased from 27 to 28", -- [1]
			0, -- [2]
		}, -- [56]
		{
			"Skill 2565 increased from 27 to 28", -- [1]
			0, -- [2]
		}, -- [57]
		{
			"Skill 186 increased from 28 to 29", -- [1]
			0, -- [2]
		}, -- [58]
		{
			"Skill 2565 increased from 28 to 29", -- [1]
			0, -- [2]
		}, -- [59]
		{
			"Skill 186 increased from 29 to 30", -- [1]
			0, -- [2]
		}, -- [60]
		{
			"Skill 2565 increased from 29 to 30", -- [1]
			0, -- [2]
		}, -- [61]
		{
			"Skill 186 increased from 30 to 31", -- [1]
			0, -- [2]
		}, -- [62]
		{
			"Skill 2565 increased from 30 to 31", -- [1]
			0, -- [2]
		}, -- [63]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [64]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [65]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [66]
		{
			"Skill 186 increased from 31 to 32", -- [1]
			0, -- [2]
		}, -- [67]
		{
			"Skill 2565 increased from 31 to 32", -- [1]
			0, -- [2]
		}, -- [68]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [69]
		{
			"Skill 186 increased from 32 to 33", -- [1]
			0, -- [2]
		}, -- [70]
		{
			"Skill 2565 increased from 32 to 33", -- [1]
			0, -- [2]
		}, -- [71]
		{
			"Skill 118 increased from 570 to 575", -- [1]
			0, -- [2]
		}, -- [72]
		{
			"Skill 183 increased from 570 to 575", -- [1]
			0, -- [2]
		}, -- [73]
		{
			"Skill 753 increased from 570 to 575", -- [1]
			0, -- [2]
		}, -- [74]
		{
			"Skill 796 increased from 570 to 575", -- [1]
			0, -- [2]
		}, -- [75]
		{
			"Skill 186 increased from 33 to 34", -- [1]
			0, -- [2]
		}, -- [76]
		{
			"Skill 2565 increased from 33 to 34", -- [1]
			0, -- [2]
		}, -- [77]
		{
			"Skill 186 increased from 34 to 35", -- [1]
			0, -- [2]
		}, -- [78]
		{
			"Skill 2565 increased from 34 to 35", -- [1]
			0, -- [2]
		}, -- [79]
		{
			"Weather changed to 3, intensity 0.158160\n", -- [1]
			0, -- [2]
		}, -- [80]
		{
			"Skill 186 increased from 35 to 36", -- [1]
			0, -- [2]
		}, -- [81]
		{
			"Skill 2565 increased from 35 to 36", -- [1]
			0, -- [2]
		}, -- [82]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [83]
		{
			"Skill 186 increased from 36 to 37", -- [1]
			0, -- [2]
		}, -- [84]
		{
			"Skill 2565 increased from 36 to 37", -- [1]
			0, -- [2]
		}, -- [85]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [86]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [87]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [88]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [89]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [90]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [91]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [92]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [93]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [94]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [95]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [96]
		{
			"Water detail changed to 1", -- [1]
			0, -- [2]
		}, -- [97]
		{
			"Ripple detail changed to 0", -- [1]
			0, -- [2]
		}, -- [98]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [99]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [100]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [101]
		{
			"Refraction mode changed to 0", -- [1]
			0, -- [2]
		}, -- [102]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [103]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [104]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [105]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [106]
		{
			"Shadow mode changed to 0 - Precomputed terrain shadows, 1 band unit shadows, 1024", -- [1]
			0, -- [2]
		}, -- [107]
		{
			"Shadow texture size changed to 1024.", -- [1]
			0, -- [2]
		}, -- [108]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [109]
		{
			"SSAO mode set to 1", -- [1]
			0, -- [2]
		}, -- [110]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [111]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [112]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [113]
		{
			"Terrain mip level changed to 1.", -- [1]
			0, -- [2]
		}, -- [114]
		{
			"Outline mode changed to 1", -- [1]
			0, -- [2]
		}, -- [115]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [116]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [117]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [118]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [119]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [120]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [121]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [122]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [123]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [124]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [125]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [126]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [127]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [128]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [129]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [130]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [131]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [132]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [133]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [134]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [135]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [136]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [137]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [138]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [139]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [140]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [141]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [142]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [143]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [144]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [145]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [146]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [147]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [148]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"3\"", -- [1]
			0, -- [2]
		}, -- [149]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [150]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-1-8\"", -- [1]
			0, -- [2]
		}, -- [151]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [152]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [153]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [154]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [155]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [156]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [157]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [158]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [159]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [160]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [161]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [162]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [163]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [164]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [165]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [166]
		{
			"Proficiency in item class 2 set to 0x0000000091", -- [1]
			0, -- [2]
		}, -- [167]
		{
			"Proficiency in item class 2 set to 0x0000000191", -- [1]
			0, -- [2]
		}, -- [168]
		{
			"Proficiency in item class 2 set to 0x00000001b1", -- [1]
			0, -- [2]
		}, -- [169]
		{
			"Proficiency in item class 2 set to 0x00000001b3", -- [1]
			0, -- [2]
		}, -- [170]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [171]
		{
			"Proficiency in item class 2 set to 0x00000041b3", -- [1]
			0, -- [2]
		}, -- [172]
		{
			"Proficiency in item class 2 set to 0x00000041f3", -- [1]
			0, -- [2]
		}, -- [173]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [174]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [175]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [176]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [177]
		{
			"Proficiency in item class 2 set to 0x00000041f3", -- [1]
			0, -- [2]
		}, -- [178]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [179]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [180]
		{
			"Time set to 9/7/2019 (Sat) 9:02", -- [1]
			0, -- [2]
		}, -- [181]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [182]
		{
			"Skill 186 increased from 37 to 38", -- [1]
			0, -- [2]
		}, -- [183]
		{
			"Skill 2565 increased from 37 to 38", -- [1]
			0, -- [2]
		}, -- [184]
		{
			"Skill 186 increased from 38 to 39", -- [1]
			0, -- [2]
		}, -- [185]
		{
			"Skill 2565 increased from 38 to 39", -- [1]
			0, -- [2]
		}, -- [186]
		{
			"Skill 186 increased from 39 to 40", -- [1]
			0, -- [2]
		}, -- [187]
		{
			"Skill 2565 increased from 39 to 40", -- [1]
			0, -- [2]
		}, -- [188]
		{
			"Skill 186 increased from 40 to 41", -- [1]
			0, -- [2]
		}, -- [189]
		{
			"Skill 2565 increased from 40 to 41", -- [1]
			0, -- [2]
		}, -- [190]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [191]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [192]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [193]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [194]
		{
			"Weather changed to 2, intensity 0.081328\n", -- [1]
			0, -- [2]
		}, -- [195]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [196]
		{
			"Weather changed to 2, intensity 0.081328\n", -- [1]
			0, -- [2]
		}, -- [197]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [198]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [199]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [200]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [201]
		{
			"Skill 186 increased from 41 to 42", -- [1]
			0, -- [2]
		}, -- [202]
		{
			"Skill 2565 increased from 41 to 42", -- [1]
			0, -- [2]
		}, -- [203]
		{
			"Skill 186 increased from 42 to 43", -- [1]
			0, -- [2]
		}, -- [204]
		{
			"Skill 2565 increased from 42 to 43", -- [1]
			0, -- [2]
		}, -- [205]
		{
			"Skill 118 increased from 575 to 580", -- [1]
			0, -- [2]
		}, -- [206]
		{
			"Skill 183 increased from 575 to 580", -- [1]
			0, -- [2]
		}, -- [207]
		{
			"Skill 753 increased from 575 to 580", -- [1]
			0, -- [2]
		}, -- [208]
		{
			"Skill 796 increased from 575 to 580", -- [1]
			0, -- [2]
		}, -- [209]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [210]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [211]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [212]
		{
			"Weather changed to 5, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [213]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [214]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [215]
		{
			"Skill 2499 increased from 0 to 16", -- [1]
			0, -- [2]
		}, -- [216]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [217]
		{
			"Weather changed to 3, intensity 0.120633\n", -- [1]
			0, -- [2]
		}, -- [218]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [219]
		{
			"Weather changed to 3, intensity 0.120633\n", -- [1]
			0, -- [2]
		}, -- [220]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [221]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [222]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [223]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [224]
		{
			"Skill 186 increased from 43 to 44", -- [1]
			0, -- [2]
		}, -- [225]
		{
			"Skill 2565 increased from 43 to 44", -- [1]
			0, -- [2]
		}, -- [226]
		{
			"Weather changed to 2, intensity 0.800000\n", -- [1]
			0, -- [2]
		}, -- [227]
		{
			"Skill 186 increased from 44 to 45", -- [1]
			0, -- [2]
		}, -- [228]
		{
			"Skill 2565 increased from 44 to 45", -- [1]
			0, -- [2]
		}, -- [229]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [230]
		{
			"Skill 186 increased from 45 to 46", -- [1]
			0, -- [2]
		}, -- [231]
		{
			"Skill 2565 increased from 45 to 46", -- [1]
			0, -- [2]
		}, -- [232]
		{
			"Skill 186 increased from 46 to 47", -- [1]
			0, -- [2]
		}, -- [233]
		{
			"Skill 2565 increased from 46 to 47", -- [1]
			0, -- [2]
		}, -- [234]
		{
			"Skill 186 increased from 47 to 48", -- [1]
			0, -- [2]
		}, -- [235]
		{
			"Skill 2565 increased from 47 to 48", -- [1]
			0, -- [2]
		}, -- [236]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [237]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [238]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [239]
		{
			"Weather changed to 2, intensity 0.800000\n", -- [1]
			0, -- [2]
		}, -- [240]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [241]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [242]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [243]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [244]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [245]
		{
			"Weather changed to 2, intensity 0.800000\n", -- [1]
			0, -- [2]
		}, -- [246]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [247]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [248]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [249]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [250]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [251]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [252]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [253]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [254]
		{
			"Weather changed to 3, intensity 0.114036\n", -- [1]
			0, -- [2]
		}, -- [255]
		{
			"Weather changed to 3, intensity 0.114036\n", -- [1]
			0, -- [2]
		}, -- [256]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [257]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [258]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [259]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [260]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [261]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [262]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [263]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [264]
		{
			"Proficiency in item class 2 set to 0x0000000091", -- [1]
			0, -- [2]
		}, -- [265]
		{
			"Proficiency in item class 2 set to 0x0000000191", -- [1]
			0, -- [2]
		}, -- [266]
		{
			"Proficiency in item class 2 set to 0x00000001b1", -- [1]
			0, -- [2]
		}, -- [267]
		{
			"Proficiency in item class 2 set to 0x00000001b3", -- [1]
			0, -- [2]
		}, -- [268]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [269]
		{
			"Proficiency in item class 2 set to 0x00000041b3", -- [1]
			0, -- [2]
		}, -- [270]
		{
			"Proficiency in item class 2 set to 0x00000041f3", -- [1]
			0, -- [2]
		}, -- [271]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [272]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [273]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [274]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [275]
		{
			"Proficiency in item class 2 set to 0x00000041f3", -- [1]
			0, -- [2]
		}, -- [276]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [277]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [278]
		{
			"Time set to 9/7/2019 (Sat) 10:41", -- [1]
			0, -- [2]
		}, -- [279]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [280]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [281]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [282]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [283]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [284]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [285]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [286]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [287]
		{
			"Skill 186 increased from 48 to 49", -- [1]
			0, -- [2]
		}, -- [288]
		{
			"Skill 2565 increased from 48 to 49", -- [1]
			0, -- [2]
		}, -- [289]
		{
			"Skill 186 increased from 49 to 50", -- [1]
			0, -- [2]
		}, -- [290]
		{
			"Skill 2565 increased from 49 to 50", -- [1]
			0, -- [2]
		}, -- [291]
		{
			"Skill 186 increased from 50 to 51", -- [1]
			0, -- [2]
		}, -- [292]
		{
			"Skill 2565 increased from 50 to 51", -- [1]
			0, -- [2]
		}, -- [293]
		{
			"Skill 186 increased from 51 to 52", -- [1]
			0, -- [2]
		}, -- [294]
		{
			"Skill 2565 increased from 51 to 52", -- [1]
			0, -- [2]
		}, -- [295]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [296]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [297]
		{
			"Skill 186 increased from 52 to 53", -- [1]
			0, -- [2]
		}, -- [298]
		{
			"Skill 2565 increased from 52 to 53", -- [1]
			0, -- [2]
		}, -- [299]
		{
			"Skill 186 increased from 53 to 54", -- [1]
			0, -- [2]
		}, -- [300]
		{
			"Skill 2565 increased from 53 to 54", -- [1]
			0, -- [2]
		}, -- [301]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [302]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [303]
		{
			"Weather changed to 2, intensity 0.225516\n", -- [1]
			0, -- [2]
		}, -- [304]
		{
			"Skill 186 increased from 54 to 55", -- [1]
			0, -- [2]
		}, -- [305]
		{
			"Skill 2565 increased from 54 to 55", -- [1]
			0, -- [2]
		}, -- [306]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [307]
		{
			"Weather changed to 2, intensity 0.225516\n", -- [1]
			0, -- [2]
		}, -- [308]
		{
			"Skill 186 increased from 55 to 56", -- [1]
			0, -- [2]
		}, -- [309]
		{
			"Skill 2565 increased from 55 to 56", -- [1]
			0, -- [2]
		}, -- [310]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [311]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [312]
		{
			"Weather changed to 2, intensity 0.232259\n", -- [1]
			0, -- [2]
		}, -- [313]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [314]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [315]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [316]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [317]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [318]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [319]
		{
			"Weather changed to 2, intensity 0.275771\n", -- [1]
			0, -- [2]
		}, -- [320]
		{
			"Weather changed to 2, intensity 0.275771\n", -- [1]
			0, -- [2]
		}, -- [321]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [322]
		{
			"Skill 186 increased from 56 to 57", -- [1]
			0, -- [2]
		}, -- [323]
		{
			"Skill 2565 increased from 56 to 57", -- [1]
			0, -- [2]
		}, -- [324]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [325]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [326]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [327]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [328]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [329]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [330]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [331]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [332]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [333]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [334]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [335]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [336]
		{
			"Weather changed to 2, intensity 0.278088\n", -- [1]
			0, -- [2]
		}, -- [337]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [338]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [339]
		{
			"Skill 186 increased from 57 to 58", -- [1]
			0, -- [2]
		}, -- [340]
		{
			"Skill 2565 increased from 57 to 58", -- [1]
			0, -- [2]
		}, -- [341]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [342]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [343]
		{
			"Weather changed to 2, intensity 0.266068\n", -- [1]
			0, -- [2]
		}, -- [344]
		{
			"Skill 186 increased from 58 to 59", -- [1]
			0, -- [2]
		}, -- [345]
		{
			"Skill 2565 increased from 58 to 59", -- [1]
			0, -- [2]
		}, -- [346]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [347]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [348]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [349]
		{
			"Weather changed to 3, intensity 0.872423\n", -- [1]
			0, -- [2]
		}, -- [350]
		{
			"Weather changed to 3, intensity 0.872423\n", -- [1]
			0, -- [2]
		}, -- [351]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [352]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [353]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [354]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [355]
		{
			"Weather changed to 2, intensity 0.240180\n", -- [1]
			0, -- [2]
		}, -- [356]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [357]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [358]
		{
			"Skill 186 increased from 59 to 60", -- [1]
			0, -- [2]
		}, -- [359]
		{
			"Skill 2565 increased from 59 to 60", -- [1]
			0, -- [2]
		}, -- [360]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [361]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [362]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [363]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [364]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [365]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [366]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [367]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [368]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [369]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [370]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [371]
		{
			"Water detail changed to 1", -- [1]
			0, -- [2]
		}, -- [372]
		{
			"Ripple detail changed to 0", -- [1]
			0, -- [2]
		}, -- [373]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [374]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [375]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [376]
		{
			"Refraction mode changed to 0", -- [1]
			0, -- [2]
		}, -- [377]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [378]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [379]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [380]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [381]
		{
			"Shadow mode changed to 0 - Precomputed terrain shadows, 1 band unit shadows, 1024", -- [1]
			0, -- [2]
		}, -- [382]
		{
			"Shadow texture size changed to 1024.", -- [1]
			0, -- [2]
		}, -- [383]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [384]
		{
			"SSAO mode set to 1", -- [1]
			0, -- [2]
		}, -- [385]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [386]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [387]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [388]
		{
			"Terrain mip level changed to 1.", -- [1]
			0, -- [2]
		}, -- [389]
		{
			"Outline mode changed to 1", -- [1]
			0, -- [2]
		}, -- [390]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [391]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [392]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [393]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [394]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [395]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [396]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [397]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [398]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [399]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [400]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [401]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [402]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [403]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [404]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [405]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [406]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [407]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [408]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [409]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [410]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [411]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [412]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [413]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [414]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [415]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [416]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [417]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [418]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [419]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [420]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [421]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [422]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [423]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"3\"", -- [1]
			0, -- [2]
		}, -- [424]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [425]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-1-8\"", -- [1]
			0, -- [2]
		}, -- [426]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [427]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [428]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [429]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [430]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [431]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [432]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [433]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [434]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [435]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [436]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [437]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [438]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [439]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [440]
		{
			"Proficiency in item class 2 set to 0x0000000091", -- [1]
			0, -- [2]
		}, -- [441]
		{
			"Proficiency in item class 2 set to 0x0000000191", -- [1]
			0, -- [2]
		}, -- [442]
		{
			"Proficiency in item class 2 set to 0x00000001b1", -- [1]
			0, -- [2]
		}, -- [443]
		{
			"Proficiency in item class 2 set to 0x00000001b3", -- [1]
			0, -- [2]
		}, -- [444]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [445]
		{
			"Proficiency in item class 2 set to 0x00000041b3", -- [1]
			0, -- [2]
		}, -- [446]
		{
			"Proficiency in item class 2 set to 0x00000041f3", -- [1]
			0, -- [2]
		}, -- [447]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [448]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [449]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [450]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [451]
		{
			"Proficiency in item class 2 set to 0x00000041f3", -- [1]
			0, -- [2]
		}, -- [452]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [453]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [454]
		{
			"Time set to 9/7/2019 (Sat) 12:47", -- [1]
			0, -- [2]
		}, -- [455]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [456]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [457]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [458]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [459]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [460]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [461]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [462]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [463]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [464]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [465]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [466]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [467]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [468]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [469]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [470]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [471]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [472]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [473]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [474]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [475]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [476]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [477]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [478]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [479]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [480]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [481]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [482]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [483]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [484]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [485]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [486]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [487]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [488]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [489]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [490]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [491]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [492]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [493]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [494]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [495]
		{
			"Weather changed to 2, intensity 0.800000\n", -- [1]
			0, -- [2]
		}, -- [496]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [497]
		{
			"Skill 118 increased from 590 to 595", -- [1]
			0, -- [2]
		}, -- [498]
		{
			"Skill 183 increased from 590 to 595", -- [1]
			0, -- [2]
		}, -- [499]
		{
			"Skill 753 increased from 590 to 595", -- [1]
			0, -- [2]
		}, -- [500]
		{
			"Skill 796 increased from 590 to 595", -- [1]
			0, -- [2]
		}, -- [501]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [502]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [503]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [504]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [505]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [506]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [507]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [508]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [509]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [510]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [511]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [512]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [513]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [514]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [515]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [516]
		{
			"Weather changed to 2, intensity 0.800000\n", -- [1]
			0, -- [2]
		}, -- [517]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [518]
		{
			"Weather changed to 2, intensity 0.800000\n", -- [1]
			0, -- [2]
		}, -- [519]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [520]
		{
			"Weather changed to 2, intensity 0.800000\n", -- [1]
			0, -- [2]
		}, -- [521]
		{
			"Skill 118 increased from 595 to 600", -- [1]
			0, -- [2]
		}, -- [522]
		{
			"Skill 183 increased from 595 to 600", -- [1]
			0, -- [2]
		}, -- [523]
		{
			"Skill 753 increased from 595 to 600", -- [1]
			0, -- [2]
		}, -- [524]
		{
			"Skill 796 increased from 595 to 600", -- [1]
			0, -- [2]
		}, -- [525]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [526]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [527]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [528]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [529]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [530]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [531]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [532]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [533]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [534]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [535]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [536]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [537]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [538]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [539]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [540]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [541]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [542]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [543]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [544]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [545]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [546]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [547]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [548]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [549]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [550]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [551]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [552]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [553]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [554]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [555]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [556]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [557]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [558]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [559]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [560]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [561]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [562]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [563]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [564]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [565]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [566]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [567]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [568]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [569]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [570]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [571]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [572]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [573]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [574]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [575]
		{
			"Weather changed to 3, intensity 0.866405\n", -- [1]
			0, -- [2]
		}, -- [576]
		{
			"Weather changed to 3, intensity 0.866405\n", -- [1]
			0, -- [2]
		}, -- [577]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [578]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [579]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [580]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [581]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [582]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [583]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [584]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [585]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [586]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [587]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [588]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [589]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [590]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [591]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [592]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [593]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [594]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [595]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [596]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [597]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [598]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [599]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [600]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [601]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [602]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [603]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [604]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [605]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [606]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [607]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [608]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [609]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [610]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [611]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [612]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [613]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [614]
		{
			"Only one lightning storm at a time is supported (including storms from weather).", -- [1]
			0, -- [2]
		}, -- [615]
		{
			"Changing lightning storm from previous lightning ID:0 to new lightning ID: 119.", -- [1]
			0, -- [2]
		}, -- [616]
		{
			"Weather changed to 2, intensity 0.103433\n", -- [1]
			0, -- [2]
		}, -- [617]
		{
			"End lightning storm.", -- [1]
			0, -- [2]
		}, -- [618]
		{
			"Skill 186 increased from 60 to 61", -- [1]
			0, -- [2]
		}, -- [619]
		{
			"Skill 2565 increased from 60 to 61", -- [1]
			0, -- [2]
		}, -- [620]
		{
			"Skill 186 increased from 61 to 62", -- [1]
			0, -- [2]
		}, -- [621]
		{
			"Skill 2565 increased from 61 to 62", -- [1]
			0, -- [2]
		}, -- [622]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [623]
		{
			"Skill 186 increased from 62 to 63", -- [1]
			0, -- [2]
		}, -- [624]
		{
			"Skill 2565 increased from 62 to 63", -- [1]
			0, -- [2]
		}, -- [625]
		{
			"Weather changed to 2, intensity 0.152059\n", -- [1]
			0, -- [2]
		}, -- [626]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [627]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [628]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [629]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [630]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [631]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [632]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [633]
		{
			"Weather changed to 2, intensity 0.152059\n", -- [1]
			0, -- [2]
		}, -- [634]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [635]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [636]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [637]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [638]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [639]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [640]
		{
			"Weather changed to 3, intensity 0.500000\n", -- [1]
			0, -- [2]
		}, -- [641]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [642]
		{
			"Weather changed to 3, intensity 0.500000\n", -- [1]
			0, -- [2]
		}, -- [643]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [644]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [645]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [646]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [647]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [648]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [649]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [650]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [651]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [652]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [653]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [654]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [655]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [656]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [657]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [658]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [659]
		{
			"Multithreaded terrain pass enabled.", -- [1]
			0, -- [2]
		}, -- [660]
		{
			"Water detail changed to 1", -- [1]
			0, -- [2]
		}, -- [661]
		{
			"Ripple detail changed to 0", -- [1]
			0, -- [2]
		}, -- [662]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [663]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [664]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [665]
		{
			"Refraction mode changed to 0", -- [1]
			0, -- [2]
		}, -- [666]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [667]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [668]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [669]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [670]
		{
			"Shadow mode changed to 0 - Precomputed terrain shadows, 1 band unit shadows, 1024", -- [1]
			0, -- [2]
		}, -- [671]
		{
			"Shadow texture size changed to 1024.", -- [1]
			0, -- [2]
		}, -- [672]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [673]
		{
			"SSAO mode set to 1", -- [1]
			0, -- [2]
		}, -- [674]
		{
			"Depth Based Opacity Enabled", -- [1]
			0, -- [2]
		}, -- [675]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [676]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [677]
		{
			"Terrain mip level changed to 1.", -- [1]
			0, -- [2]
		}, -- [678]
		{
			"Outline mode changed to 1", -- [1]
			0, -- [2]
		}, -- [679]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [680]
		{
			"Render scale changed to 1", -- [1]
			0, -- [2]
		}, -- [681]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [682]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [683]
		{
			"MSAA for alpha-test enabled.", -- [1]
			0, -- [2]
		}, -- [684]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [685]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [686]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [687]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [688]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [689]
		{
			"Full memory crash dump disabled", -- [1]
			0, -- [2]
		}, -- [690]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [691]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [692]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [693]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [694]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [695]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [696]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [697]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [698]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [699]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [700]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [701]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [702]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [703]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [704]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [705]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [706]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [707]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [708]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [709]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [710]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [711]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [712]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"3\"", -- [1]
			0, -- [2]
		}, -- [713]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [714]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-1-8\"", -- [1]
			0, -- [2]
		}, -- [715]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [716]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [717]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [718]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [719]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [720]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [721]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [722]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [723]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [724]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [725]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [726]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [727]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [728]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [729]
		{
			"Proficiency in item class 2 set to 0x0000000091", -- [1]
			0, -- [2]
		}, -- [730]
		{
			"Proficiency in item class 2 set to 0x0000000191", -- [1]
			0, -- [2]
		}, -- [731]
		{
			"Proficiency in item class 2 set to 0x00000001b1", -- [1]
			0, -- [2]
		}, -- [732]
		{
			"Proficiency in item class 2 set to 0x00000001b3", -- [1]
			0, -- [2]
		}, -- [733]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [734]
		{
			"Proficiency in item class 2 set to 0x00000041b3", -- [1]
			0, -- [2]
		}, -- [735]
		{
			"Proficiency in item class 2 set to 0x00000041f3", -- [1]
			0, -- [2]
		}, -- [736]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [737]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [738]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [739]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [740]
		{
			"Proficiency in item class 2 set to 0x00000041f3", -- [1]
			0, -- [2]
		}, -- [741]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [742]
		{
			"Weather changed to 2, intensity 0.066260\n", -- [1]
			0, -- [2]
		}, -- [743]
		{
			"Time set to 9/7/2019 (Sat) 19:51", -- [1]
			0, -- [2]
		}, -- [744]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [745]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [746]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [747]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [748]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [749]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [750]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [751]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [752]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [753]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [754]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [755]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [756]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [757]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [758]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [759]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [760]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [761]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [762]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [763]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [764]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [765]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [766]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [767]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [768]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [769]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [770]
		{
			"Weather changed to 2, intensity 0.800000\n", -- [1]
			0, -- [2]
		}, -- [771]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [772]
		{
			"Weather changed to 2, intensity 0.800000\n", -- [1]
			0, -- [2]
		}, -- [773]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [774]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [775]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [776]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [777]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [778]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [779]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [780]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [781]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [782]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [783]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [784]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [785]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [786]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [787]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [788]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [789]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [790]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [791]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [792]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [793]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [794]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [795]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [796]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [797]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [798]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [799]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [800]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [801]
		{
			"Weather changed to 3, intensity 0.382385\n", -- [1]
			0, -- [2]
		}, -- [802]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [803]
		{
			"Weather changed to 3, intensity 0.382385\n", -- [1]
			0, -- [2]
		}, -- [804]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [805]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [806]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [807]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [808]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [809]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [810]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [811]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [812]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [813]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [814]
		{
			"Weather changed to 3, intensity 0.318377\n", -- [1]
			0, -- [2]
		}, -- [815]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [816]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [817]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [818]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [819]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [820]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [821]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [822]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [823]
		{
			"Weather changed to 2, intensity 0.500000\n", -- [1]
			0, -- [2]
		}, -- [824]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [825]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [826]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [827]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [828]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [829]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [830]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [831]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [832]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [833]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [834]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [835]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [836]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [837]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [838]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [839]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [840]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [841]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [842]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [843]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [844]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [845]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [846]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [847]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [848]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [849]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [850]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [851]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [852]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [853]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [854]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [855]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [856]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [857]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [858]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [859]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [860]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [861]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [862]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [863]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [864]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [865]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [866]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [867]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [868]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [869]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [870]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [871]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [872]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [873]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [874]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [875]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [876]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [877]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [878]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [879]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [880]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [881]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [882]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [883]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [884]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [885]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [886]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [887]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [888]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [889]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [890]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [891]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [892]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [893]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [894]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [895]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [896]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [897]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [898]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [899]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [900]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [901]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [902]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [903]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [904]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [905]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [906]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [907]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [908]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [909]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [910]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [911]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [912]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [913]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [914]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [915]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [916]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [917]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [918]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [919]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [920]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [921]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [922]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [923]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [924]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [925]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [926]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [927]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [928]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [929]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [930]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [931]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [932]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [933]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [934]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [935]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [936]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [937]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [938]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [939]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [940]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [941]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [942]
		{
			"Only one lightning storm at a time is supported (including storms from weather).", -- [1]
			0, -- [2]
		}, -- [943]
		{
			"Changing lightning storm from previous lightning ID:0 to new lightning ID: 119.", -- [1]
			0, -- [2]
		}, -- [944]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [945]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [946]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [947]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [948]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [949]
		{
			"Weather changed to 2, intensity 0.076567\n", -- [1]
			0, -- [2]
		}, -- [950]
		{
			"Weather changed to 2, intensity 0.076567\n", -- [1]
			0, -- [2]
		}, -- [951]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [952]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [953]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [954]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [955]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [956]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [957]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [958]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [959]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [960]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [961]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [962]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [963]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [964]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [965]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [966]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [967]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [968]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [969]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [970]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [971]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [972]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [973]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [974]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [975]
		{
			"Weather changed to 2, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [976]
		{
			"Weather changed to 3, intensity 0.107525\n", -- [1]
			0, -- [2]
		}, -- [977]
		{
			"Weather changed to 2, intensity 0.151367\n", -- [1]
			0, -- [2]
		}, -- [978]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [979]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [980]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [981]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [982]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [983]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [984]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [985]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [986]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [987]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [988]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [989]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [990]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [991]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [992]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [993]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [994]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [995]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [996]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [997]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [998]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [999]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [1000]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [1001]
	},
	["height"] = 300,
	["fontHeight"] = 14,
	["isShown"] = false,
	["commandHistory"] = {
	},
}
